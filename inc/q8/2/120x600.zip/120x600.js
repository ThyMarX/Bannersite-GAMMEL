(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.bg_120x600 = function() {
	this.initialize(img.bg_120x600);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,120,600);


(lib.kort = function() {
	this.initialize(img.kort);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,210,129);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABHC2QgQAAgHgMIhIhwIggAAIAABtQAAAPgPAAIg2AAQgPgBAAgPIAAlJQAAgKAEgEQADgDALAAIBPAAQBeAAAjAnQAcAfAAAvQAABKg+AfIAAACIBWB6IADAIQAAAIgJAAgAg4gDIAaAAQA8AAAAg6QAAg5hCAAIgUAAg");
	this.shape.setTransform(56.225,46.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhjC2QgSgBAAgQIAAlLQAAgOAOAAIDPAAQAOAAgBAMIgFAqQgBANgTAAIh9AAIAABOIB1AAQAQAAAAAOIAAAmQAAAPgPgBIh2AAIAABTICHAAQAPAAAAAOIAAAnQAAAPgOAAg");
	this.shape_1.setTransform(26.1033,46.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgfC2QgIAAgCgCQgCgCAAgJIAAkaIhgAAQgPAAAAgQIAAgnQAAgMAPAAIEYAAQAPAAgCAMIgEAqQgBANgSAAIhcAAIAAEZQAAAJgCACQgCACgIABg");
	this.shape_2.setTransform(-2.993,46.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhBC2QgNAAAAgMIAAgdQAAgNANAAIAYAAIAAj/IgcAAQgMAAAAgOIAAgbQAAgMALAAICLAAQANgBAAAMIAAAcQAAAOgNAAIgcAAIAAD/IAaAAQANAAAAANIAAAdQAAALgMABg");
	this.shape_3.setTransform(-28.575,46.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhiC2QgRgBAAgQIAAlLQAAgOAPAAIA1AAQAQAAAAAPIAAEUICEAAQAPABAAAPIAAAnQAAAPgQABg");
	this.shape_4.setTransform(-50.375,46.55);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgcAdQgNgLAAgRQAAgSANgLQAMgLARAAQAQAAAMAKQANAMAAARQAAASgNALQgMALgQAAQgQAAgNgLg");
	this.shape_5.setTransform(-78.2,61.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("ABHC2QgQAAgHgMIhIhwIggAAIAABtQAAAPgPAAIg2AAQgPgBAAgPIAAlJQAAgKAEgEQADgDALAAIBPAAQBeAAAjAnQAcAfAAAvQAABKg+AfIAAACIBWB6IADAIQAAAIgJAAgAg4gDIAaAAQA8AAAAg6QAAg5hCAAIgUAAg");
	this.shape_6.setTransform(-96.375,46.55);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhvC2QgPgBAAgQIAAlKQAAgPAPAAIBSAAQBcAAAkAnQAcAgABAuQAAA8gqAhQgmAfg/AAIgcgCIAABsQAAAOgQABgAgrgDIAcABQA7AAAAg5QgBg5g8AAIgaAAg");
	this.shape_7.setTransform(-125.35,46.55);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AjkGfQgoAAAAglIAAr2QAAgiAgAAIHbAAQAgAAgDAcIgLBhQgCAdgsAAIkgAAIAACyIEOAAQAkAAAAAgIAABXQAAAjgjAAIkPAAIAAC9IE3AAQAiAAAAAgIAABYQAAAighAAg");
	this.shape_8.setTransform(44.1091,-30.325);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("ACjGfQglAAgRgbIilj+IhKAAIAAD3QAAAighAAIh8AAQgiAAAAgjIAArxQAAgYAIgJQAIgIAYAAIC1AAQDXAABRBaQBBBHAABrQAACriPBIIAAACIDFEYIAHAUQAAAQgUAAgAiCgHIA7AAQCMAAAAiHQAAiBiZAAIguAAg");
	this.shape_9.setTransform(-21.975,-30.325);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AlJHPIgogeQgQgNAAgLQAAgKANgRIBJhhQhIhuAAikQAAjCBmh3QBoh5CwAAQBsAABRAuIBChXQAJgMAKAAIAPAGIA1ApQARALAAAMQAAAIgJALIhDBZQBcB0AAC6QAADHhrB3QhpB1irAAQh+AAhbhAIg9BQQgRAWgKAAQgHAAgUgOgAhqDoQAqAtBKAAQCtAAAAkOQAAhUgQg1gAh4jCQgwBHAACBQAAA0AIAsIEBlUQgngYg1AAQhOAAgvBEg");
	this.shape_10.setTransform(-102.275,-31.175);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("Al5HyQgfgPAAgYIAGgdIAyhtQANgcAVAAIAfALQB9BBCCgBQBQAAA1gtQAzgvAAhJQAAhTg5gyQhBg4h8AAIihAAQg+gBgBhIIAAnEQAAhFBCAAIIuAAQA4AAAAA1IAABtQAAA6g4AAIlsAAIAAC2IALAAQDFAAB6BXQCKBgAAC4QAAC4iEBqQh7BmjDAAQi5AAiYhTg");
	this.shape_11.setTransform(34.1,-152.95);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AlFGtQhbiHAAjdQAAkIBxi1QCJjdEGAAQBtABBfAaQAqAMgHAtIgZB1QgNAtglgMQhqgUgcAAQhyAAg9A/QhABCgQB1QBVgvBjAAQCkAABeBWQBoBcAACuQAACwhrB2QhwCAi6gBQjjAAhuikgAhIAvQg0ATgaAcIAAAVQAAEJCjgBQBEABAog9QAig1AAhNQAAigiIAAQgrABgwARg");
	this.shape_12.setTransform(-48.15,-154.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("ABrI6QgpAAgLgJQgMgJAAgkIAAseIjaB1QgUALgMAAQgZAAgUgnIgshbIgHgaQAAgZAhgSIFVjDQAngVAwAAIBkAAQAuAAAAAsIAAQPQAAA4g8AAg");
	this.shape_13.setTransform(-134.125,-154.025);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("Ag6C+QgPgTgEgZQgEgUAAguIAAiEIgbAAQgMAAgEgEQgEgEAAgPIAAgdQAAgSAQAAIAgAAIAAhIQAAgPAVgDIBBgIQAPAAAAASIAABQIBLAAQARAAAAAPIAAAnQAAAQgRAAIhLAAIAACGQAAAdAHANQAHAPAWAAQAQAAAcgIIAJgCQAIAAACAJIAIAsIAAAHQABAJgLAFQgoASgwAAQg+AAgagfg");
	this.shape_14.setTransform(42.05,-268.35);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AiRB+QgjguAAhJQAAhVAvg0QArguA9AAQA4AAAbAnIADgPQABgOAOAAIA+AAQAQAAAAARIAADsQAAALALAAIAGAAQAOAAAAAOIAAAoQAAAQgRAAIgkAAQg0AAgOggIgCAAQgNAQgdAMQgbANgaAAQhGAAgogzgAg1hFQgTAZgBAsQAABeA/AAQAQAAATgLQAPgJAIgJIAAiEQgbgXgdAAQgbAAgSAVg");
	this.shape_15.setTransform(10.15,-263.925);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AggDxQgZgLgOgPQgBAPgCAFQgEAHgNAAIg1AAQgTAAAAgUIAAm5QAAgTAQgDIBJgJQAOAAAAAPIAACjQAjgdAwAAQAzAAAlAhQA1AwAABgQAABMglAvQgpA0hKAAQgTAAgZgKgAg8AIIAACFQAcAZAbAAQA+AAAAhaQAAhZg8AAQgcAAgdAVg");
	this.shape_16.setTransform(-26.775,-271.375);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AiQB+QgkguAAhJQAAhVAvg0QArguA+AAQA3AAAbAnIACgPQACgOAOAAIA+AAQARAAAAARIAADsQAAALAKAAIAFAAQAPAAAAAOIAAAoQAAAQgRAAIgkAAQg0AAgOggIgBAAQgOAQgdAMQgcANgZAAQhGAAgngzgAg1hFQgTAZAAAsQgBBeBAAAQAQAAASgLQAPgJAHgJIAAiEQgagXgdAAQgbAAgSAVg");
	this.shape_17.setTransform(-65.3,-263.925);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("ABeDvQgVgBgLgPIheiSIgqAAIAACPQAAASgTABIhHAAQgUgBAAgTIAAmyQAAgNAEgFQAFgEAOAAIBoAAQB7gBAvA0QAlApAAA9QAABihSAqIAAABIBxChIAEAMQAAAJgLAAgAhKgEIAiAAQBQAAAAhOQAAhJhXAAIgbAAg");
	this.shape_18.setTransform(-103.35,-271);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-393.1,-367,714.1,446.2);


(lib.Tween15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhdC7QgUAAAAgVIAAlAQAAgWAVAAIA9AAQAVAAABAPIABAXQAVgaASgKQAWgMAfAAIAVADQALACgCAQIgMBGQgCAMgKAAIgYgCQgnAAgcAdIAADeQAAAVgVAAg");
	this.shape.setTransform(132.2232,75.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah7CNQg1g1AAhYQAAhWA2g1QA1g0BVAAQBIAAAsAvQAtAwAABgIAAAJQAAAVgbAAIjQAAQAHAiAcAUQAZAUAkgBQAtAAAwgTIAJgCQAKAAACAKQAPAvAAAMQAAAJgPAHQg3AZhQAAQhYAAg0gzgABDgoQAAgagOgTQgPgUgdAAQgZAAgTATQgRASgFAcIB8AAIAAAAg");
	this.shape_1.setTransform(99.8,75.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("ABRC7QgWAAAAgWIAAjGQABg0gsAAQgpAAghAdIAADeQgBAVgUAAIhHAAQgUAAgBgUIAAlBQABgWAVAAIA9AAQATAAADAQIABAQQA1gqBBAAQB3AAAACFIAADaQgBAWgVAAg");
	this.shape_2.setTransform(61.2,75.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AiOCJQgtgyAAhXQAAhUAyg1QAzg2BYAAQBcAAAxA3QAtAyAABXQAABUgyA0Qg0A3hYAAQhbAAgxg3gAhHgBQAABpBHAAQBIAAAAhoQAAhnhHAAQhIAAAABmg");
	this.shape_3.setTransform(21.55,75.575);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgfEEQgXAAAAgVIAAlCQAAgUAXAAIBCAAQAWAAAAAUIAAFCQAAAVgWAAgAgoihQgTgQAAgZQAAgaASgQQASgPAXAAQAYAAARAPQATAQAAAZQAAAagTAQQgSAPgXAAQgWAAgSgPg");
	this.shape_4.setTransform(-7.025,67.775);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag+DOQgRgUgFgcQgEgUAAg0IAAiOIgeAAQgNAAgEgFQgEgFAAgPIAAggQAAgUARAAIAjAAIAAhOQAAgRAXgDIBHgIQAQAAAAATIAABXIBRAAQATAAAAAQIAAArQAAASgTAAIhRAAIAACQQAAAhAHANQAIARAXAAQASAAAegJIAKgCQAJAAACAKIAJAwIABAHQAAAKgMAFQgsAUg0AAQhCAAgcgig");
	this.shape_5.setTransform(-29.625,70.775);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AidCJQgngyAAhQQAAhcA0g4QAugyBDAAQA9AAAdAqIACgRQABgPARAAIBCAAQATAAgBASIAAEBQABANAKAAIAHAAQAQAAAAAPIAAArQgBARgRAAIgoAAQg4AAgQgiIgCAAQgOARggAOQgeANgbAAQhMAAgrg3gAg5hLQgWAbAAAwQAABmBFAAQARAAAUgMQAQgJAJgLIAAiPQgdgZgfAAQgeAAgTAXg");
	this.shape_6.setTransform(-62.95,75.575);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag+DOQgRgUgFgcQgEgUAAg0IAAiOIgeAAQgNAAgEgFQgEgFAAgPIAAggQAAgUARAAIAjAAIAAhOQAAgRAXgDIBHgIQAQAAAAATIAABXIBRAAQATAAAAAQIAAArQAAASgTAAIhRAAIAACQQAAAhAHANQAIARAXAAQASAAAegJIAKgCQAJAAACAKIAJAwIABAHQAAAKgMAFQgsAUg0AAQhCAAgcgig");
	this.shape_7.setTransform(-96.825,70.775);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AiDCkQgLgEAAgJIACgJIAPgvQAEgNAHAAIAMACQA5AXAqAAQAnAAAAgZQAAgTgjgOIhCgYQgggMgVgZQgXgdAAgmQAAg4AugeQAogaA4AAQBAAAA1AYQALAEAAAIIgCAJIgQA0QgCAJgKAAIgIgBQgxgSgiAAQgQAAgLAIQgIAGAAAJQAAASAbALIBMAeQBDAZAABGQAAA8gvAgQgpAbg9AAQg7AAhCgcg");
	this.shape_8.setTransform(-124.925,75.575);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AmcIgQgigQAAgbIAHggIA3h3QAPgeAWAAIAjALQCHBHCOAAQBYAAA4gyQA5gzAAhQQAAhbg+g2QhHg9iIAAIivAAQhFAAAAhQIAAntQABhLBHAAIJhAAQA9AAAAA7IAAB2QAAA/g9AAImNAAIAADHIAMAAQDWAACFBeQCWBpAADKQABDHiPB1QiHBvjUAAQjLAAimhag");
	this.shape_9.setTransform(102,-30.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AlpJuQgrAAAAglQAAgVAJgPIHiufInLAAQg2AAAAg+IAAh6QAAg7A2AAILiAAQA9AAAAA7IAABvQAAAvgYAtInNOeQgcA3hHAAg");
	this.shape_10.setTransform(4.2,-31.775);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("ADdJuQg7AAAAg1IAAjIIomAAQg6AAAAhEIAAhUQAAg0AYgzIFSqoQAag3A1AAICVAAQA0AAAAAmQAAAMgJASIlFKsIEsAAIAAkOQAAg2A/AAIChAAQA+AAgBA2IAALEQAAA1hAAAg");
	this.shape_11.setTransform(-101.35,-31.775);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AidDuQgmgyAAhQQAAhdAzg3QAugzBDAAQA8ABAeAqIACgRQABgPAQAAIBEAAQARAAABASIAAEBQgBAMALAAIAHAAQAPAAABAPIAAAsQAAARgSAAIgoAAQg4AAgQgiIgBAAQgQARgeANQgeAOgcAAQhNAAgqg3gAg6AZQgVAbAAAwQAABnBEAAQASgBAUgMQAQgIAIgLIAAiQQgcgagfAAQgeAAgUAYgAhBiRQgZgZAAgkQAAgjAZgZQAagaAjAAQAkAAAZAaQAZAZAAAjQAAAkgZAZQgZAagkAAQgjAAgagagAgYjiQgIAIgBAMQABANAIAIQAIAIAMAAQALAAAJgIQAJgIAAgNQAAgMgJgIQgJgJgLAAQgMAAgIAJg");
	this.shape_12.setTransform(121.7,-160.85);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AieEMQgUAAgBgXIAAnhQABgVAVAAIA5AAQAWAAACAQIACAPQAPgSAbgLQAbgMAcAAQBCAAArAuQAvAyAABZQAABbgvA4QgsA0hIAAQgyAAgggeIAACeQAAAXgYAAgAhCiVIAACXQAZAZAhAAQAgAAARgZQAWgcAAgxQAAgwgRgaQgSgbghAAQgkAAgZAbg");
	this.shape_13.setTransform(82.7,-143.125);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("Ag+DOQgRgUgFgcQgEgUAAg0IAAiOIgeAAQgNAAgEgFQgEgFAAgPIAAggQAAgUARAAIAjAAIAAhOQAAgRAXgDIBHgIQAQAAAAATIAABXIBRAAQATAAAAAQIAAArQAAASgTAAIhRAAIAACQQAAAhAHANQAIARAXAAQASAAAegJIAKgCQAJAAACAKIAJAwIABAHQAAAKgMAFQgsAUg0AAQhCAAgcgig");
	this.shape_14.setTransform(32.775,-155.575);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AiyEDQgPgDADgVIAGgvQACgLAEgDQADgCAJAAIAdACQAkAAARgMQAOgJANgbIAKgWIiLlaIgBgIQAAgMANAAIBaAAQASAAAFAPIBGDeIBCjXQAGgWAVAAIBNAAQANAAAAAMIgBAJIiVF/QgZBDgmAbQgoAbhIAAQgWAAgXgEg");
	this.shape_15.setTransform(0.3257,-142.625);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("ABRC7QgVAAgBgWIAAjGQABg0gsAAQgoAAgjAdIAADeQAAAVgUAAIhHAAQgUAAAAgUIAAlBQAAgWAVAAIA9AAQATAAACAQIACAQQA1gqBBAAQB3AAAACFIAADaQgBAWgVAAg");
	this.shape_16.setTransform(-38.15,-151.275);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("Ah8CNQg0g1AAhYQAAhWA1g1QA2g0BVAAQBIAAAsAvQAtAwAABgIAAAJQAAAVgbAAIjQAAQAHAiAbAUQAaAUAjgBQAuAAAxgTIAJgCQAIAAADAKQAPAvAAAMQAAAJgPAHQg4AZhPAAQhYAAg1gzgABDgoQAAgagOgTQgQgUgcAAQgZAAgTATQgSASgDAcIB7AAIAAAAg");
	this.shape_17.setTransform(-76.35,-150.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AioEDQgXAAAAgaIAAnWQAAgVAZAAIB5AAQDFAAAAB/QAAAngVAdQgWAfgmAIIAAABQA2AGAhAhQAiAjAAA3QAACZjTAAgAhKAdIAACMIAvAAQAnAAAVgIQAngPAAgtQAAguglgQQgXgLgwAAgAhKg0IAdAAQArAAASgOQATgOAAgjQAAg2hIAAIglAAg");
	this.shape_18.setTransform(-115.325,-158.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-357,-252.4,714.1,365.7);


(lib.Tween11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A/SIaQAyg2BEgeQBFgfBNAAQBqAABZA4IAAAAQgBhPA5g4QA4g4BPAAQAzAAAqAYQgNgoAAgrQAAhwBRhQQBQhOBxAAQBvAABQBLQBPBLAEBtQAxgwBDAAQAwAAAnAZQgOgpAAgtQAAhwBQhPQBQhQBwAAQBCAAA4AdQAQirB9h0QCAh1CtAAQCsAAB/B0QB+BzARCpQA+gmBIAAQBeAABHA+QBHA+ANBbQAngTAqAAQBJAAA2AzQAdg3A1ggQA3ghBAAAQBfAABDBCQBDBDAABfQAAAogOAnQAcAPAQAbQARAbAAAhIgBAPIBSAAQAuAAAhAhQAgAhAAAuQAAAbgLAXg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-200.3,-53.7,400.70000000000005,107.5);


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag4BAQgYgXAAgpQAAgnAZgYQAYgYAnAAQAgAAAUAWQAVAWAAArIAAAEQAAAKgNAAIheAAQADAPANAKQALAIAQAAQAVAAAWgJIAEgBQAEAAACAFQAGAVAAAGQAAAEgGADQgaAMgkAAQgoAAgYgYgAAfgRQAAgMgHgJQgHgJgNAAQgLAAgIAJQgIAIgCANIA4AAIAAAAg");
	this.shape.setTransform(44.725,-143.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgQB6QgJAAAAgJIAAjcQAAgIAIgBIAjgFQAIAAAAAIIAADhQgBAKgIAAg");
	this.shape_1.setTransform(32.8,-146.95);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag4BAQgYgXAAgpQAAgnAZgYQAYgYAnAAQAgAAAUAWQAVAWAAArIAAAEQAAAKgNAAIheAAQADAPANAKQALAIAQAAQAVAAAWgJIAEgBQAEAAACAFQAGAVAAAGQAAAEgGADQgaAMgkAAQgoAAgYgYgAAfgRQAAgMgHgJQgHgJgNAAQgLAAgIAJQgIAIgCANIA4AAIAAAAg");
	this.shape_2.setTransform(20.975,-143.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAiB6QgEAAgCgBIgBgGIAAheQAAgXgTAAQgTAAgQANIAABoQABAHgIAAIgmAAQgGAAAAgGIAAjeQAAgKAJAAIAkgFQAHAAgBAHIAABTQAVgRAfAAQA2AAAAA8IAABnQgBAHgFAAg");
	this.shape_3.setTransform(3.75,-146.95);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgcBeQgIgJgCgMQgCgKAAgYIAAhAIgNAAQgGAAgCgDQgCgBAAgIIAAgOQAAgIAIAAIAQAAIAAgkQAAgIAKgBIAggFQAHABAAAIIAAApIAlAAQAJgBAAAIIAAATQAAAIgJAAIglAAIAABBQAAAPAEAGQADAIALAAQAIAAAOgEIAEgBQAEAAABAEIAEAXIABACQAAAFgGADQgUAIgXABQgeAAgNgQg");
	this.shape_4.setTransform(-17.975,-145.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag4BAQgYgXAAgpQAAgnAZgYQAYgYAnAAQAgAAAUAWQAVAWAAArIAAAEQAAAKgNAAIheAAQADAPANAKQALAIAQAAQAVAAAWgJIAEgBQAEAAACAFQAGAVAAAGQAAAEgGADQgaAMgkAAQgoAAgYgYgAAfgRQAAgMgHgJQgHgJgNAAQgLAAgIAJQgIAIgCANIA4AAIAAAAg");
	this.shape_5.setTransform(-32.075,-143.075);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag+BjQgTgWAAglQAAglATgZQAUgcAkAAQAWAAAPAOIAAhIQAAgJAIgBIAkgGQAHABAAAHIAADiQAAAKgJAAIgdAAQgIAAAAgHIgBgHQgHAIgMAEQgNAHgKAAQgkAAgTgagAgVAGQgGAMAAATQgBAuAfAAQAQAAAMgMIAAhGQgMgJgPAAQgQAAgJAOg");
	this.shape_6.setTransform(-49.65,-146.75);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgQB6QgIAAgBgJIAAjcQABgIAHgBIAjgFQAIAAAAAIIAADhQAAAKgJAAg");
	this.shape_7.setTransform(-68.35,-146.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgOB3QgKgBAAgJIAAiTQAAgIAKAAIAeAAQAKAAAAAIIAACTQAAAJgKABgAgShJQgJgHAAgMQABgMAIgHQAIgHAKAAQALAAAHAHQAKAHgBAMQABALgKAIQgHAHgLAAQgJAAgJgHg");
	this.shape_8.setTransform(-76,-146.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgcBeQgIgJgCgMQgCgKAAgYIAAhAIgNAAQgGAAgCgDQgCgBAAgIIAAgOQAAgIAIAAIAQAAIAAgkQAAgIAKgBIAggFQAHABAAAIIAAApIAlAAQAJgBAAAIIAAATQAAAIgJAAIglAAIAABBQAAAPAEAGQADAIALAAQAIAAAOgEIAEgBQAEAAABAEIAEAXIABACQAAAFgGADQgUAIgXABQgeAAgNgQg");
	this.shape_9.setTransform(-85.925,-145.25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgsCUQgMgOgEgUQgDgPAAglIAAhmIgVAAQgKAAgCgEQgDgDAAgLIAAgXQAAgOAMAAIAZAAIAAg4QAAgMARgCIAygGQAMAAAAANIAAA/IA6AAQANAAAAAMIAAAeQAAANgNAAIg6AAIAABnQAAAYAFAJQAGAMAQAAQANAAAVgGIAIgCQAGAAABAIIAHAiIAAAFQAAAHgIAEQgfAOgmAAQgvAAgUgYg");
	this.shape_10.setTransform(46.575,-185.875);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhCCGQgPAAAAgPIAAjlQAAgQAPAAIAsAAQAPAAABALIABAQQAOgSANgIQAQgIAXAAIAPACQAHACgBALIgJAyQgBAJgHAAIgRgCQgdAAgUAVIAACfQAAAPgPAAg");
	this.shape_11.setTransform(29.0125,-182.775);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhlBjQghglAAg+QAAg8AkgmQAlgnA/AAQBBAAAjAnQAhAlAAA9QAAA9gkAmQglAng/AAQhBAAgjgngAgzAAQAABKAzAAQAzAAABhKQAAhJgzAAQg0AAAABJg");
	this.shape_12.setTransform(4.2,-182.425);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAwDAQgSAAgHgMIg7hrIgBAAIAABpQAAAOgOAAIg0AAQgPAAAAgOIAAlbQABgNANgCIA5gHQAKAAAAANIAADWIABAAIA7hfQAFgJANAAIA5AAQAJABAAAGQAAAEgCAEIhGBgIBPCCQAEAIAAAFQAAAGgLAAg");
	this.shape_13.setTransform(-21.8,-188.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgsCUQgMgOgEgUQgDgPAAglIAAhmIgVAAQgKAAgCgEQgDgDAAgLIAAgXQAAgOAMAAIAZAAIAAg4QAAgMARgCIAygGQAMAAAAANIAAA/IA6AAQANAAAAAMIAAAeQAAANgNAAIg6AAIAABnQAAAYAFAJQAGAMAQAAQANAAAVgGIAIgCQAGAAABAIIAHAiIAAAFQAAAHgIAEQgfAOgmAAQgvAAgUgYg");
	this.shape_14.setTransform(-57.425,-185.875);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AhmD2QgRAAAAgQIAAlTQAAgPAOgBIDUAAQAPAAgCANIgEArQgCAOgTAAIiBAAIAABPIB5AAQAQAAAAAOIAAAnQAAAPgQAAIh5AAIAABWICLAAQAPAAAAAOIAAAoQAAAOgOAAgAgsijIgHgKIgDgHQAAgEAIgHIA9gxQAIgGAEABQADAAAHAHIAPAVQAEAEAAAFQAAADgHAFIhHAoIgLAFQgFAAgGgIg");
	this.shape_15.setTransform(-80.868,-194);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-115.7,-220.4,190.60000000000002,94.80000000000001);


(lib.shell = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF2524").s().p("EgCLArVQhFgVg6grIhYhBI3+AAIiOxwIuiqkQg9koAAk2QAAplDtoxQDmofGimiQGjmjIejlQIyjuJlAAQJnAAIxDuQIeDlGjGjQGiGiDmIfQDtIxAAJlQAAE2g9EoIuiKkIiORwI3+AAIhYBBQg6ArhFAVQhEAXhIAAQhHAAhEgXgEgm9ADiQAACiApCfIOWKcIBxOEIRbAAIClB5QA/AuBOAAQBPAAA/guIClh5IRbAAIBxuEIOWqcQApidAAikQAAkRhwj5I5aZrIYt+fQgvi9hlioQhlimiSiDMgWJAmNMATogp0Qh6iiimh1Qimh1jCg8MgNiAvbMAJ5gxYQiQhRihgrQiggpimAAQhHgBhFAIMgCBAzWMgCAgzWQhFgIhHABQimAAigApQigAriRBRMAJ5AxYMgNigvbQjCA8imB1QimB1h6CiMAToAp0MgWJgmNQiSCDhlCmQhlCogvC9IYtefI5a5rQhwD6AAEQg");
	this.shape.setTransform(98.8783,99.8825,0.1523,0.1523);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFCD0E").s().p("EgCLArVQhFgVg6grIhYhBI3+AAIiOxwIuiqkQg9koAAk2QAAplDtoxQDmofGimiQGjmjIejlQIyjuJlAAQJnAAIxDuQIeDlGjGjQGiGiDmIfQDtIxAAJlQAAE2g9EoIuiKkIiORwI3+AAIhYBBQg6ArhFAVQhEAXhIAAQhHAAhEgXg");
	this.shape_1.setTransform(98.8783,99.8825,0.1523,0.1523);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Aq6K6QkgkhgBmZQABmYEgkiQEikgGYgBQGZABEhEgQEhEiAAGYQAAGZkhEhQkhEhmZAAQmYAAkikhg");
	this.shape_2.setTransform(98.75,98.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.shell, new cjs.Rectangle(0,0,197.5,197.5), null);


(lib.Q8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C7141D").s().p("AiJAXQAfgXAigWIABAAIC5AAQAOAYAKAVg");
	this.shape.setTransform(149.4748,71.7667,0.9169,0.9169);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#C7141D").s().p("AilAeQgugegegdIHkAAQgUAdgZAeg");
	this.shape_1.setTransform(135.2863,114.9742,0.9169,0.9169);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FEC538").s().p("AjwAeQgSgRgUgWIAKgUIIjAAQgRAfgSAcg");
	this.shape_2.setTransform(118.0262,109.4959,0.9169,0.9169);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C7141D").s().p("AkeAeQARgeARgdIIaAAQgJAdgQAeg");
	this.shape_3.setTransform(136.7991,104.0176,0.9169,0.9169);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FEC538").s().p("AkVAeQAQgaAXghIIEAAQgFAdgMAeg");
	this.shape_4.setTransform(121.9687,98.5393,0.9169,0.9169);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C7141D").s().p("AkFAeQAOgWAcglIHhAAQgBAdgGAeg");
	this.shape_5.setTransform(141.223,93.061,0.9169,0.9169);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FEC538").s().p("AjwAeIAwg7IGvAAQADAfgBAcg");
	this.shape_6.setTransform(126.0465,87.5827,0.9169,0.9169);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#C7141D").s().p("AjXAeQAZgcAfgfIFsAAQAHAaAEAhg");
	this.shape_7.setTransform(145.3031,82.1273,0.9169,0.9169);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FEC538").s().p("Ai1AeQAggeAjgdIETAAQAOAfAHAcg");
	this.shape_8.setTransform(130.2206,76.649,0.9169,0.9169);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#224498").s().p("AhcAfQBFgqBGgTIAPAQQARAUAOAZg");
	this.shape_9.setTransform(151.3773,66.7927,0.9169,0.9169);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#224498").s().p("AhzAUIADgEQAXgWAUgYIC6AAQgSAWgZAYQgTAIgjAEQgWADgXAAQgtAAgtgLg");
	this.shape_10.setTransform(142.7129,120.5315,0.9169,0.9169);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#224498").s().p("AhuAeQASgcARgfIC6AAQgRAfgSAcg");
	this.shape_11.setTransform(150.5522,109.4959,0.9169,0.9169);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#224498").s().p("AhlAeQALgeAGgdIC6AAQgHAhgKAag");
	this.shape_12.setTransform(155.2511,98.5393,0.9169,0.9169);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#224498").s().p("AhcAeQACgcgEgfIC6AAQAEAfgCAcg");
	this.shape_13.setTransform(156.6241,87.5827,0.9169,0.9169);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#224498").s().p("AhSAeQgHgcgOgfIC5AAQAOAdAIAeg");
	this.shape_14.setTransform(154.5406,76.649,0.9169,0.9169);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FEC538").s().p("AhcAfQBFgqBGgTIAOAQQARAUAPAZg");
	this.shape_15.setTransform(134.2548,66.7927,0.9169,0.9169);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("Ah9AXQAkgbAegSIC5AAQgiAVgfAYg");
	this.shape_16.setTransform(131.275,71.7667,0.9169,0.9169);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FEC538").s().p("Ai1gdIFrAAIgvAyQgkAJhAAAQh1AAhjg7g");
	this.shape_17.setTransform(119.6307,120.4754,0.9169,0.9169);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("Ag2AeQgqgagjghIC6AAQAiAhArAag");
	this.shape_18.setTransform(108.0094,114.9742,0.9169,0.9169);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AhtAeQAQgeARgdIC6AAQgRAdgRAeg");
	this.shape_19.setTransform(103.5167,104.0176,0.9169,0.9169);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AhyAeQAPgWAcglIC6AAQgcAlgPAWg");
	this.shape_20.setTransform(110.5537,93.061,0.9169,0.9169);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("Ah5AeQAeghAagaIC6AAQgaAageAhg");
	this.shape_21.setTransform(119.5161,82.1273,0.9169,0.9169);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FEC538").s().p("AAdFKQgsAKgwAAQhWAAhOgfQhmgqhOhdIgGgIIAEgJQAOgcAXgnQAuhOA2hFQBNhiBUhEQBqhVBsgdIAJgCIAHAGIAMAPQAOARAOAUQBBgmBCgSIAJgCIAHAGIAoA1QAqBBAQBKQAYBngfBpQgmCCh5B9IgCADIgEABQgtAOhAAAQgwAAgugKg");
	this.shape_22.setTransform(128.7886,93.5007,0.917,0.917);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#224498").s().p("AgUC8IgdgeQgyAig7AAQhOAAgzg5Qgzg6AGhQQAGhRA7g5QA8g6BOAAQBPAAAyA6QAzA5gGBRQgEA5gkAzIBCBGQgPAMgTAHQgQAGgNAAQgQAAgMgMgAjWhTQgjAhgDAvQgEAuAeAhQAdAhAtAAQAYAAAYgLIglgnIA4g0IAkAnQANgZACgYQAEgvgeghQgdghguAAQgtAAgiAhgABjChQgjgiAEg5QACgYANgWQAQgYAbgQIAGgCIgGgCQghgZAEgxQADgtAlgeQAkgeAxAAQAwAAAgAeQAgAegDAtQgEAwglAaQgCACgFAAQAEAAACACQAZAQALAYQAKAWgBAYQgFA5goAiQgoAgg6AAQg6AAgigggACpAhQgPAOgCAVQgCAVANAOQANANAVAAQAVAAAPgNQAPgOACgVQACgVgNgOQgNgNgVAAQgVAAgPANgAC6hzQgMALgBAQQgBAQAKAKQAKAKASAAQASAAAMgKQAMgLABgPQACgQgKgLQgLgKgSAAQgSAAgMAKg");
	this.shape_23.setTransform(58.7626,106.3502,0.9171,0.9171);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("Aq6K6QkgkhgBmZQABmYEgkiQEikgGYgBQGZABEhEgQEhEiAAGYQAAGZkhEhQkhEhmZAAQmYAAkikhg");
	this.shape_24.setTransform(98.75,98.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Q8, new cjs.Rectangle(0,0,197.5,197.5), null);


(lib.logo_ = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BDD54B").s().p("ApIDaIBEjHQAjhmAegpQBHhdCAAAINEAAIgXBHIs3AAQhXAAguA6QgPAUgOAhQgIATgLAiIhEDIg");
	this.shape.setTransform(98.8051,99.0187,0.8664,0.8664);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BDD54B").s().p("AjHCwIBDjGQAahNAUgZQAogzBPAAICnAAIgYBIIiUAAQgoACgWAaQgNAQgNAlIDQAAIgYBGIjQAAIgrCAg");
	this.shape_1.setTransform(72.9635,102.6794,0.8664,0.8664);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#D1D3D4","#CECFD1","#C4C6C8","#BCBEC0"],[0,0.396,0.792,1],-14.4,-8.8,15.3,12).s().p("AjDCwIAkhqQASg0AigUQAkgVBHAAIA7AAQARAAAPgPQAPgOAHgTQABgVgHgFQgIgGgiAAIimAAIAZhIIDGAAQAxAAAQAXQARAYgRA0QgqB6hdACIhBAAQgpAAgRALQgPAJgJAbIgDAJIDnAAIgZBIg");
	this.shape_2.setTransform(99.2546,102.6794,0.8664,0.8664);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#D1D3D4","#CECFD1","#C4C6C8","#BCBEC0"],[0,0.396,0.792,1],-15.2,-10.9,11.9,8).s().p("AgYCwIAoiAIhcAAQgxAAgQgXQgRgYARgzIAph9IBIAAIguCNQgCAHAEADQADACAIAAIBjAAIAchRIBHAAIgfBRIAtAAIgWBGIgtAAIgnCAg");
	this.shape_3.setTransform(129.1575,102.6794,0.8664,0.8664);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#002F5C").s().p("Aq+FgQg2AAgagpQgZgpAUg5ICMmiQAUg6A0grQA1gsA2gBISNAAQA2AAAcAqQAcApgQA7IhwGjQgQA6gyAqQgyAqg3AAg");
	this.shape_4.setTransform(98.0804,99.1268,0.8664,0.8664);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Aq6K6QkgkhgBmZQABmYEgkiQEikgGYgBQGZABEhEgQEhEiAAGYQAAGZkhEhQkhEhmZAAQmYAAkikhg");
	this.shape_5.setTransform(98.75,98.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_, new cjs.Rectangle(0,0,197.5,197.5), null);


(lib.hjul = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AkoEpQh7h7AAiuQAAitB7h7QB7h7CtAAQCuAAB7B7QB7B7AACtQAACuh7B7Qh7B7iuAAQitAAh7h7g");
	this.shape.setTransform(143.8,143.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AouUtQkChtjHjHQjIjIhtkCQhxkLAAkkQAAkkBxkLQBtkCDIjHQDHjHEChtQELhxEjAAQElAAELBxQECBtDHDHQDHDHBtECQBxELAAEkQAAEkhxELQhtECjHDIQjHDHkCBtQkLBxklAAQkjAAkLhxgAmHufQi1BMiLCMQiMCLhMC1QhQC7AADMQAADNBQC7QBMC1CMCLQCLCMC1BMQC7BQDMAAQDNAAC7hQQC1hMCLiMQCMiLBMi1QBQi7AAjNQAAjMhQi7QhMi1iMiLQiLiMi1hMQi7hQjNAAQjLAAi8BQg");
	this.shape_1.setTransform(143.775,143.775);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.hjul, new cjs.Rectangle(0,0,287.6,287.6), null);


(lib.Tween20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.hjul();
	this.instance.parent = this;
	this.instance.setTransform(126.3,0,0.3654,0.3654,0,0,0,143.8,143.8);

	this.instance_1 = new lib.hjul();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-179.4,0,0.3654,0.3654,0,0,0,143.8,143.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-231.9,-52.5,410.8,105.1);


(lib.Cloud = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_copy
	this.instance = new lib.Tween11("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(104.8,86.65,0.5229,0.5229,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:614.6},149).to({_off:true},1).wait(10));

	// Layer_1
	this.instance_1 = new lib.Tween11("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(199.55,18.15,0.3373,0.3373);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:497.4},159).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0.1,719.3,114.7);


// stage content:
(lib._120x600 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// BIL
	this.instance = new lib.kort();
	this.instance.parent = this;
	this.instance.setTransform(10,296,0.4762,0.4764);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(47).to({scaleY:0.476},0).to({x:-152},10,cjs.Ease.backIn).to({_off:true},1).wait(138).to({_off:false,scaleY:0.4764,x:130},0).to({x:10},12,cjs.Ease.backInOut).wait(92));

	// HJUL
	this.instance_1 = new lib.Tween20("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(65.25,342.05,0.1948,0.1933,0,0,0,0.8,0.8);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(17).to({_off:false},0).to({y:362.05},10,cjs.Ease.backOut).wait(20).to({startPosition:0},0).to({x:-94.75},10,cjs.Ease.backIn).to({_off:true},1).wait(241).to({_off:false,regX:0.6,regY:0.4,scaleX:0.2587,scaleY:0.2571,x:-79.85,y:391.1},0).wait(1));

	// Layer_1
	this.instance_2 = new lib.Tween4("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(59.95,175.95,0.2713,0.2713,0,0,0,-20.4,-173.1);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(266).to({_off:false},0).to({regX:-20.5,regY:-173,scaleX:0.6589,scaleY:0.6589,x:60,y:186,alpha:1},6).wait(27).to({startPosition:0},0).wait(1));

	// LOGO
	this.instance_3 = new lib.Q8();
	this.instance_3.parent = this;
	this.instance_3.setTransform(60.05,-51.95,0.3038,0.3038,0,0,0,98.9,98.6);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(212).to({_off:false},0).to({y:224.95},6).wait(43).to({regX:99.2,regY:99,scaleX:0.2025,scaleY:0.2025,x:60.1,y:320.65},8,cjs.Ease.backIn).wait(31));

	// LOGO_copy_copy
	this.instance_4 = new lib.shell();
	this.instance_4.parent = this;
	this.instance_4.setTransform(60,-41.95,0.4051,0.4051,0,0,0,98.8,98.9);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(232).to({_off:false},0).to({regX:98.9,regY:99.1,scaleX:0.3038,scaleY:0.3038,x:60.05,y:50.05},6).wait(23).to({regX:98.8,regY:99,scaleX:0.2025,scaleY:0.2025,x:60,y:321.05},8,cjs.Ease.backIn).wait(31));

	// LOGO_copy
	this.instance_5 = new lib.logo_();
	this.instance_5.parent = this;
	this.instance_5.setTransform(60.05,-44.8,0.4051,0.4051,0,0,0,98.9,98.7);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(222).to({_off:false},0).to({regY:98.6,scaleX:0.3038,scaleY:0.3038,y:136.95},6).wait(33).to({regX:99,regY:98.8,scaleX:0.2025,scaleY:0.2025,x:40.05,y:321},8,cjs.Ease.backIn).wait(31));

	// Adgang_til
	this.instance_6 = new lib.Tween15("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(352.75,337.95,0.2572,0.2572,0,0,0,0.2,0.2);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(131).to({_off:false},0).to({regX:0,regY:0,scaleX:0.2882,scaleY:0.2882,x:60,y:341.05},8,cjs.Ease.sineOut).wait(53).to({startPosition:0},0).to({x:-90},7,cjs.Ease.sineIn).to({_off:true},1).wait(100));

	// _65
	this.instance_7 = new lib.Tween18("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(209.45,354.3,0.3766,0.3766,0,0,0,0.4,0.2);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(53).to({_off:false},0).to({x:74.45},8,cjs.Ease.sineInOut).wait(66).to({startPosition:0},0).to({x:-85.55},7,cjs.Ease.sineIn).to({_off:true},1).wait(165));

	// Sky1
	this.instance_8 = new lib.Cloud();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-200.4,76.55,1,1,0,0,0,67.5,18.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(300));

	// BG
	this.instance_9 = new lib.bg_120x600();
	this.instance_9.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(300));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-207.9,215.2,652.5,384.8);
// library properties:
lib.properties = {
	id: '97E3EDCDDD704D8D8619AA4718BAC077',
	width: 120,
	height: 600,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/bg_120x600.jpg", id:"bg_120x600"},
		{src:"images/kort.jpg", id:"kort"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['97E3EDCDDD704D8D8619AA4718BAC077'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;