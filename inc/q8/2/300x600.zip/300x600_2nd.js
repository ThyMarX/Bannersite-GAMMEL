(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.bg300x600 = function() {
	this.initialize(img.bg300x600);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.kort = function() {
	this.initialize(img.kort);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,210,129);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABbDpQgUAAgJgPIheiPIgpAAIAACMQAAASgSAAIhGAAQgTAAAAgTIAAmoQAAgNAEgFQAFgEANAAIBnAAQB4AAAtAyQAkAoAAA8QAABghQAoIAAACIBvCdIAEALQAAAJgLAAgAhJgEIAiAAQBOAAAAhMQAAhIhVAAIgbAAg");
	this.shape.setTransform(205.25,191.475);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AiADpQgWAAAAgUIAAmrQAAgSARAAIELAAQASAAgBAPIgGA3QgCAQgYAAIiiAAIAABkICXAAQAUAAAAATIAAAwQAAATgTAAIiYAAIAABrICuAAQAUAAAAASIAAAyQAAASgTAAg");
	this.shape_1.setTransform(167.5558,191.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgoDpQgLAAgCgCQgDgDAAgLIAAlrIh7AAQgTAAAAgUIAAgyQAAgQATAAIFpAAQATAAgDAQIgFA2QgCAQgWAAIh3AAIAAFqQAAALgCADQgDADgKAAg");
	this.shape_2.setTransform(131.2145,191.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhUDpQgRAAAAgPIAAgkQAAgRARAAIAfAAIAAlJIgkAAQgQAAAAgRIAAgkQAAgPAPAAICzAAQARAAAAAOIAAAlQAAARgRAAIgkAAIAAFJIAhAAQARAAAAARIAAAkQAAAPgPAAg");
	this.shape_3.setTransform(99.375,191.475);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ah+DpQgWAAAAgVIAAmqQAAgSATAAIBEAAQAUAAAAAUIAAFjICrAAQATAAAAAUIAAAzQAAATgVAAg");
	this.shape_4.setTransform(72.375,191.475);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgkAmQgRgPAAgWQAAgXAQgPQAQgNAVAAQAWAAAPANQARAPAAAWQAAAXgRAPQgQANgVAAQgUAAgQgNg");
	this.shape_5.setTransform(34.925,210.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("ABbDpQgUAAgJgPIheiPIgpAAIAACMQAAASgSAAIhGAAQgTAAAAgTIAAmoQAAgNAEgFQAFgEANAAIBnAAQB4AAAtAyQAkAoAAA8QAABghQAoIAAACIBvCdIAEALQAAAJgLAAgAhJgEIAhAAQBPAAAAhMQAAhIhVAAIgbAAg");
	this.shape_6.setTransform(10.75,191.475);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AiPDpQgUAAAAgUIAAmpQAAgUAVAAIBoAAQB3AAAuAzQAlAoAAA7QAABPg1AqQgyAohQAAIglgCIAACKQAAASgUAAgAg4gEIAlABQBLAAAAhKQAAhJhPAAIghAAg");
	this.shape_7.setTransform(-27.475,191.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AiADpQgWAAAAgUIAAmrQAAgSARAAIELAAQASAAgBAPIgGA3QgCAQgYAAIiiAAIAABkICXAAQAUAAAAATIAAAwQAAATgTAAIiYAAIAABrICuAAQAUAAAAASIAAAyQAAASgTAAg");
	this.shape_8.setTransform(-76.9442,191.475);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("ABbDpQgUAAgKgPIhciPIgqAAIAACMQAAASgSAAIhGAAQgTAAAAgTIAAmoQAAgNAEgFQAFgEAOAAIBmAAQB4AAAtAyQAlAogBA8QAABghPAoIAAACIBuCdIAEALQAAAJgLAAgAhJgEIAiAAQBOAAAAhMQAAhIhVAAIgbAAg");
	this.shape_9.setTransform(-112.8,191.475);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ai5EFIgWgRQgJgIAAgGQAAgFAHgKIApg2Qgog+AAhdQAAhsA5hDQA7hFBiAAQA9AAAuAbIAlgyQAFgGAFAAIAJADIAeAXQAJAHAAAGQAAAFgFAGIgmAyQA0BBAABoQAABwg8BDQg7BChgAAQhHAAgzgkIgiAtQgKAMgFAAQgEAAgMgHgAg7CDQAYAZApAAQBhAAAAiYQAAgvgJgegAhDhsQgbAoAABHQAAAeAEAYICQi+QgVgOgeAAQgsAAgaAng");
	this.shape_10.setTransform(-156.625,190.975);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AquOKQg5gbAAgsIALg2IBbjFQAZgzAmAAIA5ATQDgB2DuAAQCTAABehTQBfhVAAiFQAAiYhnhaQh3hmjkAAIkkAAQhxAAAAiFIAAs2QAAh+B3AAIP3AAQBmAAAABiIAADFQAABphmAAIqXAAIAAFMIAWAAQFkAADeCdQD7CwAAFPQAAFNjuDCQjgC6ljAAQlSAAkTiXg");
	this.shape_11.setTransform(159.775,37.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("ApQMLQikj2AAmQQAAniDMlJQD6mQHdAAQDGAACtAwQBNAWgOBRIgtDWQgYBQhDgVQjBgkgzAAQjPAAhxByQhyB3gdDXQCZhWC0AAQEsAACrCcQC7CoAAE9QABE+jBDYQjODolRAAQmeAAjIksgAiEBVQhdAjgwAyIAAAnQAAHgEqAAQB7AABHhtQA/hggBiMQAAkjj3AAQhOAAhYAgg");
	this.shape_12.setTransform(-2.65,35.425);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("ADDQNQhLAAgUgQQgWgRAAhCIAA2sImNDWQglAUgWAAQgtAAglhIIhQikIgLgxQAAgsA7ghIJtlkQBGgmBXAAIC3AAQBUAAAABRIAAdiQAABmhuAAg");
	this.shape_13.setTransform(-158.25,35.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhLD4QgUgYgHgiQgEgZAAg9IAAisIgkAAQgQAAgEgFQgFgGAAgTIAAgmQAAgXAVAAIApAAIAAheQAAgUAcgEIBVgLQATAAAAAYIAABpIBiAAQAWAAAAATIAAAzQAAAWgWgBIhiAAIAACuQAAAnAJAQQAKAUAbAAQAWABAkgMIAMgCQAKAAADAMIALA6IABAIQAAAMgPAGQg0AYg/AAQhQABghgpg");
	this.shape_14.setTransform(119.425,-131.35);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ai9CkQgug8AAhfQAAhvA+hDQA3g9BRABQBIAAAkAxIACgTQACgSATAAIBRAAQAVAAAAAWIAAEzQAAAQANAAIAIAAQATAAAAASIAAA0QAAAVgWAAIgvAAQhDgBgUgpIgBAAQgSAWglAPQglAQghAAQhcAAgzhCgAhFhaQgaAgAAA6QAAB5BTAAQAUAAAZgOQASgKAKgNIAAisQgigeglgBQgkABgXAcg");
	this.shape_15.setTransform(78.9,-125.55);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgqE6QgggOgTgTQgBATgDAGQgFAKgQAAIhGAAQgZAAAAgbIAApAQAAgYAVgEIBfgMQASAAAAAUIAADUQAuglA+AAQBEAAAwArQBFA/AAB9QAABjgxA+Qg1BEhgAAQgZAAghgOgAhPAKIAACuQAmAgAjAAQBQAAAAh1QAAh1hOAAQglAAgmAcg");
	this.shape_16.setTransform(31.725,-135.275);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("Ai8CkQgvg8AAhfQAAhvA9hDQA4g9BQABQBJAAAkAxIADgTQABgSATAAIBRAAQAVAAAAAWIAAEzQAAAQAOAAIAHAAQATAAAAASIAAA0QAAAVgWAAIgvAAQhDgBgTgpIgDAAQgRAWgmAPQgkAQghAAQhcAAgyhCgAhFhaQgaAgAAA6QAAB5BSAAQAVAAAYgOQAUgKAJgNIAAisQghgegmgBQgkABgXAcg");
	this.shape_17.setTransform(-17.45,-125.55);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AB6E3QgbAAgNgUIh8i+Ig3AAIAAC5QAAAZgYAAIheAAQgZAAAAgaIAAo1QAAgSAGgGQAGgGASAAICIAAQChAAA8BDQAxA2AABPQAACBhrA2IAAABICTDSIAFAPQAAAMgOAAgAhhgGIAsAAQBpAAAAhkQAAhhhyAAIgjAAg");
	this.shape_18.setTransform(-65.975,-134.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-357,-223.5,714.1,456.1);


(lib.Tween15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AieE+QgjAAAAgjIAAoiQAAgkAkAAIBnAAQAjAAACAZIADAmQAjgrAggSQAlgUA2AAIAjAFQATAEgFAaIgTB4QgEAUgRAAIgogEQhDAAgxAyIAAF7QAAAjgjAAg");
	this.shape.setTransform(231.9181,189.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AjSDvQhahYAAiXQAAiTBbhaQBbhZCSAAQB6AABLBRQBMBRAACjIAAAPQAAAlguAAIliAAQALA6AvAjQAsAgA9AAQBNAABSghIAQgEQAQABAEAQQAYBQAAAUQAAAQgYAMQhfAriGAAQiXAAhZhYgAByhEQAAgtgYgfQgagjgwAAQgsAAggAhQgeAfgGAvIDSAAIAAAAg");
	this.shape_1.setTransform(174.7,190.45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("ACJE+QgkAAAAgmIAAlRQAAhZhJAAQhGAAg6AyIAAF6QgBAkgiAAIh5AAQgiAAAAgiIAAojQgBgkAlAAIBoAAQAgAAAEAbIACAaQBbhHBvAAQDJAAAADiIAAFzQAAAmglAAg");
	this.shape_2.setTransform(107.05,189.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AjxDpQhOhVAAiVQAAiPBVhZQBYhcCWAAQCcgBBSBdQBOBXAACTQAACQhVBYQhYBdiXAAQibAAhShdgAh6gBQAACxB5ABQB7AAAAixQAAivh4AAQh8AAAACug");
	this.shape_3.setTransform(37.525,190.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag1G6QgoAAAAgkIAAokQAAghAoAAIBxAAQAlAAAAAhIAAIkQAAAkglAAgAhEkSQghgbAAgrQAAgtAfgbQAegaApABQAogBAdAaQAgAbAAArQAAAsghAcQgdAagngBQgnAAgegZg");
	this.shape_4.setTransform(-13.025,177.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhrFfQgdgigIgvQgGgkgBhXIAAjzIgyAAQgXAAgHgJQgFgHAAgaIAAg3QAAghAdAAIA6AAIAAiFQAAgdAogEIB4gPQAcAAAAAhIAACUICLAAQAeAAAAAbIAABJQAAAegeAAIiLAAIAAD2QAAA4AMAXQAOAcAnAAQAeAAA0gPIARgEQAOAAAEASIAPBRIABALQAAASgUAJQhKAhhZAAQhxAAgwg5g");
	this.shape_5.setTransform(-53.5,182.325);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AkMDpQhBhVAAiHQAAifBXhfQBPhUBxAAQBoAAAyBHIAEgcQADgaAaABIByAAQAfAAAAAeIAAG1QAAAVATAAIALAAQAaAAAAAaIAABKQAAAdgfAAIhDAAQhfAAgbg7IgCAAQgaAfg1AWQg0AWguAAQiDAAhIhdgAhih/QglAtAABSQAACtB1AAQAeAAAigUQAbgPAOgTIAAj0Qgwgrg2AAQgyAAghApg");
	this.shape_6.setTransform(-112.225,190.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhrFfQgcgigJgvQgGgkAAhXIAAjzIgzAAQgXAAgGgJQgHgHAAgaIAAg3QAAghAdAAIA7AAIAAiFQAAgdAngEIB5gPQAcAAAAAhIAACUICKAAQAgAAAAAbIAABJQAAAeggAAIiKAAIAAD2QAAA4AMAXQAOAcAnAAQAeAAAzgPIASgEQAOAAAEASIAQBRIAAALQABASgVAJQhKAhhYAAQhyAAgwg5g");
	this.shape_7.setTransform(-171.8,182.325);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AjfEXQgTgGABgQIACgQIAahQQAHgWAMAAIAUAFQBgAnBIAAQBEAAAAgsQgBggg7gYIhxgpQg4gUgigrQgngxAAhBQAAheBPg0QBEgsBfAAQBtgBBaApQASAIAAAOIgDAOIgaBYQgFAQgRAAIgOgCQhTgfg6AAQgcAAgSAOQgOALAAAQQAAAdAvATICAAzQByAsABB2QAABnhQA1QhGAuhoAAQhkABhwgwg");
	this.shape_8.setTransform(-221.65,190.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AquOKQg5gbAAgsIALg2IBbjFQAZgzAmAAIA5ATQDgB2DuAAQCTAABehTQBfhVAAiFQAAiYhnhaQh3hmjkAAIkkAAQhxAAAAiFIAAs2QAAh+B3AAIP3AAQBmAAAABiIAADFQAABphmAAIqXAAIAAFMIAWAAQFkAADeCdQD7CwAAFPQAAFNjuDCQjgC6ljAAQlSAAkTiXg");
	this.shape_9.setTransform(169.475,8.825);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("ApbQNQhHAAAAg/QAAghAOgbIMj4IIr9AAQhYAAgBhoIAAjMQABhiBYAAITPAAQBmAAAABiIAAC6QAABOgnBLIsCYIQguBch3AAg");
	this.shape_10.setTransform(7.55,6.85);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AFxQNQhjAAAAhZIAAlNIuVAAQhiAAAAhyIAAiLQAAhXAphUIIyxvQAthcBYAAID6AAQBWAAAAA/QAAAUgOAfIogR1IH1AAIAAnCQAAhbBpAAIEMAAQBnAAAABbIAASbQAABZhsAAg");
	this.shape_11.setTransform(-167.45,6.85);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ai8EdQgvg8AAhfQAAhwA9hCQA4g8BQAAQBJAAAkAyIADgUQABgSATAAIBQAAQAWAAAAAWIAAE0QAAAPAOAAIAHAAQATAAAAASIAAA0QAAAVgWAAIgvAAQhDAAgTgpIgDAAQgRAVgmAPQgkARghAAQhcAAgyhDgAhFAeQgaAgAAA7QAAB6BSAAQAVAAAYgOQAUgLAJgNIAAitQghgegmAAQgkAAgXAcgAhNiuQgfgegBgqQABgrAfgfQAegfAqAAQAqAAAfAfQAfAfAAArQAAAqgfAeQgfAfgqAAQgqAAgegfgAgdkPQgLAKAAAPQAAAOALAKQAKAJAOAAQANAAALgJQALgKAAgOQAAgPgLgKQgLgKgNAAQgOAAgKAKg");
	this.shape_12.setTransform(147.7,-166.525);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ai+FBQgZAAABgbIAApCQAAgZAZAAIBFAAQAaABACASIACASQASgUAggOQAigOAiAAQBOAAA0A2QA5A8AABsQAABsg5BDQg0BAhXgBQg8ABgnglIAAC+QAAAbgcAAgAhQiyIAAC1QAeAdAoAAQAmAAAVgeQAbgiAAg6QAAg6gVgeQgVghgoAAQgsAAgeAhg");
	this.shape_13.setTransform(100.35,-145.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhLD3QgUgXgHgiQgEgYAAg/IAAiqIgkAAQgQAAgEgHQgFgFAAgSIAAgnQAAgXAVAAIApAAIAAheQAAgVAcgDIBVgLQATAAAAAYIAABpIBiAAQAWAAAAATIAAA0QAAAUgWABIhiAAIAACtQAAAnAJAQQAKAVAbAAQAWAAAkgMIAMgCQAKAAADANIALA5IABAIQAAAMgPAHQg0AYg/AAQhQAAghgqg");
	this.shape_14.setTransform(39.275,-160.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AjWE2QgSgEADgYIAIg4QACgOAFgEQADgCALAAIAjACQArAAAVgOQARgMAPgfIANgbIinmfIgCgJQAAgPAQAAIBsAAQAVAAAGASIBUEKIBQkCQAHgaAZAAIBdAAQAPAAAAAPIgCAKIixHMQgfBQguAhQgvAhhXAAQgbAAgbgGg");
	this.shape_15.setTransform(-0.2278,-144.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("ABhDgQgaABAAgbIAAjuQAAg/gzAAQgyAAgoAjIAAEKQAAAagZAAIhVAAQgZAAAAgXIAAmCQAAgaAaAAIBJAAQAXAAADATIACATQBAgzBOAAQCOAAAACgIAAEGQAAAbgagBg");
	this.shape_16.setTransform(-46.975,-155);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AiUCoQhAg9AAhrQAAhoBBg/QBAg/BnAAQBWAAA1A5QA2A5AABzIAAALQAAAaghAAIj6AAQAIApAhAYQAfAXArAAQA3AAA6gXIALgDQALAAADANQARA4AAANQAAAMgRAIQhDAfhfAAQhqAAg/g/gABRgwQAAgfgRgXQgTgZghAAQgfABgXAXQgVAWgFAhICVAAIAAAAg");
	this.shape_17.setTransform(-93.375,-154.45);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AjKE3QgbAAgBggIAAo0QAAgZAeAAICRAAQDtAAAACYQAAAwgZAjQgbAkgtALIAAAAQBBAIAoAnQApAqgBBCQAAC4j9AAgAhYAiIAACpIA3AAQAwgBAYgIQAvgTAAg2QAAg2gsgVQgbgMg7AAgAhYg/IAhAAQA0AAAWgRQAXgRAAgpQAAhBhWAAIgsAAg");
	this.shape_18.setTransform(-140.75,-163.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-357,-252.4,714.1,504.9);


(lib.Tween11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A/SIaQAyg2BEgeQBFgfBNAAQBqAABZA4IAAAAQgBhPA5g4QA4g4BPAAQAzAAAqAYQgNgoAAgrQAAhwBRhQQBQhOBxAAQBvAABQBLQBPBLAEBtQAxgwBDAAQAwAAAnAZQgOgpAAgtQAAhwBQhPQBQhQBwAAQBCAAA4AdQAQirB9h0QCAh1CtAAQCsAAB/B0QB+BzARCpQA+gmBIAAQBeAABHA+QBHA+ANBbQAngTAqAAQBJAAA2AzQAdg3A1ggQA3ghBAAAQBfAABDBCQBDBDAABfQAAAogOAnQAcAPAQAbQARAbAAAhIgBAPIBSAAQAuAAAhAhQAgAhAAAuQAAAbgLAXg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-200.3,-53.7,400.70000000000005,107.5);


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhCBLQgcgbAAgwQAAguAdgcQAdgcAtAAQAmAAAYAaQAYAZAAAzIAAAFQAAALgPAAIhvAAQAEASAPALQANAKATAAQAYAAAagKIAFgBQAFAAACAFQAHAaAAAGQAAAFgHADQgeAOgrAAQgvAAgcgcgAAkgVQAAgOgIgKQgIgLgPAAQgNAAgKALQgKAJgCAPIBCAAIAAAAg");
	this.shape.setTransform(76.625,35.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgSCPQgLAAAAgKIAAkDQAAgKAJgBIAqgFQAIAAAAAJIAAEJQAAALgKAAg");
	this.shape_1.setTransform(62.55,30.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhCBLQgcgbAAgwQAAguAdgcQAdgcAtAAQAmAAAYAaQAYAZAAAzIAAAFQAAALgPAAIhvAAQAEASAPALQANAKATAAQAYAAAagKIAFgBQAFAAACAFQAHAaAAAGQAAAFgHADQgeAOgrAAQgvAAgcgcgAAkgVQAAgOgIgKQgIgLgPAAQgNAAgKALQgKAJgCAPIBCAAIAAAAg");
	this.shape_2.setTransform(48.725,35.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAnCPQgFAAgBgBQgBgBAAgGIAAhuQAAgbgXAAQgXAAgSAOIAAB7QABAIgJAAIgtAAQgHAAAAgHIAAkGQABgKAJgBIArgFQAIAAgBAIIAABiQAYgUAlAAQBAAAAABGIAAB5QgBAIgGAAg");
	this.shape_3.setTransform(28.45,30.575);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AghBuQgJgKgDgPQgCgLAAgcIAAhMIgQAAQgHAAgCgCQgCgDAAgIIAAgRQAAgKAJAAIATAAIAAgqQAAgKAMgBIAmgFQAIAAAAALIAAAvIAsAAQAKAAAAAIIAAAXQAAAJgKAAIgsAAIAABNQAAASAEAHQAFAJAMAAQAJAAAQgFIAGgBQAEAAACAFIAEAaIABAEQAAAFgHADQgXALgcAAQgjAAgPgTg");
	this.shape_4.setTransform(2.925,32.575);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhCBLQgcgbAAgwQAAguAdgcQAdgcAtAAQAmAAAYAaQAYAZAAAzIAAAFQAAALgPAAIhvAAQAEASAPALQANAKATAAQAYAAAagKIAFgBQAFAAACAFQAHAaAAAGQAAAFgHADQgeAOgrAAQgvAAgcgcgAAkgVQAAgOgIgKQgIgLgPAAQgNAAgKALQgKAJgCAPIBCAAIAAAAg");
	this.shape_5.setTransform(-13.625,35.125);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhKB1QgVgbAAgrQAAgsAVgdQAZghApAAQAbAAARAQIAAhUQAAgLAKgCIAqgFQAIAAAAAIIAAELQAAALgLAAIghAAQgKAAgBgIIAAgJQgIAJgOAGQgQAHgMAAQgqAAgXgdgAgZAHQgIAPAAAVQAAA2AkAAQAUAAANgOIAAhSQgNgMgSAAQgTAAgLASg");
	this.shape_6.setTransform(-34.275,30.825);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgSCPQgLAAAAgKIAAkDQAAgKAKgBIAogFQAJAAAAAJIAAEJQAAALgLAAg");
	this.shape_7.setTransform(-56.3,30.575);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgQCLQgMAAAAgLIAAisQAAgKAMAAIAjAAQALAAAAAKIAACsQAAALgLAAgAgVhWQgKgIAAgOQAAgOAKgIQAJgIAMAAQANAAAJAIQAKAIAAAOQAAANgKAJQgJAIgNAAQgLAAgKgIg");
	this.shape_8.setTransform(-65.275,30.975);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AghBuQgJgKgDgPQgCgLAAgcIAAhMIgQAAQgHAAgCgCQgCgDAAgIIAAgRQAAgKAJAAIATAAIAAgqQAAgKAMgBIAmgFQAIAAAAALIAAAvIAsAAQAKAAAAAIIAAAXQAAAJgKAAIgsAAIAABNQAAASAEAHQAFAJAMAAQAJAAAQgFIAGgBQAEAAACAFIAEAaIABAEQAAAFgHADQgXALgcAAQgjAAgPgTg");
	this.shape_9.setTransform(-76.975,32.575);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ag1CuQgOgRgEgXQgDgSAAgrIAAh4IgZAAQgMAAgDgEQgDgEAAgNIAAgbQAAgQAPAAIAdAAIAAhDQAAgOATgCIA8gIQAOAAgBARIAABKIBFAAQAPAAABANIAAAkQgBAPgPAAIhFAAIAAB6QABAbAFALQAHAOAUAAQAPAAAZgHIAIgCQAIAAABAJIAIAoIABAGQAAAIgLAFQgkARgsAAQg4AAgYgdg");
	this.shape_10.setTransform(78.8,-15.175);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhOCeQgRAAAAgSIAAkOQAAgSASAAIAzAAQARAAABANIABASQASgVAPgJQASgKAbAAIASADQAJACgCANIgKA7QgCAKgIAAIgUgCQghAAgYAZIAAC7QAAASgSAAg");
	this.shape_11.setTransform(58.126,-11.525);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ah4BzQglgqgBhJQABhHAqgtQArgtBKAAQBNAAApAuQAmArAABIQAABHgpAsQgtAvhKAAQhMAAgqgvgAg8gBQAABZA8AAQA9AAgBhYQABhWg8gBQg9ABAABVg");
	this.shape_12.setTransform(29,-11.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AA4DiQgVAAgIgPIhFh+IgBAAIAAB8QAAARgRAAIg9AAQgRAAAAgRIAAmYQAAgPAPgDIBCgIQANAAABAQIAAD7IABAAIBFhwQAGgJAOAAIBEAAQALAAAAAIQAAAEgDAEIhSBwIBeCbQAEAJAAAFQAAAIgNAAg");
	this.shape_13.setTransform(-1.6,-18.35);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("Ag0CuQgOgRgFgXQgDgSAAgrIAAh4IgZAAQgLAAgEgEQgDgEAAgNIAAgbQAAgQAOAAIAdAAIAAhDQABgOATgCIA7gIQAOAAABARIAABKIBEAAQAPAAAAANIAAAkQAAAPgPAAIhEAAIAAB6QAAAbAFALQAIAOASAAQAQAAAZgHIAJgCQAGAAADAJIAHAoIABAGQAAAIgKAFQglARgsAAQg4AAgXgdg");
	this.shape_14.setTransform(-43.45,-15.175);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ah4EiQgVAAAAgUIAAmPQAAgRARAAID6AAQAQAAgBAOIgGAzQgBAQgXAAIiXAAIAABdICOAAQASAAAAARIAAAuQAAASgSAAIiOAAIAABkICjAAQASAAAAAQIAAAvQAAASgRAAgAg0jAIgJgMIgDgIQAAgFAJgIIBJg5QAJgHAEAAQAEAAAIAKIASAXQAEAGAAAFQAAAEgIAFIhTAwIgNAFQgHAAgGgJg");
	this.shape_15.setTransform(-70.9971,-24.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-112,-55.7,224,111.4);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhCBLQgcgbAAgwQAAguAdgcQAdgcAtAAQAmAAAYAaQAYAZAAAzIAAAFQAAALgPAAIhvAAQAEASAPALQANAKATAAQAYAAAagKIAFgBQAFAAACAFQAHAaAAAGQAAAFgHADQgeAOgrAAQgvAAgcgcgAAkgVQAAgOgIgKQgIgLgPAAQgNAAgKALQgKAJgCAPIBCAAIAAAAg");
	this.shape.setTransform(76.625,35.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgSCPQgLAAAAgKIAAkDQAAgKAJgBIAqgFQAIAAAAAJIAAEJQAAALgKAAg");
	this.shape_1.setTransform(62.55,30.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhCBLQgcgbAAgwQAAguAdgcQAdgcAtAAQAmAAAYAaQAYAZAAAzIAAAFQAAALgPAAIhvAAQAEASAPALQANAKATAAQAYAAAagKIAFgBQAFAAACAFQAHAaAAAGQAAAFgHADQgeAOgrAAQgvAAgcgcgAAkgVQAAgOgIgKQgIgLgPAAQgNAAgKALQgKAJgCAPIBCAAIAAAAg");
	this.shape_2.setTransform(48.725,35.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAnCPQgFAAgBgBQgBgBAAgGIAAhuQAAgbgXAAQgXAAgSAOIAAB7QABAIgJAAIgtAAQgHAAAAgHIAAkGQABgKAJgBIArgFQAIAAgBAIIAABiQAYgUAlAAQBAAAAABGIAAB5QgBAIgGAAg");
	this.shape_3.setTransform(28.45,30.575);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AghBuQgJgKgDgPQgCgLAAgcIAAhMIgQAAQgHAAgCgCQgCgDAAgIIAAgRQAAgKAJAAIATAAIAAgqQAAgKAMgBIAmgFQAIAAAAALIAAAvIAsAAQAKAAAAAIIAAAXQAAAJgKAAIgsAAIAABNQAAASAEAHQAFAJAMAAQAJAAAQgFIAGgBQAEAAACAFIAEAaIABAEQAAAFgHADQgXALgcAAQgjAAgPgTg");
	this.shape_4.setTransform(2.925,32.575);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhCBLQgcgbAAgwQAAguAdgcQAdgcAtAAQAmAAAYAaQAYAZAAAzIAAAFQAAALgPAAIhvAAQAEASAPALQANAKATAAQAYAAAagKIAFgBQAFAAACAFQAHAaAAAGQAAAFgHADQgeAOgrAAQgvAAgcgcgAAkgVQAAgOgIgKQgIgLgPAAQgNAAgKALQgKAJgCAPIBCAAIAAAAg");
	this.shape_5.setTransform(-13.625,35.125);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhKB1QgVgbAAgrQAAgsAVgdQAZghApAAQAbAAARAQIAAhUQAAgLAKgCIAqgFQAIAAAAAIIAAELQAAALgLAAIghAAQgKAAgBgIIAAgJQgIAJgOAGQgQAHgMAAQgqAAgXgdgAgZAHQgIAPAAAVQAAA2AkAAQAUAAANgOIAAhSQgNgMgSAAQgTAAgLASg");
	this.shape_6.setTransform(-34.275,30.825);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgSCPQgLAAAAgKIAAkDQAAgKAKgBIAogFQAJAAAAAJIAAEJQAAALgLAAg");
	this.shape_7.setTransform(-56.3,30.575);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgQCLQgMAAAAgLIAAisQAAgKAMAAIAjAAQALAAAAAKIAACsQAAALgLAAgAgVhWQgKgIAAgOQAAgOAKgIQAJgIAMAAQANAAAJAIQAKAIAAAOQAAANgKAJQgJAIgNAAQgLAAgKgIg");
	this.shape_8.setTransform(-65.275,30.975);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AghBuQgJgKgDgPQgCgLAAgcIAAhMIgQAAQgHAAgCgCQgCgDAAgIIAAgRQAAgKAJAAIATAAIAAgqQAAgKAMgBIAmgFQAIAAAAALIAAAvIAsAAQAKAAAAAIIAAAXQAAAJgKAAIgsAAIAABNQAAASAEAHQAFAJAMAAQAJAAAQgFIAGgBQAEAAACAFIAEAaIABAEQAAAFgHADQgXALgcAAQgjAAgPgTg");
	this.shape_9.setTransform(-76.975,32.575);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ag1CuQgOgRgEgXQgDgSAAgrIAAh4IgZAAQgMAAgDgEQgDgEAAgNIAAgbQAAgQAPAAIAdAAIAAhDQAAgOATgCIA8gIQAOAAgBARIAABKIBFAAQAPAAABANIAAAkQgBAPgPAAIhFAAIAAB6QABAbAFALQAHAOAUAAQAPAAAZgHIAIgCQAIAAABAJIAIAoIABAGQAAAIgLAFQgkARgsAAQg4AAgYgdg");
	this.shape_10.setTransform(78.8,-15.175);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhOCeQgRAAAAgSIAAkOQAAgSASAAIAzAAQARAAABANIABASQASgVAPgJQASgKAbAAIASADQAJACgCANIgKA7QgCAKgIAAIgUgCQghAAgYAZIAAC7QAAASgSAAg");
	this.shape_11.setTransform(58.126,-11.525);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ah4BzQglgqgBhJQABhHAqgtQArgtBKAAQBNAAApAuQAmArAABIQAABHgpAsQgtAvhKAAQhMAAgqgvgAg8gBQAABZA8AAQA9AAgBhYQABhWg8gBQg9ABAABVg");
	this.shape_12.setTransform(29,-11.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AA4DiQgVAAgIgPIhFh+IgBAAIAAB8QAAARgRAAIg9AAQgRAAAAgRIAAmYQAAgPAPgDIBCgIQANAAABAQIAAD7IABAAIBFhwQAGgJAOAAIBEAAQALAAAAAIQAAAEgDAEIhSBwIBeCbQAEAJAAAFQAAAIgNAAg");
	this.shape_13.setTransform(-1.6,-18.35);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("Ag0CuQgOgRgFgXQgDgSAAgrIAAh4IgZAAQgLAAgEgEQgDgEAAgNIAAgbQAAgQAOAAIAdAAIAAhDQABgOATgCIA7gIQAOAAABARIAABKIBEAAQAPAAAAANIAAAkQAAAPgPAAIhEAAIAAB6QAAAbAFALQAIAOASAAQAQAAAZgHIAJgCQAGAAADAJIAHAoIABAGQAAAIgKAFQglARgsAAQg4AAgXgdg");
	this.shape_14.setTransform(-43.45,-15.175);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ah4EiQgVAAAAgUIAAmPQAAgRARAAID6AAQAQAAgBAOIgGAzQgBAQgXAAIiXAAIAABdICOAAQASAAAAARIAAAuQAAASgSAAIiOAAIAABkICjAAQASAAAAAQIAAAvQAAASgRAAgAg0jAIgJgMIgDgIQAAgFAJgIIBJg5QAJgHAEAAQAEAAAIAKIASAXQAEAGAAAFQAAAEgIAFIhTAwIgNAFQgHAAgGgJg");
	this.shape_15.setTransform(-70.9971,-24.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-112,-55.7,224,111.4);


(lib.shell = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF2524").s().p("EgCLArVQhFgVg6grIhYhBI3+AAIiOxwIuiqkQg9koAAk2QAAplDtoxQDmofGimiQGjmjIejlQIyjuJlAAQJnAAIxDuQIeDlGjGjQGiGiDmIfQDtIxAAJlQAAE2g9EoIuiKkIiORwI3+AAIhYBBQg6ArhFAVQhEAXhIAAQhHAAhEgXgEgm9ADiQAACiApCfIOWKcIBxOEIRbAAIClB5QA/AuBOAAQBPAAA/guIClh5IRbAAIBxuEIOWqcQApidAAikQAAkRhwj5I5aZrIYt+fQgvi9hlioQhlimiSiDMgWJAmNMATogp0Qh6iiimh1Qimh1jCg8MgNiAvbMAJ5gxYQiQhRihgrQiggpimAAQhHgBhFAIMgCBAzWMgCAgzWQhFgIhHABQimAAigApQigAriRBRMAJ5AxYMgNigvbQjCA8imB1QimB1h6CiMAToAp0MgWJgmNQiSCDhlCmQhlCogvC9IYtefI5a5rQhwD6AAEQg");
	this.shape.setTransform(98.8783,99.8825,0.1523,0.1523);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFCD0E").s().p("EgCLArVQhFgVg6grIhYhBI3+AAIiOxwIuiqkQg9koAAk2QAAplDtoxQDmofGimiQGjmjIejlQIyjuJlAAQJnAAIxDuQIeDlGjGjQGiGiDmIfQDtIxAAJlQAAE2g9EoIuiKkIiORwI3+AAIhYBBQg6ArhFAVQhEAXhIAAQhHAAhEgXg");
	this.shape_1.setTransform(98.8783,99.8825,0.1523,0.1523);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Aq6K6QkgkhgBmZQABmYEgkiQEikgGYgBQGZABEhEgQEhEiAAGYQAAGZkhEhQkhEhmZAAQmYAAkikhg");
	this.shape_2.setTransform(98.75,98.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.shell, new cjs.Rectangle(0,0,197.5,197.5), null);


(lib.Q8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C7141D").s().p("AiJAXQAfgXAigWIABAAIC5AAQAOAYAKAVg");
	this.shape.setTransform(149.4748,71.7667,0.9169,0.9169);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#C7141D").s().p("AilAeQgugegegdIHkAAQgUAdgZAeg");
	this.shape_1.setTransform(135.2863,114.9742,0.9169,0.9169);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FEC538").s().p("AjwAeQgSgRgUgWIAKgUIIjAAQgRAfgSAcg");
	this.shape_2.setTransform(118.0262,109.4959,0.9169,0.9169);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C7141D").s().p("AkeAeQARgeARgdIIaAAQgJAdgQAeg");
	this.shape_3.setTransform(136.7991,104.0176,0.9169,0.9169);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FEC538").s().p("AkVAeQAQgaAXghIIEAAQgFAdgMAeg");
	this.shape_4.setTransform(121.9687,98.5393,0.9169,0.9169);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C7141D").s().p("AkFAeQAOgWAcglIHhAAQgBAdgGAeg");
	this.shape_5.setTransform(141.223,93.061,0.9169,0.9169);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FEC538").s().p("AjwAeIAwg7IGvAAQADAfgBAcg");
	this.shape_6.setTransform(126.0465,87.5827,0.9169,0.9169);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#C7141D").s().p("AjXAeQAZgcAfgfIFsAAQAHAaAEAhg");
	this.shape_7.setTransform(145.3031,82.1273,0.9169,0.9169);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FEC538").s().p("Ai1AeQAggeAjgdIETAAQAOAfAHAcg");
	this.shape_8.setTransform(130.2206,76.649,0.9169,0.9169);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#224498").s().p("AhcAfQBFgqBGgTIAPAQQARAUAOAZg");
	this.shape_9.setTransform(151.3773,66.7927,0.9169,0.9169);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#224498").s().p("AhzAUIADgEQAXgWAUgYIC6AAQgSAWgZAYQgTAIgjAEQgWADgXAAQgtAAgtgLg");
	this.shape_10.setTransform(142.7129,120.5315,0.9169,0.9169);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#224498").s().p("AhuAeQASgcARgfIC6AAQgRAfgSAcg");
	this.shape_11.setTransform(150.5522,109.4959,0.9169,0.9169);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#224498").s().p("AhlAeQALgeAGgdIC6AAQgHAhgKAag");
	this.shape_12.setTransform(155.2511,98.5393,0.9169,0.9169);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#224498").s().p("AhcAeQACgcgEgfIC6AAQAEAfgCAcg");
	this.shape_13.setTransform(156.6241,87.5827,0.9169,0.9169);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#224498").s().p("AhSAeQgHgcgOgfIC5AAQAOAdAIAeg");
	this.shape_14.setTransform(154.5406,76.649,0.9169,0.9169);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FEC538").s().p("AhcAfQBFgqBGgTIAOAQQARAUAPAZg");
	this.shape_15.setTransform(134.2548,66.7927,0.9169,0.9169);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("Ah9AXQAkgbAegSIC5AAQgiAVgfAYg");
	this.shape_16.setTransform(131.275,71.7667,0.9169,0.9169);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FEC538").s().p("Ai1gdIFrAAIgvAyQgkAJhAAAQh1AAhjg7g");
	this.shape_17.setTransform(119.6307,120.4754,0.9169,0.9169);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("Ag2AeQgqgagjghIC6AAQAiAhArAag");
	this.shape_18.setTransform(108.0094,114.9742,0.9169,0.9169);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AhtAeQAQgeARgdIC6AAQgRAdgRAeg");
	this.shape_19.setTransform(103.5167,104.0176,0.9169,0.9169);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AhyAeQAPgWAcglIC6AAQgcAlgPAWg");
	this.shape_20.setTransform(110.5537,93.061,0.9169,0.9169);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("Ah5AeQAeghAagaIC6AAQgaAageAhg");
	this.shape_21.setTransform(119.5161,82.1273,0.9169,0.9169);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FEC538").s().p("AAdFKQgsAKgwAAQhWAAhOgfQhmgqhOhdIgGgIIAEgJQAOgcAXgnQAuhOA2hFQBNhiBUhEQBqhVBsgdIAJgCIAHAGIAMAPQAOARAOAUQBBgmBCgSIAJgCIAHAGIAoA1QAqBBAQBKQAYBngfBpQgmCCh5B9IgCADIgEABQgtAOhAAAQgwAAgugKg");
	this.shape_22.setTransform(128.7886,93.5007,0.917,0.917);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#224498").s().p("AgUC8IgdgeQgyAig7AAQhOAAgzg5Qgzg6AGhQQAGhRA7g5QA8g6BOAAQBPAAAyA6QAzA5gGBRQgEA5gkAzIBCBGQgPAMgTAHQgQAGgNAAQgQAAgMgMgAjWhTQgjAhgDAvQgEAuAeAhQAdAhAtAAQAYAAAYgLIglgnIA4g0IAkAnQANgZACgYQAEgvgeghQgdghguAAQgtAAgiAhgABjChQgjgiAEg5QACgYANgWQAQgYAbgQIAGgCIgGgCQghgZAEgxQADgtAlgeQAkgeAxAAQAwAAAgAeQAgAegDAtQgEAwglAaQgCACgFAAQAEAAACACQAZAQALAYQAKAWgBAYQgFA5goAiQgoAgg6AAQg6AAgigggACpAhQgPAOgCAVQgCAVANAOQANANAVAAQAVAAAPgNQAPgOACgVQACgVgNgOQgNgNgVAAQgVAAgPANgAC6hzQgMALgBAQQgBAQAKAKQAKAKASAAQASAAAMgKQAMgLABgPQACgQgKgLQgLgKgSAAQgSAAgMAKg");
	this.shape_23.setTransform(58.7626,106.3502,0.9171,0.9171);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("Aq6K6QkgkhgBmZQABmYEgkiQEikgGYgBQGZABEhEgQEhEiAAGYQAAGZkhEhQkhEhmZAAQmYAAkikhg");
	this.shape_24.setTransform(98.75,98.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Q8, new cjs.Rectangle(0,0,197.5,197.5), null);


(lib.logo_ = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BDD54B").s().p("ApIDaIBEjHQAjhmAegpQBHhdCAAAINEAAIgXBHIs3AAQhXAAguA6QgPAUgOAhQgIATgLAiIhEDIg");
	this.shape.setTransform(98.8026,99.0176,0.8664,0.8664);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BDD54B").s().p("AjHCwIBDjGQAahNAUgZQAogzBPAAICnAAIgYBIIiUAAQgoACgWAaQgNAQgNAlIDQAAIgYBGIjQAAIgrCAg");
	this.shape_1.setTransform(72.962,102.6782,0.8664,0.8664);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#D1D3D4","#CECFD1","#C4C6C8","#BCBEC0"],[0,0.396,0.792,1],-14.4,-8.8,15.3,12).s().p("AjDCwIAkhqQASg0AigUQAkgVBHAAIA7AAQARAAAPgPQAPgOAHgTQABgVgHgFQgIgGgiAAIimAAIAZhIIDGAAQAxAAAQAXQARAYgRA0QgqB6hdACIhBAAQgpAAgRALQgPAJgJAbIgDAJIDnAAIgZBIg");
	this.shape_2.setTransform(99.2522,102.6782,0.8664,0.8664);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#D1D3D4","#CECFD1","#C4C6C8","#BCBEC0"],[0,0.396,0.792,1],-15.2,-10.9,11.9,8).s().p("AgYCwIAoiAIhcAAQgxAAgQgXQgRgYARgzIAph9IBIAAIguCNQgCAHAEADQADACAIAAIBjAAIAchRIBHAAIgfBRIAtAAIgWBGIgtAAIgnCAg");
	this.shape_3.setTransform(129.154,102.6782,0.8664,0.8664);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#002F5C").s().p("Aq+FgQg2AAgagpQgZgpAUg5ICMmiQAUg6A0grQA1gsA2gBISNAAQA2AAAcAqQAcApgQA7IhwGjQgQA6gyAqQgyAqg3AAg");
	this.shape_4.setTransform(98.078,99.1257,0.8664,0.8664);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Aq6K6QkgkhgBmZQABmYEgkiQEikgGYgBQGZABEhEgQEhEiAAGYQAAGZkhEhQkhEhmZAAQmYAAkikhg");
	this.shape_5.setTransform(98.75,98.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_, new cjs.Rectangle(0,0,197.5,197.5), null);


(lib.hjul = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AkoEpQh7h7AAiuQAAitB7h7QB7h7CtAAQCuAAB7B7QB7B7AACtQAACuh7B7Qh7B7iuAAQitAAh7h7g");
	this.shape.setTransform(143.8,143.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AouUtQkChtjHjHQjIjIhtkCQhxkLAAkkQAAkkBxkLQBtkCDIjHQDHjHEChtQELhxEjAAQElAAELBxQECBtDHDHQDHDHBtECQBxELAAEkQAAEkhxELQhtECjHDIQjHDHkCBtQkLBxklAAQkjAAkLhxgAmHufQi1BMiLCMQiMCLhMC1QhQC7AADMQAADNBQC7QBMC1CMCLQCLCMC1BMQC7BQDMAAQDNAAC7hQQC1hMCLiMQCMiLBMi1QBQi7AAjNQAAjMhQi7QhMi1iMiLQiLiMi1hMQi7hQjNAAQjLAAi8BQg");
	this.shape_1.setTransform(143.775,143.775);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.hjul, new cjs.Rectangle(0,0,287.6,287.6), null);


(lib.Tween21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.hjul();
	this.instance.parent = this;
	this.instance.setTransform(179.4,0,0.3654,0.3654,0,0,0,143.8,143.8);

	this.instance_1 = new lib.hjul();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-179.4,0,0.3654,0.3654,0,0,0,143.8,143.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-231.9,-52.5,463.9,105.1);


(lib.Tween20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.hjul();
	this.instance.parent = this;
	this.instance.setTransform(179.4,0,0.3654,0.3654,0,0,0,143.8,143.8);

	this.instance_1 = new lib.hjul();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-179.4,0,0.3654,0.3654,0,0,0,143.8,143.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-231.9,-52.5,463.9,105.1);


(lib.Cloud = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_copy
	this.instance = new lib.Tween11("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(159.4,86.65,0.5229,0.5229,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:682.6},125).to({_off:true},1).wait(29));

	// Layer_1
	this.instance_1 = new lib.Tween11("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(104.55,18.15,0.3373,0.3373);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:645.35},154).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(37,0.1,750.3,114.7);


// stage content:
(lib._300x600_2nd = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// BIL
	this.instance = new lib.kort();
	this.instance.parent = this;
	this.instance.setTransform(45,276);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(47).to({x:-223,y:277},10,cjs.Ease.backIn).wait(100).to({x:300,y:276},0).wait(39).to({x:320},0).to({x:45},12,cjs.Ease.backInOut).wait(102));

	// Layer_1
	this.instance_1 = new lib.Tween3("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(150,140.55,0.1562,0.1562);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.instance_2 = new lib.Tween4("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(150,160.55);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(266).to({_off:false},0).to({_off:true,scaleX:1,scaleY:1,y:160.55,alpha:1},4).wait(40));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(266).to({_off:false},4).wait(30).to({startPosition:0},0).to({scaleX:0.5804,scaleY:0.5804,y:341.2},9,cjs.Ease.backIn).wait(1));

	// HJUL
	this.instance_3 = new lib.Tween20("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(150.15,375.1,0.3448,0.3432,0,0,0,0.5,0.3);
	this.instance_3._off = true;

	this.instance_4 = new lib.Tween21("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(150.05,415.05,0.3449,0.3444,0,0,0,0.1,0.1);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(17).to({_off:false},0).to({_off:true,regX:0.1,regY:0.1,scaleX:0.3449,scaleY:0.3444,x:150.05,y:415.05},10,cjs.Ease.backOut).wait(283));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(17).to({_off:false},10,cjs.Ease.backOut).wait(20).to({startPosition:0},0).to({x:-109.95},10,cjs.Ease.backIn).wait(252).to({startPosition:0},0).wait(1));

	// LOGO
	this.instance_5 = new lib.Q8();
	this.instance_5.parent = this;
	this.instance_5.setTransform(60.05,-41.9,0.4051,0.4051,0,0,0,98.9,98.7);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(212).to({_off:false},0).to({y:200},6).wait(43).to({regY:98.9,scaleX:0.3038,scaleY:0.3038,x:150,y:339.8},8,cjs.Ease.backIn).wait(41));

	// LOGO_copy_copy
	this.instance_6 = new lib.shell();
	this.instance_6.parent = this;
	this.instance_6.setTransform(240,-39.95,0.4051,0.4051,0,0,0,98.8,98.9);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(232).to({_off:false},0).to({y:200.05},6).wait(23).to({x:150,y:340.05},8,cjs.Ease.backIn).wait(41));

	// LOGO_copy
	this.instance_7 = new lib.logo_();
	this.instance_7.parent = this;
	this.instance_7.setTransform(150.05,-44.8,0.4051,0.4051,0,0,0,98.9,98.7);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(222).to({_off:false},0).to({y:200},6).wait(33).to({y:340},8,cjs.Ease.backIn).wait(41));

	// Adgang_til
	this.instance_8 = new lib.Tween15("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(430.05,345.65,0.4736,0.4736);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(131).to({_off:false},0).to({x:150,y:335.65},8,cjs.Ease.sineOut).wait(53).to({startPosition:0},0).to({x:-124.2},7,cjs.Ease.sineIn).to({_off:true},14).wait(97));

	// _65
	this.instance_9 = new lib.Tween18("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(478.15,332,0.4976,0.4976,0,0,0,0.1,0);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(53).to({_off:false},0).to({x:142.05},8,cjs.Ease.sineInOut).wait(66).to({startPosition:0},0).to({x:-140.8},7,cjs.Ease.sineIn).to({_off:true},1).wait(175));

	// Sky1
	this.instance_10 = new lib.Cloud();
	this.instance_10.parent = this;
	this.instance_10.setTransform(-200.4,76.55,1,1,0,0,0,67.5,18.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(310));

	// BG
	this.instance_11 = new lib.bg300x600();
	this.instance_11.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(310));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-168.5,215.2,824.2,384.8);
// library properties:
lib.properties = {
	id: '97E3EDCDDD704D8D8619AA4718BAC077',
	width: 300,
	height: 600,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/bg300x600.jpg", id:"bg300x600"},
		{src:"images/kort.jpg", id:"kort"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['97E3EDCDDD704D8D8619AA4718BAC077'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;