(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.bg_930x180 = function() {
	this.initialize(img.bg_930x180);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,930,180);


(lib.kort = function() {
	this.initialize(img.kort);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,210,129);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgtA0QgTgTAAghQAAgfAUgTQATgUAfAAQAbAAAQASQAQARAAAjIAAADQAAAIgKAAIhMAAQADANAKAHQAJAHANAAQARAAARgHIAEgBQADAAABAEQAGARAAAEQAAAEgGACQgUAKgeAAQgfAAgUgTgAAZgOQAAgKgFgGQgGgIgKAAQgJAAgHAHQgHAHgBAKIAtAAIAAAAg");
	this.shape.setTransform(50.875,22.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgMBiQgIABAAgIIAAixQAAgHAHgBIAcgDQAFAAAAAGIAAC2QABAIgIgBg");
	this.shape_1.setTransform(41.6,18.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgtA0QgTgTAAghQAAgfAUgTQATgUAfAAQAbAAAQASQAQARAAAjIAAADQAAAIgKAAIhMAAQADANAKAHQAJAHANAAQARAAARgHIAEgBQADAAABAEQAGARAAAEQAAAEgGACQgUAKgeAAQgfAAgUgTgAAZgOQAAgKgFgGQgGgIgKAAQgJAAgHAHQgHAHgBAKIAtAAIAAAAg");
	this.shape_2.setTransform(32.475,22.025);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAbBiIgEgBQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAgBAAgBIAAhMQAAgSgPAAQgQAAgNAJIAABVQABAGgGgBIgfAAQgEAAAAgEIAAi0QgBgHAIgBIAdgDQAFgBgBAGIAABEQARgOAYAAQAsAAAAAwIAABTQAAAGgEgBg");
	this.shape_3.setTransform(18.85,18.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgWBMQgGgHgCgLQgCgHAAgTIAAg0IgLAAQgFAAgBgCQgBgCAAgFIAAgMQAAgHAGAAIANAAIAAgdQAAgGAIgBIAagDQAGAAAAAHIAAAgIAdAAQAHAAAAAGIAAAQQAAAGgHAAIgdAAIAAA1QAAALACAFQADAHAJAAQAGAAALgEIAEgBQADAAABAEIADASIAAACQAAAEgEACQgQAHgTAAQgYAAgKgMg");
	this.shape_4.setTransform(2.025,20.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgtA0QgTgTAAghQAAgfAUgTQATgUAfAAQAbAAAQASQAQARAAAjIAAADQAAAIgKAAIhMAAQADANAKAHQAJAHANAAQARAAARgHIAEgBQADAAABAEQAGARAAAEQAAAEgGACQgUAKgeAAQgfAAgUgTgAAZgOQAAgKgFgGQgGgIgKAAQgJAAgHAHQgHAHgBAKIAtAAIAAAAg");
	this.shape_5.setTransform(-8.975,22.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgyBQQgPgSAAgdQAAgeAPgUQAQgXAdAAQASAAAMALIAAg6QAAgHAHgCIAdgEQAFAAAAAHIAAC2QAAAIgHAAIgXAAQgHAAAAgGIgBgFQgFAFgKAFQgKAFgJgBQgcABgQgVgAgQAFQgGAKAAAPQAAAlAYAAQAOAAAJgKIAAg4QgJgIgNAAQgMAAgHAMg");
	this.shape_6.setTransform(-22.875,19.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgMBiQgHABAAgIIAAixQAAgHAGgBIAcgDQAGAAgBAGIAAC2QAAAIgGgBg");
	this.shape_7.setTransform(-37.3,18.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgLBgQgIAAAAgIIAAh2QAAgHAIAAIAYAAQAIAAAAAHIAAB2QAAAIgIAAgAgOg6QgHgGAAgKQAAgJAHgGQAGgGAIAAQAJAAAGAGQAHAGAAAJQAAAJgHAGQgHAGgIAAQgIAAgGgFg");
	this.shape_8.setTransform(-43.075,19.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgWBMQgGgHgCgLQgCgHAAgTIAAg0IgLAAQgFAAgBgCQgBgCAAgFIAAgMQAAgHAGAAIANAAIAAgdQAAgGAIgBIAagDQAGAAAAAHIAAAgIAdAAQAHAAAAAGIAAAQQAAAGgHAAIgdAAIAAA1QAAALACAFQADAHAJAAQAGAAALgEIAEgBQADAAABAEIADASIAAACQAAAEgEACQgQAHgTAAQgYAAgKgMg");
	this.shape_9.setTransform(-50.775,20.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgiBxQgJgKgDgQQgCgLAAgdIAAhOIgRAAQgHAAgCgCQgCgDAAgIIAAgSQAAgLAJABIATAAIAAgsQAAgJANgCIAngFQAJAAAAALIAAAxIAtAAQAKgBAAAJIAAAXQAAALgKgBIgtAAIAABPQAAASAEAIQAEAJANAAQAKABAQgGIAGgBQAEAAACAGIAFAbIAAADQAAAFgHADQgXALgdAAQglABgPgUg");
	this.shape_10.setTransform(50.575,-9.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgzBnQgLAAAAgLIAAixQAAgLAMAAIAhAAQAMAAAAAIIABAMQALgOAKgGQAMgGASAAIALABQAGACgBAIIgGAnQgCAHgFAAIgNgCQgWAAgPAQIAAB7QAAALgMAAg");
	this.shape_11.setTransform(37.44,-7.325);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhOBMQgZgdAAgvQAAguAcgdQAcgeAwAAQAzAAAaAeQAaAcAAAvQAAAvgcAdQgdAegwAAQgyAAgbgegAgnAAQAAA5AnAAQAoAAAAg5QAAg5gnABQgogBAAA5g");
	this.shape_12.setTransform(18.825,-7.05);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAkCUQgNAAgGgKIgthSIgBAAIAABRQAAALgKAAIgoAAQgLAAAAgLIAAkKQAAgLAKgBIArgGQAIAAAAAKIAACkIABAAIAthJQAEgFAKAAIAtAAQAHAAAAAEQAAAEgCADIg2BIIA9BlQADAHAAACQAAAGgIAAg");
	this.shape_13.setTransform(-0.8,-11.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgiBxQgJgKgDgQQgCgLAAgdIAAhOIgRAAQgHAAgCgCQgCgDAAgIIAAgSQAAgLAJABIATAAIAAgsQAAgJANgCIAngFQAJAAAAALIAAAxIAtAAQAKgBAAAJIAAAXQAAALgKgBIgtAAIAABPQAAASAEAIQAEAJANAAQAKABAQgGIAGgBQAEAAACAGIAFAbIAAADQAAAFgHADQgXALgdAAQglABgPgUg");
	this.shape_14.setTransform(-27.425,-9.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AhOC+QgOAAAAgNIAAkFQAAgLALAAICjAAQALAAgBAJIgEAiQAAAKgPAAIhjAAIAAA8IBcAAQANAAAAALIAAAeQAAAMgMAAIhdAAIAABCIBqAAQAMAAAAALIAAAeQAAAMgLAAgAgih9IgGgIIgCgFQAAgDAGgFIAvgmQAGgFADAAQADAAAFAHIAMAPQACAEAAADQAAADgFADIg2AfIgJAEQgEAAgEgGg");
	this.shape_15.setTransform(-44.9958,-15.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-117.5,-36.6,235,73.2);


(lib.Tween17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABPDCQgMAAgEgLIgQguIhiAAIgQAwQgDAJgJAAIgtAAQgHAAAAgGIABgFIBfj/QAEgKAKAAIAoAAQALAAADAJIBiD9IABAGQAAAIgJAAgAAeBZIgZhPIgHgWIAAAAIgIAWIgZBPIBBAAgAgfhyQgOgOAAgTQAAgTAOgNQANgOASAAQATAAAOAOQAOANAAATQAAATgOAOQgOANgTAAQgSAAgNgNgAgKieQgEAFAAAGQAAAHAEAEQAFAEAFAAQAHAAAEgEQAFgEAAgHQAAgGgFgFQgFgEgGAAQgFAAgFAEg");
	this.shape.setTransform(53.525,14.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhVCLQgMAAAAgNIAAj7QAAgNANAAIA+AAQBGAAAcAeQAVAZABAjQAAAughAZQgcAYgwAAIgWgBIAABSQAAALgMAAgAghgCIAWABQAtAAAAgsQgBgsguAAIgUAAg");
	this.shape_1.setTransform(31.2,20.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgYCLQgGAAgBgCQgCgBAAgHIAAjXIhJAAQgLAAAAgMIAAgeQAAgKALAAIDWAAQALAAgBAKIgEAgQgBAKgNAAIhGAAIAADWQAAAHgCACQgBACgGAAg");
	this.shape_2.setTransform(55.3087,-20.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgSCLQgMAAAAgMIAAhoIhXiWIgBgEQAAgHAHAAIAxAAQALAAAEAJIAzBjIABAAIAzhjQAFgJALAAIAmAAQAJAAAAAGIgBAFIhVCTIAABsQAAALgLAAg");
	this.shape_3.setTransform(32.6,-20.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("ABNCLQgLAAgGgJIh3ieIAAAAIAACbQAAAMgMAAIgmAAQgNAAAAgMIAAj8QAAgNANAAIAiAAQAKAAAGAJIB3CfIAAAAIAAicQAAgMANAAIAnAAQALAAAAANIAAD7QAAANgMAAg");
	this.shape_4.setTransform(6.975,-20.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhMCLQgNAAAAgNIAAj9QAAgLALAAICeAAQALAAgBAJIgEAhQgBAKgOAAIhgAAIAAA7IBaAAQAMAAAAALIAAAcQAAAMgMAAIhaAAIAAA/IBnAAQAMAAAAALIAAAeQAAALgLAAg");
	this.shape_5.setTransform(-16.7208,-20.175);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhaCLQgMAAAAgOIAAj7QAAgMANAAIBBAAQBpAAAABEQAAAVgLAQQgMAQgUAFIAAAAQAdADARARQATATAAAeQAABShxAAgAgnAQIAABKIAZAAQAVAAALgEQAUgIAAgYQAAgYgTgJQgNgGgZAAgAgngbIAPAAQAXAAAJgIQALgHAAgTQAAgdgmAAIgUAAg");
	this.shape_6.setTransform(-38.275,-20.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-66.8,-45.1,133.7,90.2);


(lib.Tween14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgdA8QgHAAAAgHIAAhmQAAgHAHAAIAUAAQAGAAABAFIAAAHQAGgIAGgDQAHgEAKAAIAHABQADABgBAEIgDAXQgBAEgDAAIgIgBQgMAAgJAJIAABHQAAAHgHAAg");
	this.shape.setTransform(42.2111,36.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgnAtQgRgQAAgdQAAgbARgRQARgRAbAAQAYAAANAQQAPAPAAAeIAAADQAAAHgIAAIhDAAQACALAJAGQAIAGALAAQAOAAAQgGIADgBQADAAABAEQAFAPgBADQABADgFADQgSAIgaAAQgbAAgRgRgAAWgMQgBgIgEgGQgFgHgJAAQgHAAgHAGQgFAGgCAJIAoAAIAAAAg");
	this.shape_1.setTransform(31.85,36.725);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAaA8QgHAAAAgHIAAg/QAAgRgOAAQgMAAgLAJIAABHQAAAHgHAAIgXAAQgGAAAAgHIAAhmQAAgHAHAAIAUAAQAFAAABAFIABAFQARgNAUAAQAmAAAAAqIAABGQAAAHgHAAg");
	this.shape_2.setTransform(19.55,36.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgsAsQgQgQABgcQgBgbARgQQAQgRAcAAQAdgBAQASQAOAQAAAbQAAAbgPARQgRASgcAAQgdAAgPgSgAgWAAQAAAhAWABQAXAAAAgiQAAgggWgBQgXAAAAAhg");
	this.shape_3.setTransform(6.85,36.75);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgJBTQgIAAAAgGIAAhnQAAgHAIAAIAUAAQAHAAAAAHIAABnQAAAGgHAAgAgMgzQgGgFAAgIQAAgJAGgFQAFgFAHABQAIgBAFAFQAGAFAAAJQAAAHgGAGQgFAEgIABQgGgBgGgEg");
	this.shape_4.setTransform(-2.225,34.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgTBCQgGgGgBgJQgCgHAAgQIAAgtIgJAAQgEAAgCgCQgBgBAAgFIAAgKQAAgHAGAAIALAAIAAgZQAAgGAHgBIAWgCQAFAAAAAGIAAAcIAbAAQAFAAAAAFIAAAOQAAAGgFAAIgbAAIAAAuQAAAKADAEQACAFAIAAQAFABAKgDIADgBQABAAABAAQAAAAABABQAAAAAAABQABABAAAAIADAQIAAACQAAADgEACQgOAGgRAAQgUAAgJgLg");
	this.shape_5.setTransform(-9.425,35.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgyAsQgMgQAAgaQAAgdAQgRQAPgQAWAAQATgBAJANIABgEQAAgFAFgBIAWAAQAGABAAAFIAABSQAAAEADAAIACAAQAFAAAAAFIAAAOQAAAGgGgBIgMAAQgSAAgFgLIgBAAQgFAGgKAEQgJAFgIAAQgZAAgOgSgAgSgYQgHAJAAAPQAAAhAWgBQAFAAAHgDQAFgDADgEIAAgtQgKgIgJAAQgJAAgHAHg");
	this.shape_6.setTransform(-20.075,36.75);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgTBCQgGgGgBgJQgCgHAAgQIAAgtIgJAAQgEAAgCgCQgBgBAAgFIAAgKQAAgHAGAAIALAAIAAgZQAAgGAHgBIAWgCQAFAAAAAGIAAAcIAbAAQAFAAAAAFIAAAOQAAAGgFAAIgbAAIAAAuQAAAKADAEQACAFAIAAQAFABAKgDIADgBQABAAABAAQAAAAABABQAAAAAAABQABABAAAAIADAQIAAACQAAADgEACQgOAGgRAAQgUAAgJgLg");
	this.shape_7.setTransform(-30.875,35.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgpA1QgEgCAAgDIABgCIAFgQQABgEACAAIAEABQASAIAOAAQAMAAAAgJQAAgGgMgEIgUgIQgLgEgGgIQgIgIAAgNQAAgRAPgKQANgJARABQAVAAARAHQADACAAACIAAADIgFAQQgBAEgDAAIgDgBQgPgGgLAAQgFAAgDACQgDADAAADQAAAGAIADIAYAJQAWAIAAAWQAAATgPALQgNAJgTAAQgTAAgVgJg");
	this.shape_8.setTransform(-39.825,36.75);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AiJC2QgLgGAAgIIACgLIASgoQAFgKAIAAIALAEQAtAYAwAAQAdAAATgRQATgRAAgbQAAgegVgSQgYgVgtAAIg7AAQgWAAAAgaIAAilQAAgZAYAAIDLAAQAUAAAAAUIAAAnQAAAVgUAAIiFAAIAABDIAFAAQBGAAAtAfQAyAjAABDQAABDgvAnQguAlhGAAQhEAAg3geg");
	this.shape_9.setTransform(32.625,-2.625);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ah4DQQgOAAAAgMQAAgHACgFIChk2IiZAAQgSAAAAgUIAAgpQAAgUASAAID2AAQAVAAAAAUIAAAlQAAAQgIAPIiZE1QgKASgYAAg");
	this.shape_10.setTransform(2.9,-3.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("ABKDQQgUAAAAgSIAAhCIi3AAQgUAAAAgXIAAgcQAAgSAJgRIBwjjQAJgSASAAIAxAAQASAAAAANQAAAEgDAGIhtDkIBkAAIAAhaQAAgSAVAAIA2AAQAVAAAAASIAADsQAAASgWAAg");
	this.shape_11.setTransform(-29.425,-3.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-154.8,-62.4,309.6,112.3);


(lib.Tween13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiJC2QgLgGAAgIIACgLIASgoQAFgKAIAAIALAEQAtAYAwAAQAdAAATgRQATgRAAgbQAAgegVgSQgYgVgtAAIg7AAQgWAAAAgaIAAilQAAgZAYAAIDLAAQAUAAAAAUIAAAnQAAAVgUAAIiFAAIAABDIAFAAQBGAAAtAfQAyAjAABDQAABDgvAnQguAlhGAAQhEAAg3geg");
	this.shape.setTransform(136.325,4.475);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah2CcQghgxAAhQQAAhgAphCQAyhRBgAAQAnAAAiAKQAQAEgDARIgJArQgEAQgOgEQgngIgKAAQgqAAgVAXQgXAYgGArQAegRAkAAQA8AAAjAfQAlAiAAA/QAABAgnArQgpAvhEAAQhSAAgog9gAgZARQgUAHgJAKIAAAIQAABgA7AAQAZAAAOgWQAMgTAAgcQABg6gyAAQgPAAgRAGg");
	this.shape_1.setTransform(102.9,4.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAnDQQgPAAgEgDQgEgDAAgOIAAkiIhPArQgIAEgEAAQgJAAgHgPIgRghIgCgJQAAgKAMgGIB8hHQAOgIASAAIAkAAQARAAAAAQIAAF7QAAAUgWAAg");
	this.shape_2.setTransform(68.175,4.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgVBIQgGgHgCgKIgBgZIAAgxIgKAAQgFAAgBgCQgCgBAAgFIAAgMQAAgGAGAAIAMAAIAAgcQAAgGAIAAIAYgEQAGAAAAAHIAAAfIAcAAQAHAAAAAFIAAAPQAAAGgHAAIgcAAIAAAyQAAALACAFQADAGAIAAQAHAAAKgDIAEgBQAAAAABAAQAAAAABABQAAAAABABQAAAAAAABIADARIABACQAAAEgFACQgPAHgSAAQgWAAgKgMg");
	this.shape_3.setTransform(147.775,-32.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag2AwQgNgRAAgdQgBgfATgTQAQgSAXAAQAUAAALAPIABgGQAAgFAFAAIAYAAQAGAAAAAGIAABZQAAAEAEAAIACAAQAFAAABAGIAAAPQgBAFgGAAIgNAAQgUABgFgMIgBAAQgGAFgKAFQgKAFgJAAQgbAAgPgTgAgTgaQgIAKAAAQQABAjAXAAQAGAAAGgDQAGgEADgDIAAgyQgKgIgKgBQgKABgHAHg");
	this.shape_4.setTransform(136.15,-30.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgLBbQgKgEgFgGIgBAIQgCACgFAAIgUAAQgHAAAAgHIAAimQAAgIAGAAIAcgEQAFAAAAAFIAAA+QANgLASAAQATAAAOANQAUASAAAjQAAAdgOASQgQAUgbAAQgHAAgJgEgAgWADIAAAyQALAKAKgBQAXABAAgjQAAgggWgBQgLAAgLAIg");
	this.shape_5.setTransform(122.625,-33.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag2AwQgOgRAAgdQAAgfASgTQARgSAXAAQAVAAAJAPIABgGQABgFAFAAIAYAAQAGAAAAAGIAABZQAAAEAEAAIACAAQAGAAAAAGIAAAPQAAAFgHAAIgOAAQgTABgFgMIgBAAQgFAFgLAFQgKAFgJAAQgbAAgPgTgAgTgaQgHAKgBAQQAAAjAYAAQAGAAAGgDQAGgEADgDIAAgyQgKgIgKgBQgLABgGAHg");
	this.shape_6.setTransform(108.5,-30.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAkBaQgJAAgDgFIgkg4IgQAAIAAA2QAAAHgGAAIgbAAQgIAAAAgHIAAijQAAgGACgBQACgCAFAAIAnAAQAuAAASATQAOAQAAAXQAAAkgfAQIAAABIAqA9IACAEQAAADgEAAgAgcgBIAOAAQAdAAAAgdQAAgcggAAIgLAAg");
	this.shape_7.setTransform(94.6,-33.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-154,-62.9,308,103);


(lib.Tween11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A/SIaQAyg2BEgeQBFgfBNAAQBqAABZA4IAAAAQgBhPA5g4QA4g4BPAAQAzAAAqAYQgNgoAAgrQAAhwBRhQQBQhOBxAAQBvAABQBLQBPBLAEBtQAxgwBDAAQAwAAAnAZQgOgpAAgtQAAhwBQhPQBQhQBwAAQBCAAA4AdQAQirB9h0QCAh1CtAAQCsAAB/B0QB+BzARCpQA+gmBIAAQBeAABHA+QBHA+ANBbQAngTAqAAQBJAAA2AzQAdg3A1ggQA3ghBAAAQBfAABDBCQBDBDAABfQAAAogOAnQAcAPAQAbQARAbAAAhIgBAPIBSAAQAuAAAhAhQAgAhAAAuQAAAbgLAXg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-200.3,-53.7,400.70000000000005,107.5);


(lib.Tween8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.kort();
	this.instance.parent = this;
	this.instance.setTransform(-75,-46.05,0.7142,0.7139);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-75,-46,150,92.1);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.kort();
	this.instance.parent = this;
	this.instance.setTransform(-75,-46.05,0.7142,0.7139);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-75,-46,150,92.1);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAkBaQgJAAgDgFIgkg4IgQAAIAAA2QAAAHgGAAIgbAAQgIAAAAgHIAAijQAAgGACgBQACgCAFAAIAnAAQAuAAASATQAOAQAAAXQAAAkgfAQIAAABIAqA9IACAEQAAADgEAAgAgcgBIAOAAQAdAAAAgdQAAgcggAAIgLAAg");
	this.shape.setTransform(-55.25,27.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgxBaQgJAAAAgIIAAikQAAgHAHAAIBnAAQAHAAgBAGIgCAVQgBAGgJAAIg+AAIAAAnIA6AAQAIAAAAAHIAAASQAAAIgIAAIg6AAIAAApIBDAAQAHAAAAAHIAAATQAAAHgHAAg");
	this.shape_1.setTransform(-69.9483,27.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgPBaQgEAAgBgBQgBgBAAgEIAAiMIgvAAQgIAAAAgIIAAgTQAAgGAHAAICLAAQAIAAgBAGIgCAVQgBAGgJAAIgtAAIAACMQAAAEgBABQgCABgDAAg");
	this.shape_2.setTransform(-84.1191,27.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AggBaQgGAAAAgFIAAgPQAAgGAGAAIAMAAIAAh/IgOAAQgGAAAAgGIAAgOQAAgGAGAAIBEAAQAHAAAAAGIAAAOQAAAGgHAAIgOAAIAAB/IAOAAQAFAAABAGIAAAOQAAAGgGAAg");
	this.shape_3.setTransform(-96.6,27.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgwBaQgIAAgBgIIAAikQABgHAHAAIAbAAQAHAAAAAIIAACIIBBAAQAIAAAAAIIAAAUQAAAHgIAAg");
	this.shape_4.setTransform(-107.2,27.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgNAPQgHgGAAgJQAAgIAGgGQAHgFAHAAQAIAAAGAFQAHAGAAAIQAAAJgHAFQgGAGgIAAQgHAAgGgFg");
	this.shape_5.setTransform(-119.95,34.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAjBaQgHAAgEgFIgjg4IgRAAIAAA2QABAHgIAAIgbAAQgHAAAAgHIAAijQAAgGACgBQACgCAFAAIAoAAQAtAAASATQAOAQAAAXQAAAkgfAQIAAABIArA9IABAEQAAADgEAAgAgcgBIAOAAQAdAAAAgdQAAgcghAAIgKAAg");
	this.shape_6.setTransform(-128.45,27.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag2BaQgJAAABgIIAAijQgBgIAJAAIAoAAQAtAAASAUQAOAPABAXQAAAegVAQQgTAPgfAAIgOAAIAAA1QAAAHgHAAgAgVgBIAOAAQAdAAgBgcQAAgcgdAAIgNAAg");
	this.shape_7.setTransform(-142.35,27.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhyDQQgUAAAAgSIAAl8QAAgRAQAAIDuAAQAQAAgBAOIgGAwQgBAPgWAAIiQAAIAABaICHAAQASAAAAAQIAAArQAAARgSAAIiHAAIAABfICbAAQASAAAAAQIAAAtQAAAQgRAAg");
	this.shape_8.setTransform(-56.5221,-7.625);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("ABSDQQgTAAgIgNIhTiAIglAAIAAB9QAAAQgQAAIg+AAQgRAAAAgRIAAl6QAAgMADgEQAFgEAMAAIBbAAQBrAAApAtQAgAkAAA1QAABWhHAkIAAABIBiCMIADAKQAAAIgJAAgAhBgDIAeAAQBGAAAAhEQAAhAhMAAIgYAAg");
	this.shape_9.setTransform(-89.225,-7.625);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AilDpIgTgQQgJgGAAgGQAAgEAHgJIAkgxQgkg3AAhSQAAhhA0g8QA0g9BYAAQA2AAApAXIAhgsQAEgFAFgBIAIAEIAbAUQAIAGAAAFQAAAFgFAFIghAtQAuA6AABdQAABkg2A8Qg0A7hWAAQg/gBgugfIgfAnQgIAMgFAAQgEgBgKgGgAg0B0QAVAYAkAAQBXAAAAiJQAAgpgIgbgAg7hhQgZAkAABAQAAAbAEAVICBiqQgUgMgaAAQgnAAgXAig");
	this.shape_10.setTransform(-129.025,-8.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-152.5,-44,305,88);


(lib.shell = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF2524").s().p("EgCLArVQhFgVg6grIhYhBI3+AAIiOxwIuiqkQg9koAAk2QAAplDtoxQDmofGimiQGjmjIejlQIyjuJlAAQJnAAIxDuQIeDlGjGjQGiGiDmIfQDtIxAAJlQAAE2g9EoIuiKkIiORwI3+AAIhYBBQg6ArhFAVQhEAXhIAAQhHAAhEgXgEgm9ADiQAACiApCfIOWKcIBxOEIRbAAIClB5QA/AuBOAAQBPAAA/guIClh5IRbAAIBxuEIOWqcQApidAAikQAAkRhwj5I5aZrIYt+fQgvi9hlioQhlimiSiDMgWJAmNMATogp0Qh6iiimh1Qimh1jCg8MgNiAvbMAJ5gxYQiQhRihgrQiggpimAAQhHgBhFAIMgCBAzWMgCAgzWQhFgIhHABQimAAigApQigAriRBRMAJ5AxYMgNigvbQjCA8imB1QimB1h6CiMAToAp0MgWJgmNQiSCDhlCmQhlCogvC9IYtefI5a5rQhwD6AAEQg");
	this.shape.setTransform(98.7722,99.7844,0.1519,0.1519);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFCD0E").s().p("EgCLArVQhFgVg6grIhYhBI3+AAIiOxwIuiqkQg9koAAk2QAAplDtoxQDmofGimiQGjmjIejlQIyjuJlAAQJnAAIxDuQIeDlGjGjQGiGiDmIfQDtIxAAJlQAAE2g9EoIuiKkIiORwI3+AAIhYBBQg6ArhFAVQhEAXhIAAQhHAAhEgXg");
	this.shape_1.setTransform(98.7722,99.7844,0.1519,0.1519);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Aq6K6QkgkhgBmZQABmYEgkiQEikgGYgBQGZABEhEgQEhEiAAGYQAAGZkhEhQkhEhmZAAQmYAAkikhg");
	this.shape_2.setTransform(98.75,98.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.shell, new cjs.Rectangle(0,0,197.5,197.5), null);


(lib.Q8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C7141D").s().p("AiJAXQAfgXAigWIABAAIC5AAQAOAYAKAVg");
	this.shape.setTransform(149.3234,71.7549,0.9157,0.9157);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#C7141D").s().p("AilAeQgugegegdIHkAAQgUAdgZAeg");
	this.shape_1.setTransform(135.1526,114.9084,0.9157,0.9157);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FEC538").s().p("AjwAeQgSgRgUgWIAKgUIIjAAQgRAfgSAcg");
	this.shape_2.setTransform(117.914,109.437,0.9157,0.9157);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C7141D").s().p("AkeAeQARgeARgdIIaAAQgJAdgQAeg");
	this.shape_3.setTransform(136.6635,103.9655,0.9157,0.9157);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FEC538").s().p("AkVAeQAQgaAXghIIEAAQgFAdgMAeg");
	this.shape_4.setTransform(121.8516,98.4941,0.9157,0.9157);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C7141D").s().p("AkFAeQAOgWAcglIHhAAQgBAdgGAeg");
	this.shape_5.setTransform(141.0819,93.0226,0.9157,0.9157);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FEC538").s().p("AjwAeIAwg7IGvAAQADAfgBAcg");
	this.shape_6.setTransform(125.9243,87.5511,0.9157,0.9157);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#C7141D").s().p("AjXAeQAZgcAfgfIFsAAQAHAaAEAhg");
	this.shape_7.setTransform(145.1569,82.1026,0.9157,0.9157);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FEC538").s().p("Ai1AeQAggeAjgdIETAAQAOAfAHAcg");
	this.shape_8.setTransform(130.0932,76.6311,0.9157,0.9157);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#224498").s().p("AhcAfQBFgqBGgTIAPAQQARAUAOAZg");
	this.shape_9.setTransform(151.2235,66.7871,0.9157,0.9157);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#224498").s().p("AhzAUIADgEQAXgWAUgYIC6AAQgSAWgZAYQgTAIgjAEQgWADgXAAQgtAAgtgLg");
	this.shape_10.setTransform(142.5699,120.4588,0.9157,0.9157);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#224498").s().p("AhuAeQASgcARgfIC6AAQgRAfgSAcg");
	this.shape_11.setTransform(150.3994,109.437,0.9157,0.9157);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#224498").s().p("AhlAeQALgeAGgdIC6AAQgHAhgKAag");
	this.shape_12.setTransform(155.0925,98.4941,0.9157,0.9157);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#224498").s().p("AhcAeQACgcgEgfIC6AAQAEAfgCAcg");
	this.shape_13.setTransform(156.4638,87.5511,0.9157,0.9157);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#224498").s().p("AhSAeQgHgcgOgfIC5AAQAOAdAIAeg");
	this.shape_14.setTransform(154.3828,76.6311,0.9157,0.9157);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FEC538").s().p("AhcAfQBFgqBGgTIAOAQQARAUAPAZg");
	this.shape_15.setTransform(134.1224,66.7871,0.9157,0.9157);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("Ah9AXQAkgbAegSIC5AAQgiAVgfAYg");
	this.shape_16.setTransform(131.1463,71.7549,0.9157,0.9157);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FEC538").s().p("Ai1gdIFrAAIgvAyQgkAJhAAAQh1AAhjg7g");
	this.shape_17.setTransform(119.5165,120.4028,0.9157,0.9157);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("Ag2AeQgqgagjghIC6AAQAiAhArAag");
	this.shape_18.setTransform(107.9097,114.9084,0.9157,0.9157);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AhtAeQAQgeARgdIC6AAQgRAdgRAeg");
	this.shape_19.setTransform(103.4227,103.9655,0.9157,0.9157);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AhyAeQAPgWAcglIC6AAQgcAlgPAWg");
	this.shape_20.setTransform(110.4509,93.0226,0.9157,0.9157);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("Ah5AeQAeghAagaIC6AAQgaAageAhg");
	this.shape_21.setTransform(119.4021,82.1026,0.9157,0.9157);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FEC538").s().p("AAdFKQgsAKgwAAQhWAAhOgfQhmgqhOhdIgGgIIAEgJQAOgcAXgnQAuhOA2hFQBNhiBUhEQBqhVBsgdIAJgCIAHAGIAMAPQAOARAOAUQBBgmBCgSIAJgCIAHAGIAoA1QAqBBAQBKQAYBngfBpQgmCCh5B9IgCADIgEABQgtAOhAAAQgwAAgugKg");
	this.shape_22.setTransform(128.7099,93.4763,0.9163,0.9163);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#224498").s().p("AgUC8IgdgeQgyAig7AAQhOAAgzg5Qgzg6AGhQQAGhRA7g5QA8g6BOAAQBPAAAyA6QAzA5gGBRQgEA5gkAzIBCBGQgPAMgTAHQgQAGgNAAQgQAAgMgMgAjWhTQgjAhgDAvQgEAuAeAhQAdAhAtAAQAYAAAYgLIglgnIA4g0IAkAnQANgZACgYQAEgvgeghQgdghguAAQgtAAgiAhgABjChQgjgiAEg5QACgYANgWQAQgYAbgQIAGgCIgGgCQghgZAEgxQADgtAlgeQAkgeAxAAQAwAAAgAeQAgAegDAtQgEAwglAaQgCACgFAAQAEAAACACQAZAQALAYQAKAWgBAYQgFA5goAiQgoAgg6AAQg6AAgigggACpAhQgPAOgCAVQgCAVANAOQANANAVAAQAVAAAPgNQAPgOACgVQACgVgNgOQgNgNgVAAQgVAAgPANgAC6hzQgMALgBAQQgBAQAKAKQAKAKASAAQASAAAMgKQAMgLABgPQACgQgKgLQgLgKgSAAQgSAAgMAKg");
	this.shape_23.setTransform(58.7499,106.3319,0.9168,0.9168);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("Aq6K6QkgkhgBmZQABmYEgkiQEikgGYgBQGZABEhEgQEhEiAAGYQAAGZkhEhQkhEhmZAAQmYAAkikhg");
	this.shape_24.setTransform(98.75,98.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Q8, new cjs.Rectangle(0,0,197.5,197.5), null);


(lib.logo_ = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BDD54B").s().p("ApIDaIBEjHQAjhmAegpQBHhdCAAAINEAAIgXBHIs3AAQhXAAguA6QgPAUgOAhQgIATgLAiIhEDIg");
	this.shape.setTransform(98.7633,99.0005,0.8659,0.8659);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BDD54B").s().p("AjHCwIBDjGQAahNAUgZQAogzBPAAICnAAIgYBIIiUAAQgoACgWAaQgNAQgNAlIDQAAIgYBGIjQAAIgrCAg");
	this.shape_1.setTransform(72.9373,102.659,0.8659,0.8659);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#D1D3D4","#CECFD1","#C4C6C8","#BCBEC0"],[0,0.396,0.792,1],-14.4,-8.8,15.3,12).s().p("AjDCwIAkhqQASg0AigUQAkgVBHAAIA7AAQARAAAPgPQAPgOAHgTQABgVgHgFQgIgGgiAAIimAAIAZhIIDGAAQAxAAAQAXQARAYgRA0QgqB6hdACIhBAAQgpAAgRALQgPAJgJAbIgDAJIDnAAIgZBIg");
	this.shape_2.setTransform(99.2126,102.659,0.8659,0.8659);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#D1D3D4","#CECFD1","#C4C6C8","#BCBEC0"],[0,0.396,0.792,1],-15.2,-10.9,11.9,8).s().p("AgYCwIAoiAIhcAAQgxAAgQgXQgRgYARgzIAph9IBIAAIguCNQgCAHAEADQADACAIAAIBjAAIAchRIBHAAIgfBRIAtAAIgWBGIgtAAIgnCAg");
	this.shape_3.setTransform(129.0976,102.659,0.8659,0.8659);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#002F5C").s().p("Aq+FgQg2AAgagpQgZgpAUg5ICMmiQAUg6A0grQA1gsA2gBISNAAQA2AAAcAqQAcApgQA7IhwGjQgQA6gyAqQgyAqg3AAg");
	this.shape_4.setTransform(98.0391,99.1085,0.8659,0.8659);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Aq6K6QkgkhgBmZQABmYEgkiQEikgGYgBQGZABEhEgQEhEiAAGYQAAGZkhEhQkhEhmZAAQmYAAkikhg");
	this.shape_5.setTransform(98.75,98.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_, new cjs.Rectangle(0,0,197.5,197.5), null);


(lib.hjul = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AkoEpQh7h7AAiuQAAitB7h7QB7h7CtAAQCuAAB7B7QB7B7AACtQAACuh7B7Qh7B7iuAAQitAAh7h7g");
	this.shape.setTransform(143.8,143.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AouUtQkChtjHjHQjIjIhtkCQhxkLAAkkQAAkkBxkLQBtkCDIjHQDHjHEChtQELhxEjAAQElAAELBxQECBtDHDHQDHDHBtECQBxELAAEkQAAEkhxELQhtECjHDIQjHDHkCBtQkLBxklAAQkjAAkLhxgAmHufQi1BMiLCMQiMCLhMC1QhQC7AADMQAADNBQC7QBMC1CMCLQCLCMC1BMQC7BQDMAAQDNAAC7hQQC1hMCLiMQCMiLBMi1QBQi7AAjNQAAjMhQi7QhMi1iMiLQiLiMi1hMQi7hQjNAAQjLAAi8BQg");
	this.shape_1.setTransform(143.775,143.775);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.hjul, new cjs.Rectangle(0,0,287.6,287.6), null);


(lib.Tween20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.hjul();
	this.instance.parent = this;
	this.instance.setTransform(152.85,0,0.3654,0.3654,0,0,0,143.8,143.8);

	this.instance_1 = new lib.hjul();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-152.85,0,0.3654,0.3654,0,0,0,143.8,143.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-205.4,-52.5,410.8,105.1);


(lib.Cloud = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_copy
	this.instance = new lib.Tween11("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(159.45,86.65,0.2725,0.2725,0,0,0,0.2,0);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(81).to({_off:false},0).to({regX:0.1,scaleX:0.3114,scaleY:0.3114,x:2379.05},293).wait(1));

	// Layer_1
	this.instance_1 = new lib.Tween11("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(211.85,22.65,0.2539,0.2539);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:2794.8,y:18.15},354).to({_off:true},1).wait(20));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(104.8,4.5,2740.8999999999996,98.9);


// stage content:
(lib._728x90_HTML5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_7
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhGHeIAAu7ICNAAIAAO7g");
	this.shape.setTransform(364,-82.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},229).wait(22));

	// Layer_6
	this.instance = new lib.Tween14("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(1010,36.25);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(108).to({_off:false},0).to({x:420.4},6,cjs.Ease.sineInOut).wait(52).to({startPosition:0},0).to({x:-51.15,y:39.5},13,cjs.Ease.quintInOut).to({_off:true},1).wait(71));

	// Layer_5
	this.instance_1 = new lib.Tween17("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(781.05,45);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(105).to({_off:false},0).wait(1).to({regX:9.3,regY:0.1,x:776.65,y:45.1},0).wait(1).to({x:745.05},0).wait(1).to({x:693.25},0).wait(1).to({x:621.8},0).wait(1).to({x:537.2},0).wait(1).to({x:452.15},0).wait(1).to({x:379.5},0).wait(1).to({x:326.15},0).wait(1).to({regX:0,regY:0,x:283.5,y:45},0).wait(48).to({startPosition:0},0).to({x:-92.9,y:57.35},15,cjs.Ease.quintInOut).to({_off:true},1).wait(73));

	// Layer_1
	this.instance_2 = new lib.Tween2("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(881.5,45);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(46).to({_off:false},0).to({x:528.8},7,cjs.Ease.sineOut).wait(43).to({startPosition:0},0).wait(2).to({startPosition:0},0).to({x:38.2},17,cjs.Ease.quintInOut).to({_off:true},1).wait(135));

	// Layer_4
	this.instance_3 = new lib.Tween13("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(675,56.4);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(42).to({_off:false},0).to({x:200.75},11,cjs.Ease.sineOut).wait(43).to({startPosition:0},0).to({x:-155},17,cjs.Ease.quintInOut).to({_off:true},3).wait(135));

	// Bil
	this.instance_4 = new lib.kort();
	this.instance_4.parent = this;
	this.instance_4.setTransform(323,21,0.4286,0.4283);

	this.instance_5 = new lib.Tween7("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(322.3,23.25,0.5795,0.5792,3.4829,0,0,-74.9,-46);
	this.instance_5._off = true;

	this.instance_6 = new lib.Tween8("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(-157.05,43.95,1,1,3.7454,0,0,-75,-46.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4}]}).to({state:[{t:this.instance_5}]},38).to({state:[{t:this.instance_5}]},8).to({state:[{t:this.instance_6}]},128).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_4}]},9).wait(67));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({_off:true},38).wait(137).to({_off:false,x:734,y:23},0).to({x:323,y:21},9,cjs.Ease.backOut).wait(67));
	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(38).to({_off:false},0).to({x:-94.05,y:22.9},8,cjs.Ease.backIn).to({_off:true},128).wait(77));

	// Hjul
	this.instance_7 = new lib.Tween20("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(364,65.95,0.1733,0.1718,0,0,0,-26.6,0);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(12).to({_off:false},0).to({y:80.95},10,cjs.Ease.backOut).wait(16).to({startPosition:0},0).to({x:-56.85,y:81.25},8,cjs.Ease.backIn).to({_off:true},138).wait(67));

	// Layer_11
	this.instance_8 = new lib.Tween23("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(514,-29.95);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(210).to({_off:false},0).to({y:45.05},4,cjs.Ease.backOut).wait(20).to({startPosition:0},0).to({scaleX:0.4919,scaleY:0.4919,x:364,y:45},7,cjs.Ease.backIn).wait(10));

	// Shell
	this.instance_9 = new lib.shell();
	this.instance_9.parent = this;
	this.instance_9.setTransform(289.25,-44,0.2025,0.2025,0,0,0,99.5,98.8);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(197).to({_off:false},0).to({regY:99,x:225.75,y:45.05},7,cjs.Ease.backOut).wait(30).to({x:230.9},0).to({regX:99.2,x:364.1},7,cjs.Ease.backIn).wait(10));

	// F24
	this.instance_10 = new lib.logo_();
	this.instance_10.parent = this;
	this.instance_10.setTransform(197,-40.95,0.2025,0.2025,0,0,0,99.5,98.5);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(192).to({_off:false},0).to({x:163.2,y:44.95},7,cjs.Ease.backOut).wait(35).to({x:175.6},0).to({regX:99.2,x:364.1},7,cjs.Ease.backIn).wait(10));

	// Q8
	this.instance_11 = new lib.Q8();
	this.instance_11.parent = this;
	this.instance_11.setTransform(98.35,-60,0.2025,0.2025,0,0,0,99,98.2);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(187).to({_off:false},0).to({regX:99.5,regY:98.5,x:98.6,y:44.95},7,cjs.Ease.backOut).wait(40).to({regX:99,x:114},0).to({x:364.05},7,cjs.Ease.backIn).wait(10));

	// Sky
	this.instance_12 = new lib.Cloud();
	this.instance_12.parent = this;
	this.instance_12.setTransform(-181.45,31.1,0.3896,0.3896,0,0,0,-144,57.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(251));

	// bg
	this.instance_13 = new lib.bg_930x180();
	this.instance_13.parent = this;
	this.instance_13.setTransform(-1,-51,0.785,0.7851);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(251));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(55,-85.1,1109.8,230.79999999999998);
// library properties:
lib.properties = {
	id: 'DDDE089C9D9248C48A9CFDF1E6EA452C',
	width: 728,
	height: 90,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/bg_930x180.jpg", id:"bg_930x180"},
		{src:"images/kort.jpg", id:"kort"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['DDDE089C9D9248C48A9CFDF1E6EA452C'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;