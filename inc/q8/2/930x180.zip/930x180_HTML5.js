(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.bg_930x180 = function() {
	this.initialize(img.bg_930x180);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,930,180);


(lib.kort = function() {
	this.initialize(img.kort);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,210,129);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgyA6QgXgVAAglQABgjAWgWQAWgVAjAAQAeAAASATQASAUABAnIAAAEQAAAIgMABIhVAAQADANALAJQAKAHAOAAQAUABATgJIAEAAQAEAAABAEQAGATAAAFQAAAEgGADQgXAKghAAQgkABgVgWgAAcgQQAAgLgGgIQgGgIgMAAQgKAAgIAIQgHAHgCAMIAzAAIAAAAg");
	this.shape.setTransform(58.4,27.35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgOBvQgIAAAAgJIAAjHQAAgIAHgBIAggEQAGAAAAAIIAADMQAAAJgIAAg");
	this.shape_1.setTransform(47.675,23.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgyA6QgXgVAAglQAAgjAXgWQAWgVAjAAQAeAAASATQASAUAAAnIAAAEQABAIgMABIhVAAQADANALAJQAKAHAPAAQASABAUgJIAEAAQAEAAABAEQAGATAAAFQAAAEgGADQgXAKghAAQgkABgVgWgAAcgQQAAgLgGgIQgGgIgMAAQgKAAgIAIQgHAHgCAMIAzAAIAAAAg");
	this.shape_2.setTransform(37.15,27.35);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAeBvQgBAAAAAAQgBAAgBAAQAAgBgBAAQAAAAAAAAQgBgBAAgEIAAhWQAAgVgSAAQgRAAgOAMIAABfQAAAGgGAAIgjAAQgGAAAAgGIAAjKQAAgIAJgBIAhgEQAFAAAAAHIAABLQASgPAcAAQAyAAgBA2IAABeQABAGgGAAg");
	this.shape_3.setTransform(21.65,23.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgZBWQgHgJgCgLQgCgJAAgVIAAg6IgMAAQgGgBgBgCQgCgCAAgGIAAgNQAAgIAHAAIAPAAIAAghQAAgGAJgBIAdgFQAHAAAAAIIAAAlIAhAAQAIAAAAAHIAAASQAAAGgIABIghAAIAAA7QAAANACAGQAEAGAJAAQAIAAAMgDIAEgBQAEAAABAEIAEAUIAAADQAAAEgFACQgSAJgWgBQgbABgLgOg");
	this.shape_4.setTransform(2.225,25.35);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgzA6QgVgVAAglQgBgjAXgWQAWgVAjAAQAdAAATATQASAUAAAnIAAAEQAAAIgLABIhWAAQADANAMAJQAKAHAPAAQATABATgJIAEAAQAEAAABAEQAGATAAAFQAAAEgGADQgXAKghAAQgkABgWgWgAAcgQQAAgLgGgIQgHgIgLAAQgKAAgIAIQgHAHgCAMIAzAAIAAAAg");
	this.shape_5.setTransform(-10.4,27.35);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag5BaQgRgUAAgiQABghAQgWQATgaAhAAQAUAAANAMIAAhBQAAgJAHgBIAhgEQAGAAABAHIAADNQAAAJgJAAIgaAAQgHAAgBgGIAAgGQgHAGgLAFQgLAFgJAAQghAAgSgXgAgTAGQgGALAAARQAAAqAcAAQAOAAALgMIAAg/QgLgJgNAAQgOAAgJAOg");
	this.shape_6.setTransform(-26.2,24);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgOBvQgIAAAAgJIAAjHQAAgIAHgBIAggEQAGAAAAAIIAADMQAAAJgIAAg");
	this.shape_7.setTransform(-42.875,23.825);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgMBsQgKAAAAgJIAAiFQAAgIAKAAIAbAAQAJAAAAAIIAACFQAAAJgJAAgAgQhCQgIgGAAgLQAAgLAIgHQAHgGAJAAQAKAAAHAGQAIAHAAALQAAAKgIAHQgIAGgJAAQgJAAgHgGg");
	this.shape_8.setTransform(-49.7,24.125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgZBWQgHgJgCgLQgCgJAAgVIAAg6IgMAAQgGgBgBgCQgCgCAAgGIAAgNQAAgIAHAAIAPAAIAAghQAAgGAJgBIAdgFQAHAAAAAIIAAAlIAhAAQAIAAAAAHIAAASQAAAGgIABIghAAIAAA7QAAANACAGQAEAGAJAAQAIAAAMgDIAEgBQAEAAABAEIAEAUIAAADQAAAEgFACQgSAJgWgBQgbABgLgOg");
	this.shape_9.setTransform(-58.525,25.35);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgpCKQgMgNgDgTQgCgOAAgiIAAhfIgUAAQgJAAgDgDQgCgDAAgLIAAgVQAAgNALAAIAXAAIAAg0QAAgMAQgBIAugGQALAAAAANIAAA6IA3AAQAMAAAAALIAAAcQAAAMgMAAIg3AAIAABgQAAAWAFAJQAGALAPAAQAMAAAUgGIAHgCQAFAAACAHIAGAgIAAAFQAAAHgIADQgdANgjAAQgsAAgSgWg");
	this.shape_10.setTransform(61.975,-11.275);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("Ag9B9QgOAAAAgOIAAjVQAAgPAOAAIAoAAQAOAAABAKIABAPQANgRANgHQAOgIAVAAIAOACQAHACgBAKIgIAvQgBAIgHAAIgQgCQgaAAgTAUIAACUQAAAOgOAAg");
	this.shape_11.setTransform(45.7632,-8.375);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AheBbQgeghAAg6QAAg4AhgjQAigkA7AAQA9AAAgAlQAeAhAAA5QAAA5ghAiQgiAlg7AAQg9AAggglgAgvAAQAABFAvAAQAwAAAAhFQAAhEgvAAQgwAAAABEg");
	this.shape_12.setTransform(22.825,-8.05);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAsCzQgQAAgHgMIg3hjIgBAAIAABhQABAOgNAAIgxAAQgNAAAAgOIAAlCQAAgNAMgBIA0gHQALAAgBANIAADGIABAAIA3hYQAFgIALAAIA2AAQAIAAAAAHQABADgDAEIhABYIBJB6QAEAHAAAEQAAAHgLAAg");
	this.shape_13.setTransform(-1.2,-13.775);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgpCKQgMgNgDgTQgCgOAAgiIAAhfIgUAAQgJAAgDgDQgCgDAAgLIAAgVQAAgNALAAIAXAAIAAg0QAAgMAQgBIAugGQALAAAAANIAAA6IA3AAQAMAAAAALIAAAcQAAAMgMAAIg3AAIAABgQAAAWAFAJQAGALAPAAQAMAAAUgGIAHgCQAFAAACAHIAGAgIAAAFQAAAHgIADQgdANgjAAQgsAAgSgWg");
	this.shape_14.setTransform(-34.025,-11.275);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AheDlQgRAAAAgPIAAk8QAAgNANAAIDFAAQAOAAgBALIgFAoQgBANgSAAIh4AAIAABJIBwAAQAPAAAAANIAAAlQAAAOgOAAIhxAAIAABPICCAAQAOAAAAANIAAAlQAAAOgOAAgAgpiXIgHgKIgDgGQAAgEAIgGIA5guQAHgFAEAAQADAAAGAHIAOATQAEAFAAADQAAAEgHAEIhBAmIgLAEQgFAAgFgHg");
	this.shape_15.setTransform(-55.6716,-18.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-117.5,-43.4,235,86.9);


(lib.Tween22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgyA6QgXgVAAglQABgjAWgWQAWgWAjABQAegBASAUQASATABAoIAAADQAAAKgMgBIhVAAQADAPALAIQAKAIAOAAQAUgBATgHIAEgBQAEAAABAEQAGAUAAAEQAAAEgGADQgXALghAAQgkgBgVgVgAAcgQQAAgLgGgHQgGgJgMAAQgKAAgIAIQgHAIgCALIAzAAIAAAAg");
	this.shape.setTransform(58.4,27.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgOBvQgIAAAAgJIAAjHQAAgIAHgBIAggEQAGAAAAAIIAADMQAAAJgIAAg");
	this.shape_1.setTransform(47.675,23.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgyA6QgXgVAAglQAAgjAXgWQAWgWAjABQAegBASAUQASATAAAoIAAADQABAKgMgBIhVAAQADAPALAIQAKAIAPAAQASgBAUgHIAEgBQAEAAABAEQAGAUAAAEQAAAEgGADQgXALghAAQgkgBgVgVgAAcgQQAAgLgGgHQgGgJgMAAQgKAAgIAIQgHAIgCALIAzAAIAAAAg");
	this.shape_2.setTransform(37.15,27.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAeBvQgBAAAAAAQgBAAgBgBQAAAAgBAAQAAAAAAAAQgBgBAAgEIAAhWQAAgVgSAAQgRAAgOAMIAABfQAAAGgGAAIgjAAQgGAAAAgGIAAjKQAAgIAJgBIAhgEQAFAAAAAHIAABLQASgPAcAAQAyAAgBA2IAABeQABAGgGAAg");
	this.shape_3.setTransform(21.65,23.775);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgZBVQgHgHgCgMQgCgJAAgVIAAg7IgMAAQgGAAgBgBQgCgCAAgHIAAgNQAAgIAHAAIAPAAIAAggQAAgIAJgBIAdgDQAHAAAAAHIAAAlIAhAAQAIAAAAAGIAAASQAAAIgIgBIghAAIAAA8QAAANACAGQAEAHAJAAQAIAAAMgEIAEgBQAEAAABAFIAEATIAAADQAAAEgFADQgSAHgWABQgbAAgLgPg");
	this.shape_4.setTransform(2.225,25.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgzA6QgVgVAAglQgBgjAXgWQAWgWAjABQAdgBATAUQASATAAAoIAAADQAAAKgLgBIhWAAQADAPAMAIQAKAIAPAAQATgBATgHIAEgBQAEAAABAEQAGAUAAAEQAAAEgGADQgXALghAAQgkgBgWgVgAAcgQQAAgLgGgHQgHgJgLAAQgKAAgIAIQgHAIgCALIAzAAIAAAAg");
	this.shape_5.setTransform(-10.4,27.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag5BbQgRgWAAggQABgjAQgWQATgZAhAAQAUAAANAMIAAhBQAAgJAHAAIAhgFQAGAAABAHIAADOQAAAIgJAAIgaAAQgHAAgBgGIAAgHQgHAHgLAFQgLAFgJAAQghAAgSgWgAgTAFQgGAMAAAQQAAAqAcABQAOAAALgMIAAg/QgLgJgNAAQgOAAgJANg");
	this.shape_6.setTransform(-26.2,23.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgOBvQgIAAAAgJIAAjHQAAgIAHgBIAggEQAGAAAAAIIAADMQAAAJgIAAg");
	this.shape_7.setTransform(-42.875,23.775);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgMBsQgKAAAAgJIAAiFQAAgIAKAAIAbAAQAJAAAAAIIAACFQAAAJgJAAgAgQhCQgIgGAAgLQAAgLAIgHQAHgGAJAAQAKAAAHAGQAIAHAAALQAAAKgIAHQgIAGgJAAQgJAAgHgGg");
	this.shape_8.setTransform(-49.7,24.075);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgZBVQgHgHgCgMQgCgJAAgVIAAg7IgMAAQgGAAgBgBQgCgCAAgHIAAgNQAAgIAHAAIAPAAIAAggQAAgIAJgBIAdgDQAHAAAAAHIAAAlIAhAAQAIAAAAAGIAAASQAAAIgIgBIghAAIAAA8QAAANACAGQAEAHAJAAQAIAAAMgEIAEgBQAEAAABAFIAEATIAAADQAAAEgFADQgSAHgWABQgbAAgLgPg");
	this.shape_9.setTransform(-58.525,25.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgpCKQgMgNgDgTQgCgOAAgiIAAhfIgUAAQgJAAgDgDQgCgDAAgLIAAgVQAAgNALAAIAXAAIAAg0QAAgMAQgBIAugGQALAAAAANIAAA6IA3AAQAMAAAAALIAAAcQAAAMgMAAIg3AAIAABgQAAAWAFAJQAGALAPAAQAMAAAUgGIAHgCQAFAAACAHIAGAgIAAAFQAAAHgIADQgdANgjAAQgsAAgSgWg");
	this.shape_10.setTransform(61.975,-11.325);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("Ag9B9QgOAAAAgOIAAjVQAAgPAOAAIAoAAQAOAAABAKIABAPQANgRANgHQAOgIAVAAIAOACQAHACgBAKIgIAvQgBAIgHAAIgQgCQgaAAgTAUIAACUQAAAOgOAAg");
	this.shape_11.setTransform(45.7632,-8.425);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AheBcQgegiAAg6QAAg4AhgjQAigkA7AAQA9AAAgAkQAeAiAAA6QAAA4ghAjQgiAkg7AAQg9AAgggkgAgvAAQAABFAvAAQAwAAAAhFQAAhEgvAAQgwAAAABEg");
	this.shape_12.setTransform(22.825,-8.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAsCzQgQAAgHgMIg3hjIgBAAIAABhQABAOgNAAIgxAAQgNAAAAgOIAAlCQAAgNAMgBIA0gHQALAAgBANIAADGIABAAIA3hYQAFgIALAAIA2AAQAIAAAAAHQABADgDAEIhABYIBJB6QAEAHAAAEQAAAHgLAAg");
	this.shape_13.setTransform(-1.2,-13.825);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgpCKQgMgNgDgTQgCgOAAgiIAAhfIgUAAQgJAAgDgDQgCgDAAgLIAAgVQAAgNALAAIAXAAIAAg0QAAgMAQgBIAugGQALAAAAANIAAA6IA3AAQAMAAAAALIAAAcQAAAMgMAAIg3AAIAABgQAAAWAFAJQAGALAPAAQAMAAAUgGIAHgCQAFAAACAHIAGAgIAAAFQAAAHgIADQgdANgjAAQgsAAgSgWg");
	this.shape_14.setTransform(-34.025,-11.325);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AheDlQgRAAAAgPIAAk8QAAgNANAAIDFAAQAOAAgBALIgFAoQgBANgSAAIh4AAIAABJIBwAAQAPAAAAANIAAAlQAAAOgOAAIhxAAIAABPICCAAQAOAAAAANIAAAlQAAAOgOAAgAgpiXIgHgKIgDgGQAAgEAIgGIA5guQAHgFAEAAQADAAAGAHIAOATQAEAFAAADQAAAEgHAEIhBAmIgLAEQgFAAgFgHg");
	this.shape_15.setTransform(-55.6716,-18.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-117.5,-43.4,235,86.8);


(lib.Tween21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.kort();
	this.instance.parent = this;
	this.instance.setTransform(-75,-46.05,0.7142,0.7139);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-75,-46,150,92.1);


(lib.Tween19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.kort();
	this.instance.parent = this;
	this.instance.setTransform(-75,-46.05,0.7142,0.7139);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-75,-46,150,92.1);


(lib.Tween17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABiDzQgOAAgFgOIgUg6Ih7AAIgUA8QgDAMgMAAIg5AAQgIAAAAgIIABgGIB3lAQAFgMAMAAIAzAAQAOAAAEALIB5E9IACAIQAAAKgLAAgAAlBvIgfhjIgIgcIgBAAIgJAdIggBiIBRAAgAgoiPQgRgRAAgYQAAgXARgSQASgRAWAAQAYAAARARQARASAAAXQAAAYgRARQgRARgYAAQgWAAgSgRgAgMjFQgGAFAAAIQAAAIAGAGQAFAFAHAAQAIAAAGgFQAGgGAAgIQAAgIgGgFQgGgGgIAAQgHAAgFAGg");
	this.shape.setTransform(210.875,19.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhqCtQgPAAAAgPIAAk7QAAgPAPAAIBOAAQBYgBAjAmQAbAeAAAsQAAA7goAeQgkAeg8ABIgbgCIAABnQAAANgPAAgAgpgCIAbAAQA4AAAAg3QAAg2g7AAIgYAAg");
	this.shape_1.setTransform(182.425,26.15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgeCuQgHgBgCgCQgCgBAAgJIAAkNIhcAAQgOAAAAgPIAAglQAAgNAOAAIEMAAQAOAAgCANIgEAoQgBAMgRAAIhYAAIAAEMQAAAJgCACQgCADgHAAg");
	this.shape_2.setTransform(213.1121,-25.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgXCuQgOAAAAgPIAAiDIhti7IgCgFQAAgIAKgBIA8AAQAPAAAFALIA/B8IABAAIBBh8QAFgLAOAAIAwAAQALAAAAAIIgCAFIhpC5IAACHQAAAOgOAAg");
	this.shape_3.setTransform(184.175,-25.85);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("ABgCuQgOAAgHgMIiVjFIgBAAIAADCQABAPgQAAIguAAQgQAAgBgPIAAk8QABgQAQAAIAqAAQANAAAHALICVDHIABAAIAAjDQAAgPAPAAIAwAAQAPAAAAAQIAAE7QAAAPgPABg");
	this.shape_4.setTransform(151.65,-25.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhfCuQgQgBAAgPIAAk8QAAgOANgBIDGAAQANAAgBAMIgEApQgBAMgTAAIh4AAIAABKIBxAAQAPAAAAAOIAAAjQAAAPgPAAIhxAAIAABPICCAAQAOAAAAAOIAAAkQAAAPgOAAg");
	this.shape_5.setTransform(121.4785,-25.85);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhxCuQgOgBAAgRIAAk6QAAgPAQAAIBRAAQCEAAgBBVQABAbgOAUQgPAUgaAFIAAABQAlAEAWAVQAWAYAAAlQABBmiOABgAgxATIAABeIAfAAQAaAAAOgFQAagKAAgeQAAgfgYgLQgQgHggAAgAgxgjIATAAQAdAAALgJQAOgKAAgWQAAgkgxAAIgYAAg");
	this.shape_6.setTransform(94,-25.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-227.6,-56.5,455.29999999999995,113);


(lib.Tween16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABiDzQgOAAgFgOIgUg6Ih7AAIgUA8QgDAMgMAAIg5AAQgIAAAAgIIABgGIB3lAQAFgMAMAAIAzAAQAOAAAEALIB5E9IACAIQAAAKgLAAgAAlBvIgfhjIgIgcIgBAAIgJAdIggBiIBRAAgAgoiPQgRgRAAgYQAAgXARgSQASgRAWAAQAYAAARARQARASAAAXQAAAYgRARQgRARgYAAQgWAAgSgRgAgMjFQgGAFAAAIQAAAIAGAGQAFAFAHAAQAIAAAGgFQAGgGAAgIQAAgIgGgFQgGgGgIAAQgHAAgFAGg");
	this.shape.setTransform(210.875,19.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhqCtQgPAAAAgPIAAk7QAAgPAPAAIBOAAQBYgBAjAmQAbAeAAAsQAAA7goAeQgkAeg8ABIgbgCIAABnQAAANgPAAgAgpgCIAbAAQA4AAAAg3QAAg2g7AAIgYAAg");
	this.shape_1.setTransform(182.425,26.15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgeCuQgHgBgCgCQgCgBAAgJIAAkNIhcAAQgOAAAAgPIAAglQAAgNAOAAIEMAAQAOAAgCANIgEAoQgBAMgRAAIhYAAIAAEMQAAAJgCACQgCADgHAAg");
	this.shape_2.setTransform(213.1121,-25.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgXCuQgOAAAAgPIAAiDIhti7IgCgFQAAgIAKgBIA8AAQAPAAAFALIA/B8IABAAIBBh8QAFgLAOAAIAwAAQALAAAAAIIgCAFIhpC5IAACHQAAAOgOAAg");
	this.shape_3.setTransform(184.175,-25.85);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("ABgCuQgOAAgHgMIiVjFIgBAAIAADCQABAPgQAAIguAAQgQAAgBgPIAAk8QABgQAQAAIAqAAQANAAAHALICVDHIABAAIAAjDQAAgPAPAAIAwAAQAPAAAAAQIAAE7QAAAPgPABg");
	this.shape_4.setTransform(151.65,-25.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhfCuQgQgBAAgPIAAk8QAAgOANgBIDGAAQANAAgBAMIgEApQgBAMgTAAIh4AAIAABKIBxAAQAPAAAAAOIAAAjQAAAPgPAAIhxAAIAABPICCAAQAOAAAAAOIAAAkQAAAPgOAAg");
	this.shape_5.setTransform(121.4785,-25.85);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhxCuQgOgBAAgRIAAk6QAAgPAQAAIBRAAQCEAAgBBVQABAbgOAUQgPAUgaAFIAAABQAlAEAWAVQAWAYAAAlQABBmiOABgAgxATIAABeIAfAAQAaAAAOgFQAagKAAgeQAAgfgYgLQgQgHggAAgAgxgjIATAAQAdAAALgJQAOgKAAgWQAAgkgxAAIgYAAg");
	this.shape_6.setTransform(94,-25.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-227.6,-56.5,455.29999999999995,113);


(lib.Tween15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgrBYQgKAAAAgKIAAiWQAAgKAKAAIAdAAQAJAAABAHIABALQAJgMAIgFQALgGAOAAIAKACQAFABgBAHIgFAhQgBAGgFAAIgLgBQgTAAgMANIAABoQAAAKgKAAg");
	this.shape.setTransform(63.2083,43.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag6BCQgYgZAAgpQAAgoAZgYQAZgZAoAAQAhAAAVAWQAVAXAAAsIAAAEQAAAKgNAAIhgAAQADAQANAJQALAJARAAQAVAAAXgJIAEgBQAEAAACAFQAGAWAAAGQAAAEgGADQgbAMglAAQgpAAgZgYgAAfgSQABgMgHgJQgHgKgOABQgLAAgJAJQgIAIgCANIA5AAIAAAAg");
	this.shape_1.setTransform(47.65,44.15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAmBYQgKAAAAgLIAAhcQAAgYgUAAQgTAAgQANIAABoQAAAKgKAAIggAAQgKAAAAgKIAAiWQAAgKAKAAIAdAAQAIAAABAIIABAHQAZgUAeAAQA3AAAAA/IAABlQAAALgKAAg");
	this.shape_2.setTransform(29.175,43.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhCBAQgVgYAAgoQAAgnAYgYQAXgaApAAQArAAAXAaQAVAXAAAoQAAAogYAYQgYAagoAAQgrAAgXgagAghAAQAAAxAhAAQAiAAAAgxQAAgvghAAQgigBAAAwg");
	this.shape_3.setTransform(10.2,44.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgOB6QgLAAAAgKIAAiXQAAgJALAAIAfAAQAKAAAAAJIAACXQAAAKgKAAgAgShLQgJgHAAgMQAAgMAIgIQAJgHAKAAQALAAAIAHQAJAIAAAMQAAAMgJAHQgIAIgLAAQgKAAgIgIg");
	this.shape_4.setTransform(-3.525,40.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgdBhQgHgKgDgNQgCgJABgYIAAhDIgPAAQgGABgCgDQgCgCAAgHIAAgQQAAgJAIAAIARAAIAAgkQgBgIALgCIAhgDQAIAAAAAJIAAAoIAmAAQAJABAAAHIAAAUQAAAIgJAAIgmAAIAABEQAAAOADAHQAEAIALAAQAIAAAOgFIAFgBQAEABABAFIAEAWIABADQAAAFgGADQgVAIgYABQgfAAgNgQg");
	this.shape_5.setTransform(-14.5,41.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhJBAQgSgXAAgmQAAgqAYgaQAWgYAfAAQAcAAAOAUIABgIQABgHAHAAIAfAAQAJAAAAAJIAAB3QAAAGAFAAIADAAQAHAAAAAHIAAAVQAAAHgIABIgTAAQgaAAgHgQIgBAAQgHAHgPAHQgNAGgNAAQgkAAgUgagAgagjQgKANAAAWQAAAvAgAAQAHAAAKgEQAHgFAEgFIAAhDQgNgMgOABQgOgBgJALg");
	this.shape_6.setTransform(-30.475,44.15);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgdBhQgHgKgDgNQgBgJgBgYIAAhDIgOAAQgGABgBgDQgDgCAAgHIAAgQQABgJAHAAIAQAAIAAgkQAAgIALgCIAhgDQAIAAAAAJIAAAoIAmAAQAIABAAAHIAAAUQAAAIgIAAIgmAAIAABEQAAAOADAHQAEAIALAAQAIAAAOgFIAFgBQAEABABAFIAEAWIABADQgBAFgFADQgVAIgYABQgfAAgNgQg");
	this.shape_7.setTransform(-46.7,41.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag9BNQgFgCAAgEIABgFIAHgWQACgFADgBIAGABQAaAMAUAAQASAAAAgNQAAgIgRgHIgegMQgPgFgKgLQgKgOAAgRQAAgbAVgOQATgMAZAAQAfAAAYALQAFACAAAEIAAAEIgIAYQgBAFgFAAIgEgBQgWgIgQAAQgHAAgFADQgEADAAAFQAAAIAMAFIAjAPQAgAKAAAiQAAAcgWAPQgTAMgcAAQgcAAgfgNg");
	this.shape_8.setTransform(-60.225,44.15);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ai3DzQgPgIAAgMIADgOIAYg1QAHgNAKAAIAPAFQA8AfBAAAQAmAAAagWQAZgXAAgjQAAgpgcgYQgfgbg9AAIhOAAQgeAAAAgjIAAjcQAAgiAgAAIEPAAQAbAAAAAaIAAA1QAAAcgbAAIixAAIAABZIAGAAQBfAAA7AqQBDAuAABaQAABZhAA0Qg8AyheAAQhaAAhKgog");
	this.shape_9.setTransform(44.175,-9.425);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AihEWQgSgBgBgQQAAgJAEgIIDWmcIjLAAQgYAAAAgcIAAg3QAAgaAYAAIFIAAQAcAAgBAaIAAAyQAAAWgKATIjOGdQgMAYggABg");
	this.shape_10.setTransform(3.2,-9.95);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("ABjEWQgbAAAAgZIAAhZIj0AAQgbABAAgfIAAglQAAgXALgXICXkvQAMgYAXgBIBCAAQAXAAAAARQAAAFgDAJIiREwICFAAIAAh4QAAgYAcAAIBIAAQAcAAAAAYIAAE7QAAAZgdAAg");
	this.shape_11.setTransform(-41.225,-9.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-154.8,-62.4,309.6,124.8);


(lib.Tween14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgrBYQgKAAAAgKIAAiWQAAgKAKAAIAdAAQAJAAABAHIABALQAJgMAIgFQALgGAOAAIAKACQAFABgBAHIgFAhQgBAGgFAAIgLgBQgTAAgMANIAABoQAAAKgKAAg");
	this.shape.setTransform(63.2083,43.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag6BCQgYgZAAgpQAAgoAZgYQAZgZAoAAQAhAAAVAWQAVAXAAAsIAAAEQAAAKgNAAIhgAAQADAQANAJQALAJARAAQAVAAAXgJIAEgBQAEAAACAFQAGAWAAAGQAAAEgGADQgbAMglAAQgpAAgZgYgAAfgSQABgMgHgJQgHgKgOABQgLAAgJAJQgIAIgCANIA5AAIAAAAg");
	this.shape_1.setTransform(47.65,44.15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAmBYQgKAAAAgLIAAhcQAAgYgUAAQgTAAgQANIAABoQAAAKgKAAIggAAQgKAAAAgKIAAiWQAAgKAKAAIAdAAQAIAAABAIIABAHQAZgUAeAAQA3AAAAA/IAABlQAAALgKAAg");
	this.shape_2.setTransform(29.175,43.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhCBAQgVgYAAgoQAAgnAYgYQAXgaApAAQArAAAXAaQAVAXAAAoQAAAogYAYQgYAagoAAQgrAAgXgagAghAAQAAAxAhAAQAiAAAAgxQAAgvghAAQgigBAAAwg");
	this.shape_3.setTransform(10.2,44.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgOB6QgLAAAAgKIAAiXQAAgJALAAIAfAAQAKAAAAAJIAACXQAAAKgKAAgAgShLQgJgHAAgMQAAgMAIgIQAJgHAKAAQALAAAIAHQAJAIAAAMQAAAMgJAHQgIAIgLAAQgKAAgIgIg");
	this.shape_4.setTransform(-3.525,40.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgdBhQgHgKgDgNQgCgJABgYIAAhDIgPAAQgGABgCgDQgCgCAAgHIAAgQQAAgJAIAAIARAAIAAgkQgBgIALgCIAhgDQAIAAAAAJIAAAoIAmAAQAJABAAAHIAAAUQAAAIgJAAIgmAAIAABEQAAAOADAHQAEAIALAAQAIAAAOgFIAFgBQAEABABAFIAEAWIABADQAAAFgGADQgVAIgYABQgfAAgNgQg");
	this.shape_5.setTransform(-14.5,41.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhJBAQgSgXAAgmQAAgqAYgaQAWgYAfAAQAcAAAOAUIABgIQABgHAHAAIAfAAQAJAAAAAJIAAB3QAAAGAFAAIADAAQAHAAAAAHIAAAVQAAAHgIABIgTAAQgaAAgHgQIgBAAQgHAHgPAHQgNAGgNAAQgkAAgUgagAgagjQgKANAAAWQAAAvAgAAQAHAAAKgEQAHgFAEgFIAAhDQgNgMgOABQgOgBgJALg");
	this.shape_6.setTransform(-30.475,44.15);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgdBhQgHgKgDgNQgBgJgBgYIAAhDIgOAAQgGABgBgDQgDgCAAgHIAAgQQABgJAHAAIAQAAIAAgkQAAgIALgCIAhgDQAIAAAAAJIAAAoIAmAAQAIABAAAHIAAAUQAAAIgIAAIgmAAIAABEQAAAOADAHQAEAIALAAQAIAAAOgFIAFgBQAEABABAFIAEAWIABADQgBAFgFADQgVAIgYABQgfAAgNgQg");
	this.shape_7.setTransform(-46.7,41.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag9BNQgFgCAAgEIABgFIAHgWQACgFADgBIAGABQAaAMAUAAQASAAAAgNQAAgIgRgHIgegMQgPgFgKgLQgKgOAAgRQAAgbAVgOQATgMAZAAQAfAAAYALQAFACAAAEIAAAEIgIAYQgBAFgFAAIgEgBQgWgIgQAAQgHAAgFADQgEADAAAFQAAAIAMAFIAjAPQAgAKAAAiQAAAcgWAPQgTAMgcAAQgcAAgfgNg");
	this.shape_8.setTransform(-60.225,44.15);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ai3DzQgPgIAAgMIADgOIAYg1QAHgNAKAAIAPAFQA8AfBAAAQAmAAAagWQAZgXAAgjQAAgpgcgYQgfgbg9AAIhOAAQgeAAAAgjIAAjcQAAgiAgAAIEPAAQAbAAAAAaIAAA1QAAAcgbAAIixAAIAABZIAGAAQBfAAA7AqQBDAuAABaQAABZhAA0Qg8AyheAAQhaAAhKgog");
	this.shape_9.setTransform(44.175,-9.425);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AihEWQgSgBgBgQQAAgJAEgIIDWmcIjLAAQgYAAAAgcIAAg3QAAgaAYAAIFIAAQAcAAgBAaIAAAyQAAAWgKATIjOGdQgMAYggABg");
	this.shape_10.setTransform(3.2,-9.95);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("ABjEWQgbAAAAgZIAAhZIj0AAQgbABAAgfIAAglQAAgXALgXICXkvQAMgYAXgBIBCAAQAXAAAAARQAAAFgDAJIiREwICFAAIAAh4QAAgYAcAAIBIAAQAcAAAAAYIAAE7QAAAZgdAAg");
	this.shape_11.setTransform(-41.225,-9.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-154.8,-62.4,309.6,124.8);


(lib.Tween13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ai3DzQgPgIAAgMIADgOIAYg1QAHgNAKAAIAPAFQA8AfBAAAQAmAAAagWQAZgXAAgjQAAgpgcgYQgfgbg9AAIhOAAQgeAAAAgjIAAjcQAAgiAgAAIEPAAQAbAAAAAaIAAA1QAAAcgbAAIixAAIAABZIAGAAQBfAAA7AqQBDAuAABaQAABZhAA0Qg8AyheAAQhaAAhKgog");
	this.shape.setTransform(130.775,16.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AidDQQgthBAAhrQAAiBA3hYQBDhrB/AAQA1AAAuANQAVAGgEAWIgMA5QgGAVgSgFQg0gKgOAAQg3AAgdAeQgfAggIA6QApgXAwAAQBQAAAuAqQAyAtAABUQAABVg0A6Qg3A+haAAQhuAAg1hRgAgiAXQgZAJgNANIAAALQAACBBPAAQAhAAATgeQARgaAAglQAAhOhDAAQgUAAgXAJg");
	this.shape_1.setTransform(85.875,15.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AA0EVQgUAAgFgEQgGgEAAgSIAAmEIhqA5QgJAGgGAAQgMAAgKgTIgWgsIgDgOQAAgLAQgJICmhfQASgLAYAAIAxAAQAWABAAAVIAAH5QAAAcgdgBg");
	this.shape_2.setTransform(39.225,15.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AghBuQgJgKgDgPQgCgLAAgcIAAhMIgQAAQgHAAgCgCQgCgDAAgIIAAgRQAAgKAJAAIATAAIAAgqQAAgKAMgBIAmgFQAIAAAAALIAAAvIAsAAQAKAAAAAIIAAAXQAAAJgKAAIgsAAIAABNQAAASAEAHQAFAJAMAAQAJAAAQgFIAGgBQAEAAACAFIAEAaIABAEQAAAFgHADQgXALgcAAQgjAAgPgTg");
	this.shape_3.setTransform(144.925,-36.425);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhTBKQgVgcAAgqQAAgxAbgeQAZgbAkAAQAgAAAQAWIABgIQABgIAIAAIAkAAQAKAAAAAKIAACIQAAAHAGAAIADAAQAIAAAAAIIAAAXQAAAKgJgBIgVAAQgfAAgIgSIgBAAQgIAJgQAHQgQAIgPAAQgpAAgWgdgAgegnQgMAOAAAZQAAA2AlAAQAJABALgHQAIgFAFgFIAAhNQgQgOgQAAQgQAAgKAOg");
	this.shape_4.setTransform(126.475,-33.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgSCMQgPgGgHgJIgDALQgCAFgHAAIgfAAQgLAAAAgMIAAkAQAAgLAJgCIAqgFQAIAAAAAIIAABfQAVgRAcAAQAdAAAWAUQAeAcABA3QAAAsgWAcQgYAegrAAQgLAAgOgGgAgjAEIAABOQASAOAPAAQAjAAAAg0QAAgzgiAAQgQAAgSALg");
	this.shape_5.setTransform(105.1,-38.175);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhTBKQgVgcAAgqQAAgxAbgeQAZgbAkAAQAgAAAQAWIABgIQABgIAIAAIAkAAQAKAAAAAKIAACIQAAAHAGAAIADAAQAIAAAAAIIAAAXQAAAKgJgBIgVAAQgfAAgIgSIgBAAQgIAJgQAHQgQAIgPAAQgpAAgWgdgAgegnQgMAOAAAZQAAA2AlAAQAJABALgHQAIgFAFgFIAAhNQgQgOgQAAQgQAAgKAOg");
	this.shape_6.setTransform(82.825,-33.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AA3CLQgNAAgFgJIg3hVIgZAAIAABTQAAALgKAAIgqAAQgLAAAAgMIAAj7QAAgIACgDQADgDAHAAIA+AAQBGAAAcAeQAWAYgBAkQABA4gxAYIAAABIBCBeIADAGQAAAGgHAAgAgrgCIAUAAQAvAAgBgtQAAgrgzAAIgPAAg");
	this.shape_7.setTransform(60.85,-37.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-154,-62.9,308,125.8);


(lib.Tween12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ai3DzQgPgIAAgMIADgOIAYg1QAHgNAKAAIAPAFQA8AfBAAAQAmAAAagWQAZgXAAgjQAAgpgcgYQgfgbg9AAIhOAAQgeAAAAgjIAAjcQAAgiAgAAIEPAAQAbAAAAAaIAAA1QAAAcgbAAIixAAIAABZIAGAAQBfAAA7AqQBDAuAABaQAABZhAA0Qg8AyheAAQhaAAhKgog");
	this.shape.setTransform(130.775,16.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AidDQQgthBAAhrQAAiBA3hYQBDhrB/AAQA1AAAuANQAVAGgEAWIgMA5QgGAVgSgFQg0gKgOAAQg3AAgdAeQgfAggIA6QApgXAwAAQBQAAAuAqQAyAtAABUQAABVg0A6Qg3A+haAAQhuAAg1hRgAgiAXQgZAJgNANIAAALQAACBBPAAQAhAAATgeQARgaAAglQAAhOhDAAQgUAAgXAJg");
	this.shape_1.setTransform(85.875,15.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AA0EVQgUAAgFgEQgGgEAAgSIAAmEIhqA5QgJAGgGAAQgMAAgKgTIgWgsIgDgOQAAgLAQgJICmhfQASgLAYAAIAxAAQAWABAAAVIAAH5QAAAcgdgBg");
	this.shape_2.setTransform(39.225,15.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AghBuQgJgKgDgPQgCgLAAgcIAAhMIgQAAQgHAAgCgCQgCgDAAgIIAAgRQAAgKAJAAIATAAIAAgqQAAgKAMgBIAmgFQAIAAAAALIAAAvIAsAAQAKAAAAAIIAAAXQAAAJgKAAIgsAAIAABNQAAASAEAHQAFAJAMAAQAJAAAQgFIAGgBQAEAAACAFIAEAaIABAEQAAAFgHADQgXALgcAAQgjAAgPgTg");
	this.shape_3.setTransform(144.925,-36.425);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhTBKQgVgcAAgqQAAgxAbgeQAZgbAkAAQAgAAAQAWIABgIQABgIAIAAIAkAAQAKAAAAAKIAACIQAAAHAGAAIADAAQAIAAAAAIIAAAXQAAAKgJgBIgVAAQgfAAgIgSIgBAAQgIAJgQAHQgQAIgPAAQgpAAgWgdgAgegnQgMAOAAAZQAAA2AlAAQAJABALgHQAIgFAFgFIAAhNQgQgOgQAAQgQAAgKAOg");
	this.shape_4.setTransform(126.475,-33.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgSCMQgPgGgHgJIgDALQgCAFgHAAIgfAAQgLAAAAgMIAAkAQAAgLAJgCIAqgFQAIAAAAAIIAABfQAVgRAcAAQAdAAAWAUQAeAcABA3QAAAsgWAcQgYAegrAAQgLAAgOgGgAgjAEIAABOQASAOAPAAQAjAAAAg0QAAgzgiAAQgQAAgSALg");
	this.shape_5.setTransform(105.1,-38.175);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhTBKQgVgcAAgqQAAgxAbgeQAZgbAkAAQAgAAAQAWIABgIQABgIAIAAIAkAAQAKAAAAAKIAACIQAAAHAGAAIADAAQAIAAAAAIIAAAXQAAAKgJgBIgVAAQgfAAgIgSIgBAAQgIAJgQAHQgQAIgPAAQgpAAgWgdgAgegnQgMAOAAAZQAAA2AlAAQAJABALgHQAIgFAFgFIAAhNQgQgOgQAAQgQAAgKAOg");
	this.shape_6.setTransform(82.825,-33.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AA3CLQgNAAgFgJIg3hVIgZAAIAABTQAAALgKAAIgqAAQgLAAAAgMIAAj7QAAgIACgDQADgDAHAAIA+AAQBGAAAcAeQAWAYgBAkQABA4gxAYIAAABIBCBeIADAGQAAAGgHAAgAgrgCIAUAAQAvAAgBgtQAAgrgzAAIgPAAg");
	this.shape_7.setTransform(60.85,-37.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-154,-62.9,308,125.8);


(lib.Tween11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A/SIaQAyg2BEgeQBFgfBNAAQBqAABZA4IAAAAQgBhPA5g4QA4g4BPAAQAzAAAqAYQgNgoAAgrQAAhwBRhQQBQhOBxAAQBvAABQBLQBPBLAEBtQAxgwBDAAQAwAAAnAZQgOgpAAgtQAAhwBQhPQBQhQBwAAQBCAAA4AdQAQirB9h0QCAh1CtAAQCsAAB/B0QB+BzARCpQA+gmBIAAQBeAABHA+QBHA+ANBbQAngTAqAAQBJAAA2AzQAdg3A1ggQA3ghBAAAQBfAABDBCQBDBDAABfQAAAogOAnQAcAPAQAbQARAbAAAhIgBAPIBSAAQAuAAAhAhQAgAhAAAuQAAAbgLAXg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-200.3,-53.7,400.70000000000005,107.5);


(lib.Tween8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.kort();
	this.instance.parent = this;
	this.instance.setTransform(-75,-46.05,0.7142,0.7139);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-75,-46,150,92.1);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.kort();
	this.instance.parent = this;
	this.instance.setTransform(-75,-46.05,0.7142,0.7139);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-75,-46,150,92.1);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAwB5QgLAAgFgHIgwhKIgWAAIAABIQAAAJgJAAIgkAAQgKABAAgKIAAjdQAAgGACgDQACgCAHgBIA1AAQA/AAAXAbQATAVAAAfQAAAxgpAWIAAAAIA5BSIACAGQAAAEgGAAgAgmgCIASAAQAoAAAAgnQAAglgsAAIgOAAg");
	this.shape.setTransform(-18.025,38.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhCB5QgMABAAgLIAAjeQAAgKAJAAICLAAQAJAAgBAJIgDAcQgBAJgMAAIhUAAIAAA0IBOAAQALAAAAAKIAAAYQAAAKgKAAIhPAAIAAA3IBaAAQAKAAAAAKIAAAaQAAAJgJAAg");
	this.shape_1.setTransform(-38.1952,38.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgUB5QgGAAgBgBQgBgBAAgGIAAi8IhAAAQgKAAAAgLIAAgaQAAgJAJAAIC8AAQAJAAgBAJIgDAcQAAAJgMAAIg+AAIAAC8QAAAFgBACQgCABgFAAg");
	this.shape_2.setTransform(-57.6702,38.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgrB5QgJAAAAgHIAAgTQAAgJAJAAIAQAAIAAirIgTAAQgIABAAgKIAAgSQAAgJAIAAIBcAAQAJAAAAAJIAAASQAAAKgJgBIgTAAIAACrIASAAQAIAAAAAJIAAASQAAAJgHgBg");
	this.shape_3.setTransform(-74.775,38.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhCB5QgKAAgBgLIAAjdQAAgKAKAAIAjAAQALAAAAALIAAC5IBYAAQAKAAAAAKIAAAbQAAAKgLgBg");
	this.shape_4.setTransform(-89.35,38.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgSAUQgJgIAAgMQAAgLAIgHQAJgIAKAAQALAAAIAIQAJAHAAALQAAAMgJAHQgIAIgLgBQgKAAgIgGg");
	this.shape_5.setTransform(-107.975,48.65);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAwB5QgLAAgFgHIgwhKIgWAAIAABIQAAAJgJAAIgkAAQgKABAAgKIAAjdQAAgGACgDQACgCAHgBIA1AAQA/AAAXAbQATAVAAAfQAAAxgpAWIAAAAIA5BSIACAGQAAAEgGAAgAgmgCIASAAQAoAAAAgnQAAglgsAAIgOAAg");
	this.shape_6.setTransform(-120.125,38.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhKB5QgKABAAgLIAAjdQAAgLAKAAIA3AAQA9AAAYAbQATAVAAAfQAAApgbAVQgaAVgpAAIgUgBIAABIQAAAJgKAAgAgdgCIATABQAnAAAAgnQAAgmgpABIgRAAg");
	this.shape_7.setTransform(-139.525,38.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AiYEVQgbABAAgZIAAn8QAAgWAVABIE+AAQAVAAgCASIgHBBQgBATgeAAIjBAAIAAB3IC1AAQAYABAAAVIAAA6QAAAXgXAAIi2AAIAAB/IDQAAQAXgBAAAWIAAA7QAAAXgWgBg");
	this.shape_8.setTransform(-23.8915,-12.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("ABtEVQgZAAgLgRIhuirIgyAAIAACmQAAAXgWgBIhTAAQgWAAAAgWIAAn4QAAgRAFgFQAFgGAQABIB6AAQCPgBA2A8QArAwAABHQAABzhfAwIAAABICDC8IAFANQAAAKgNAAgAhXgEIAoAAQBdAAAAhbQAAhWhmAAIgfAAg");
	this.shape_9.setTransform(-68.125,-12.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AjcE2IgbgUQgLgJABgIQAAgGAIgLIAxhBQgwhKAAhuQAAiBBFhQQBGhRB0AAQBJAAA2AfIAsg6QAGgIAHAAIAKAEIAkAbQALAIAAAHQAAAGgHAIIgtA7QA+BNAAB8QABCGhJBQQhFBOhzAAQhUAAg9grIgpA2QgLAOgHAAQgEAAgOgJgAhGCbQAcAfAwAAQB1AAgBi1QAAg4gKgkgAhPiBQghAvAABWQAAAjAFAdICsjjQgagQgkAAQg0AAgeAug");
	this.shape_10.setTransform(-121.85,-13.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-152.5,-60.5,305,121.1);


(lib.shell = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF2524").s().p("EgCLArVQhFgVg6grIhYhBI3+AAIiOxwIuiqkQg9koAAk2QAAplDtoxQDmofGimiQGjmjIejlQIyjuJlAAQJnAAIxDuQIeDlGjGjQGiGiDmIfQDtIxAAJlQAAE2g9EoIuiKkIiORwI3+AAIhYBBQg6ArhFAVQhEAXhIAAQhHAAhEgXgEgm9ADiQAACiApCfIOWKcIBxOEIRbAAIClB5QA/AuBOAAQBPAAA/guIClh5IRbAAIBxuEIOWqcQApidAAikQAAkRhwj5I5aZrIYt+fQgvi9hlioQhlimiSiDMgWJAmNMATogp0Qh6iiimh1Qimh1jCg8MgNiAvbMAJ5gxYQiQhRihgrQiggpimAAQhHgBhFAIMgCBAzWMgCAgzWQhFgIhHABQimAAigApQigAriRBRMAJ5AxYMgNigvbQjCA8imB1QimB1h6CiMAToAp0MgWJgmNQiSCDhlCmQhlCogvC9IYtefI5a5rQhwD6AAEQg");
	this.shape.setTransform(98.8045,99.8143,0.1521,0.1521);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFCD0E").s().p("EgCLArVQhFgVg6grIhYhBI3+AAIiOxwIuiqkQg9koAAk2QAAplDtoxQDmofGimiQGjmjIejlQIyjuJlAAQJnAAIxDuQIeDlGjGjQGiGiDmIfQDtIxAAJlQAAE2g9EoIuiKkIiORwI3+AAIhYBBQg6ArhFAVQhEAXhIAAQhHAAhEgXg");
	this.shape_1.setTransform(98.8045,99.8143,0.1521,0.1521);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Aq6K6QkgkhgBmZQABmYEgkiQEikgGYgBQGZABEhEgQEhEiAAGYQAAGZkhEhQkhEhmZAAQmYAAkikhg");
	this.shape_2.setTransform(98.75,98.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.shell, new cjs.Rectangle(0,0,197.5,197.5), null);


(lib.Q8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C7141D").s().p("AiJAXQAfgXAigWIABAAIC5AAQAOAYAKAVg");
	this.shape.setTransform(149.3719,71.7586,0.9161,0.9161);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#C7141D").s().p("AilAeQgugegegdIHkAAQgUAdgZAeg");
	this.shape_1.setTransform(135.1953,114.9295,0.9161,0.9161);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FEC538").s().p("AjwAeQgSgRgUgWIAKgUIIjAAQgRAfgSAcg");
	this.shape_2.setTransform(117.9499,109.4558,0.9161,0.9161);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C7141D").s().p("AkeAeQARgeARgdIIaAAQgJAdgQAeg");
	this.shape_3.setTransform(136.7069,103.9822,0.9161,0.9161);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FEC538").s().p("AkVAeQAQgaAXghIIEAAQgFAdgMAeg");
	this.shape_4.setTransform(121.8891,98.5085,0.9161,0.9161);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C7141D").s().p("AkFAeQAOgWAcglIHhAAQgBAdgGAeg");
	this.shape_5.setTransform(141.127,93.0349,0.9161,0.9161);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FEC538").s().p("AjwAeIAwg7IGvAAQADAfgBAcg");
	this.shape_6.setTransform(125.9634,87.5612,0.9161,0.9161);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#C7141D").s().p("AjXAeQAZgcAfgfIFsAAQAHAaAEAhg");
	this.shape_7.setTransform(145.2036,82.1105,0.9161,0.9161);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FEC538").s().p("Ai1AeQAggeAjgdIETAAQAOAfAHAcg");
	this.shape_8.setTransform(130.1339,76.6368,0.9161,0.9161);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#224498").s().p("AhcAfQBFgqBGgTIAPAQQARAUAOAZg");
	this.shape_9.setTransform(151.2728,66.7889,0.9161,0.9161);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#224498").s().p("AhzAUIADgEQAXgWAUgYIC6AAQgSAWgZAYQgTAIgjAEQgWADgXAAQgtAAgtgLg");
	this.shape_10.setTransform(142.6157,120.4821,0.9161,0.9161);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#224498").s().p("AhuAeQASgcARgfIC6AAQgRAfgSAcg");
	this.shape_11.setTransform(150.4483,109.4558,0.9161,0.9161);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#224498").s().p("AhlAeQALgeAGgdIC6AAQgHAhgKAag");
	this.shape_12.setTransform(155.1432,98.5085,0.9161,0.9161);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#224498").s().p("AhcAeQACgcgEgfIC6AAQAEAfgCAcg");
	this.shape_13.setTransform(156.5151,87.5612,0.9161,0.9161);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#224498").s().p("AhSAeQgHgcgOgfIC5AAQAOAdAIAeg");
	this.shape_14.setTransform(154.4333,76.6368,0.9161,0.9161);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FEC538").s().p("AhcAfQBFgqBGgTIAOAQQARAUAPAZg");
	this.shape_15.setTransform(134.1647,66.7889,0.9161,0.9161);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("Ah9AXQAkgbAegSIC5AAQgiAVgfAYg");
	this.shape_16.setTransform(131.1874,71.7586,0.9161,0.9161);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FEC538").s().p("Ai1gdIFrAAIgvAyQgkAJhAAAQh1AAhjg7g");
	this.shape_17.setTransform(119.5531,120.426,0.9161,0.9161);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("Ag2AeQgqgagjghIC6AAQAiAhArAag");
	this.shape_18.setTransform(107.9416,114.9295,0.9161,0.9161);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AhtAeQAQgeARgdIC6AAQgRAdgRAeg");
	this.shape_19.setTransform(103.4528,103.9822,0.9161,0.9161);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AhyAeQAPgWAcglIC6AAQgcAlgPAWg");
	this.shape_20.setTransform(110.4838,93.0349,0.9161,0.9161);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("Ah5AeQAeghAagaIC6AAQgaAageAhg");
	this.shape_21.setTransform(119.4386,82.1105,0.9161,0.9161);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FEC538").s().p("AAdFKQgsAKgwAAQhWAAhOgfQhmgqhOhdIgGgIIAEgJQAOgcAXgnQAuhOA2hFQBNhiBUhEQBqhVBsgdIAJgCIAHAGIAMAPQAOARAOAUQBBgmBCgSIAJgCIAHAGIAoA1QAqBBAQBKQAYBngfBpQgmCCh5B9IgCADIgEABQgtAOhAAAQgwAAgugKg");
	this.shape_22.setTransform(128.7334,93.4835,0.9165,0.9165);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#224498").s().p("AgUC8IgdgeQgyAig7AAQhOAAgzg5Qgzg6AGhQQAGhRA7g5QA8g6BOAAQBPAAAyA6QAzA5gGBRQgEA5gkAzIBCBGQgPAMgTAHQgQAGgNAAQgQAAgMgMgAjWhTQgjAhgDAvQgEAuAeAhQAdAhAtAAQAYAAAYgLIglgnIA4g0IAkAnQANgZACgYQAEgvgeghQgdghguAAQgtAAgiAhgABjChQgjgiAEg5QACgYANgWQAQgYAbgQIAGgCIgGgCQghgZAEgxQADgtAlgeQAkgeAxAAQAwAAAgAeQAgAegDAtQgEAwglAaQgCACgFAAQAEAAACACQAZAQALAYQAKAWgBAYQgFA5goAiQgoAgg6AAQg6AAgigggACpAhQgPAOgCAVQgCAVANAOQANANAVAAQAVAAAPgNQAPgOACgVQACgVgNgOQgNgNgVAAQgVAAgPANgAC6hzQgMALgBAQQgBAQAKAKQAKAKASAAQASAAAMgKQAMgLABgPQACgQgKgLQgLgKgSAAQgSAAgMAKg");
	this.shape_23.setTransform(58.754,106.3377,0.9169,0.9169);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("Aq6K6QkgkhgBmZQABmYEgkiQEikgGYgBQGZABEhEgQEhEiAAGYQAAGZkhEhQkhEhmZAAQmYAAkikhg");
	this.shape_24.setTransform(98.75,98.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Q8, new cjs.Rectangle(0,0,197.5,197.5), null);


(lib.logo_ = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BDD54B").s().p("ApIDaIBEjHQAjhmAegpQBHhdCAAAINEAAIgXBHIs3AAQhXAAguA6QgPAUgOAhQgIATgLAiIhEDIg");
	this.shape.setTransform(98.7744,99.0053,0.8661,0.8661);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BDD54B").s().p("AjHCwIBDjGQAahNAUgZQAogzBPAAICnAAIgYBIIiUAAQgoACgWAaQgNAQgNAlIDQAAIgYBGIjQAAIgrCAg");
	this.shape_1.setTransform(72.9442,102.6644,0.8661,0.8661);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#D1D3D4","#CECFD1","#C4C6C8","#BCBEC0"],[0,0.396,0.792,1],-14.4,-8.8,15.3,12).s().p("AjDCwIAkhqQASg0AigUQAkgVBHAAIA7AAQARAAAPgPQAPgOAHgTQABgVgHgFQgIgGgiAAIimAAIAZhIIDGAAQAxAAAQAXQARAYgRA0QgqB6hdACIhBAAQgpAAgRALQgPAJgJAbIgDAJIDnAAIgZBIg");
	this.shape_2.setTransform(99.2237,102.6644,0.8661,0.8661);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#D1D3D4","#CECFD1","#C4C6C8","#BCBEC0"],[0,0.396,0.792,1],-15.2,-10.9,11.9,8).s().p("AgYCwIAoiAIhcAAQgxAAgQgXQgRgYARgzIAph9IBIAAIguCNQgCAHAEADQADACAIAAIBjAAIAchRIBHAAIgfBRIAtAAIgWBGIgtAAIgnCAg");
	this.shape_3.setTransform(129.1134,102.6644,0.8661,0.8661);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#002F5C").s().p("Aq+FgQg2AAgagpQgZgpAUg5ICMmiQAUg6A0grQA1gsA2gBISNAAQA2AAAcAqQAcApgQA7IhwGjQgQA6gyAqQgyAqg3AAg");
	this.shape_4.setTransform(98.0501,99.1133,0.8661,0.8661);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Aq6K6QkgkhgBmZQABmYEgkiQEikgGYgBQGZABEhEgQEhEiAAGYQAAGZkhEhQkhEhmZAAQmYAAkikhg");
	this.shape_5.setTransform(98.75,98.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_, new cjs.Rectangle(0,0,197.5,197.5), null);


(lib.hjul = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AkoEpQh7h7AAiuQAAitB7h7QB7h7CtAAQCuAAB7B7QB7B7AACtQAACuh7B7Qh7B7iuAAQitAAh7h7g");
	this.shape.setTransform(143.8,143.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AouUtQkChtjHjHQjIjIhtkCQhxkLAAkkQAAkkBxkLQBtkCDIjHQDHjHEChtQELhxEjAAQElAAELBxQECBtDHDHQDHDHBtECQBxELAAEkQAAEkhxELQhtECjHDIQjHDHkCBtQkLBxklAAQkjAAkLhxgAmHufQi1BMiLCMQiMCLhMC1QhQC7AADMQAADNBQC7QBMC1CMCLQCLCMC1BMQC7BQDMAAQDNAAC7hQQC1hMCLiMQCMiLBMi1QBQi7AAjNQAAjMhQi7QhMi1iMiLQiLiMi1hMQi7hQjNAAQjLAAi8BQg");
	this.shape_1.setTransform(143.775,143.775);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.hjul, new cjs.Rectangle(0,0,287.6,287.6), null);


(lib.Tween20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.hjul();
	this.instance.parent = this;
	this.instance.setTransform(126.3,0,0.3654,0.3654,0,0,0,143.8,143.8);

	this.instance_1 = new lib.hjul();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-179.4,0,0.3654,0.3654,0,0,0,143.8,143.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-231.9,-52.5,410.8,105.1);


(lib.Cloud = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_copy
	this.instance = new lib.Tween11("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(159.4,86.65,0.5229,0.5229,0,0,0,0.1,0);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(81).to({_off:false},0).to({x:2837.2},293).wait(1));

	// Layer_1
	this.instance_1 = new lib.Tween11("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(222.35,18.15,0.3373,0.3373);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:2794.8},354).to({_off:true},1).wait(20));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(54.6,0.1,2887.3,114.7);


(lib.card = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Tween19("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(75,46.05);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.card, new cjs.Rectangle(0,0,150,92.1), null);


// stage content:
(lib._930x180_HTML5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_7
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhGHeIAAu7ICMAAIAAO7g");
	this.shape.setTransform(465,-82.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},229).wait(23));

	// Layer_6
	this.instance = new lib.Tween14("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(1010,93.4);
	this.instance._off = true;

	this.instance_1 = new lib.Tween15("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(543.4,90);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(108).to({_off:false},0).to({_off:true,x:543.4,y:90},6,cjs.Ease.sineInOut).wait(138));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(108).to({_off:false},6,cjs.Ease.sineInOut).wait(52).to({startPosition:0},0).to({x:-82.3,y:85.3},13,cjs.Ease.quintInOut).to({_off:true},1).wait(72));

	// Layer_5
	this.instance_2 = new lib.Tween16("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(869.75,99.3);
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween17("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(230.75,99.3);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(105).to({_off:false},0).to({_off:true,x:230.75},9,cjs.Ease.sineInOut).wait(138));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(105).to({_off:false},9,cjs.Ease.sineInOut).wait(49).to({startPosition:0},0).to({x:-401.15,y:94.6},15,cjs.Ease.quintInOut).to({_off:true},1).wait(73));

	// Layer_1
	this.instance_4 = new lib.Tween2("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(1086.9,90);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(46).to({_off:false},0).to({x:633.2,y:85.15},7,cjs.Ease.sineOut).wait(43).to({startPosition:0},0).wait(2).to({startPosition:0},0).to({x:4.8,y:86.3},17,cjs.Ease.quintInOut).to({_off:true},1).wait(136));

	// Layer_4
	this.instance_5 = new lib.Tween12("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(912.1,93.1);
	this.instance_5._off = true;

	this.instance_6 = new lib.Tween13("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(311,93.1);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(42).to({_off:false},0).to({_off:true,x:311},11,cjs.Ease.sineOut).wait(199));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(42).to({_off:false},11,cjs.Ease.sineOut).wait(43).to({startPosition:0},0).to({x:-317.4,y:94.25},17,cjs.Ease.quintInOut).to({_off:true},3).wait(136));

	// Bil
	this.instance_7 = new lib.kort();
	this.instance_7.parent = this;
	this.instance_7.setTransform(390,44,0.7142,0.7139);

	this.instance_8 = new lib.Tween7("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(390,43.95,1,1,3.4817,0,0,-75,-46.1);
	this.instance_8._off = true;

	this.instance_9 = new lib.Tween8("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(-157.05,43.95,1,1,3.7454,0,0,-75,-46.1);

	this.instance_10 = new lib.card();
	this.instance_10.parent = this;
	this.instance_10.setTransform(1005,90.05,1,1,0,0,0,75,46.1);
	this.instance_10._off = true;

	this.instance_11 = new lib.Tween21("synched",0);
	this.instance_11.parent = this;
	this.instance_11.setTransform(465,90.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7}]}).to({state:[{t:this.instance_8}]},38).to({state:[{t:this.instance_9}]},8).to({state:[{t:this.instance_9}]},128).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_10}]},9).to({state:[{t:this.instance_11}]},67).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(38).to({_off:false},0).to({_off:true,rotation:3.7454,x:-157.05},8,cjs.Ease.backIn).wait(206));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(175).to({_off:false},0).to({x:465},9,cjs.Ease.backOut).to({_off:true},67).wait(1));

	// Hjul
	this.instance_12 = new lib.Tween20("synched",0);
	this.instance_12.parent = this;
	this.instance_12.setTransform(477,112.2,0.292,0.2895,0,0,0,0.8,0.8);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(12).to({_off:false},0).to({y:142.2},10,cjs.Ease.backOut).wait(16).to({startPosition:0},0).to({x:-70},8,cjs.Ease.backIn).to({_off:true},138).wait(68));

	// Layer_11
	this.instance_13 = new lib.Tween22("synched",0);
	this.instance_13.parent = this;
	this.instance_13.setTransform(689.05,-49.45);
	this.instance_13._off = true;

	this.instance_14 = new lib.Tween23("synched",0);
	this.instance_14.parent = this;
	this.instance_14.setTransform(689.05,90);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(210).to({_off:false},0).to({_off:true,y:90},4,cjs.Ease.backOut).wait(38));
	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(210).to({_off:false},4,cjs.Ease.backOut).wait(20).to({x:720.05},0).to({x:462.75},7,cjs.Ease.backIn).wait(11));

	// Shell
	this.instance_15 = new lib.shell();
	this.instance_15.parent = this;
	this.instance_15.setTransform(299.3,-33.95,0.3038,0.3038,0,0,0,99.2,98.9);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(197).to({_off:false},0).to({y:90.05},7,cjs.Ease.backOut).wait(30).to({x:465.15},7,cjs.Ease.backIn).wait(11));

	// F24
	this.instance_16 = new lib.logo_();
	this.instance_16.parent = this;
	this.instance_16.setTransform(207.05,-30.95,0.3038,0.3038,0,0,0,99.2,98.6);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(192).to({_off:false},0).to({x:205.5,y:89.95},7,cjs.Ease.backOut).wait(35).to({x:216.35},0).to({x:465.15},7,cjs.Ease.backIn).wait(11));

	// Q8
	this.instance_17 = new lib.Q8();
	this.instance_17.parent = this;
	this.instance_17.setTransform(108.4,-50,0.3038,0.3038,0,0,0,99.1,98.5);
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(187).to({_off:false},0).to({regX:98.9,regY:98.6,x:108.5,y:89.95},7,cjs.Ease.backOut).wait(40).to({x:124},0).to({regX:99.1,x:465.1},7,cjs.Ease.backIn).wait(11));

	// Sky
	this.instance_18 = new lib.Cloud();
	this.instance_18.parent = this;
	this.instance_18.setTransform(-181.45,31.1,0.3896,0.3896,0,0,0,-144,57.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(252));

	// bg
	this.instance_19 = new lib.bg_930x180();
	this.instance_19.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(252));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-163.8,-40.1,1403.2,220.1);
// library properties:
lib.properties = {
	id: 'DDDE089C9D9248C48A9CFDF1E6EA452C',
	width: 930,
	height: 180,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/bg_930x180.jpg", id:"bg_930x180"},
		{src:"images/kort.jpg", id:"kort"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['DDDE089C9D9248C48A9CFDF1E6EA452C'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;