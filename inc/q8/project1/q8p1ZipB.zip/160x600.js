(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"160x600_atlas_P_", frames: [[0,0,80,53]]},
		{name:"160x600_atlas_NP_", frames: [[0,0,160,600]]}
];


// symbols:



(lib.bg160X600 = function() {
	this.initialize(ss["160x600_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.snow = function() {
	this.initialize(img.snow);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,930,600);


(lib.starbucks_un_the_go = function() {
	this.initialize(ss["160x600_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Tween8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F50D05").s().p("AgWCVQgFgIgDgNIgEgZIgBgWIACgkIAFgjQgGAAgFgFQgFgDAAgHIABgFIAOgbIAOgbIABgJIACgJIADgWIAHgZQADgLAHgJQAGgIALAAQAHAAAGAFQAHADAAAKIAAADQAAARgIAWQgIAWgLAWIgDASIgEATIgGAhIgEAhIgBAiIABAbQACAOAEAOIABAEIAAACQAAAGgFADQgDAEgGAAQgKAAgGgJg");
	this.shape.setTransform(6.375,84.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F50D05").s().p("AAACjIgGgBIgEgEIgCgHQAAgHAEgEQADgFAFgCQALgMAIgSQAHgRAFgUQAEgTACgVIADgoIAAgIIAAgFIgBgFIAAgIIgJALIgFAGIgEAFIgDADIgOALIgPAKIgSAIQgKAEgIAAQgQAAgGgKQgHgJAAgUQAAgNADgQIAJggIAMgeQAHgOAJgMQAJgLAJgHQAJgHAJAAIAMAAIALACIALAFIAKAMQAEAEAAAFQAAAHgGAFQgFAFgHAAIgHgCIgFgEIgDgDIgEgCIgHAEIgHAFQgSAQgJAZQgJAZgBAfIAAgBQAKgBANgJQANgIALgLQALgMAIgMQAJgNAAgKIgBgCIAAgCIAAgCIAAgEQAAgEAGgEQAGgFAIAAQAJAAAEAIQADAIAAAMIAFAqIACAnIgDAjIgGAoIgLAmQgGATgIAOQgIAOgKAJQgKAJgLAAg");
	this.shape_1.setTransform(-9.775,96.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F50D05").s().p("AgjBYQgMgFgIgKQgJgLgEgPQgEgPABgVQABgRAIgTQAIgTANgPQAMgPAQgJQAPgJASAAQAKAAAHAEQAHAEAEAHQAEAGABAIIABARQgBASgJAOQgJAOgOAJQgNALgOAGQgQAGgNACQADAPAHAGQAHAFAJAAIAPgCIAQgFIANgJQAGgFAEgGQACgFAGABQAGAAAFADQAFAEACAFQACAFgCAFQgHAKgKAIQgJAIgMAFQgLAFgLADQgLADgKAAQgOAAgLgFgAACg1QgIAFgIAJQgHAJgGALQgGALgDAKIATgFQAKgDAIgHQAJgGAGgIQAGgJABgLQABgHgBgCQgBgBAAAAQAAgBgBAAQAAAAgBgBQgBAAAAAAQgJAAgIAGg");
	this.shape_2.setTransform(-26.683,89.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F50D05").s().p("AhABUQgFgFAAgJIABgUIAEg/QADggAFgeQACgHAFgDQAEgEAGAAQAIAAAFAGQAGAFgCAJIgCAIIAAAEIgBACIgBAEQAHgKAJgJQAKgJALAAQALAAAHAHQAGAHAEAKIAFAVIAEASIAIAoQAFAUAIASQACAFgBAFIgDAHIgHAFIgIACIgIgCQgEgDgDgFIgeh1QgFAEgEAJIgJAUIgIAWIgHAYIgFAVIgEAPQgBAIgFAEQgFAEgGAAQgGAAgGgGg");
	this.shape_3.setTransform(-43.57,90.075);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F50D05").s().p("AguBkIgFgFIgCgGIgBgFQAAgGACgFQADgGAFgBQAEgBADABIAIABIAGAAIAIgDIANgEIAPgIIAOgLQAGgFABgGQAAgDgGgDIgLgFIgMgDIgEgBIgUgGQgMgDgKgGQgKgEgHgJQgIgJABgNQAAgQALgNQAKgMAPgJQAPgIAPgEQARgEALAAQAGAAAIADQAHADAAAIQAAAWgQAAIgHgCIgFgCQgJAAgKADIgRAIQgIAEgFAFQgFAGAAAFQAAAEAEADIAJAGIAMAFIALADIAYAIIAUAJQAJAEAFAHQAEAHAAAJQAAAQgKANQgLAMgPAJQgPAJgQAGIgfAIIgEACIgEAAQgEAAgCgCg");
	this.shape_4.setTransform(-60.35,91.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#F50D05").s().p("AgWCVQgFgIgDgNIgEgZIgBgWIACgkIAFgjQgGAAgFgFQgFgDAAgHIABgFIAOgbIAOgbIABgJIACgJIADgWIAHgZQADgLAHgJQAGgIALAAQAHAAAGAFQAHADAAAKIAAADQAAARgIAWQgIAWgLAWIgDASIgEATIgGAhIgEAhIgBAiIABAbQACAOAEAOIABAEIAAACQAAAGgFADQgDAEgGAAQgKAAgGgJg");
	this.shape_5.setTransform(-70.575,84.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F50D05").s().p("AgjBYQgMgFgIgKQgJgLgEgPQgEgPABgVQABgRAIgTQAIgTANgPQAMgPAQgJQAPgJASAAQAKAAAHAEQAHAEAEAHQAEAGABAIIABARQgBASgJAOQgJAOgOAJQgNALgOAGQgQAGgNACQADAPAHAGQAHAFAJAAIAPgCIAQgFIANgJQAGgFAEgGQACgFAGABQAGAAAFADQAFAEACAFQACAFgCAFQgHAKgKAIQgJAIgMAFQgLAFgLADQgLADgKAAQgOAAgLgFgAACg1QgIAFgIAJQgHAJgGALQgGALgDAKIATgFQAKgDAIgHQAJgGAGgIQAGgJABgLQABgHgBgCQgBgBAAAAQAAgBgBAAQAAAAgBgBQgBAAAAAAQgJAAgIAGg");
	this.shape_6.setTransform(-84.633,89.975);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#F50D05").s().p("AhABUQgFgFAAgJIABgUIAEg/QADggAFgeQACgHAFgDQAEgEAGAAQAIAAAFAGQAGAFgCAJIgCAIIAAAEIgBACIgBAEQAHgKAJgJQAKgJALAAQALAAAHAHQAGAHAEAKIAFAVIAEASIAIAoQAFAUAIASQACAFgBAFIgDAHIgHAFIgIACIgIgCQgEgDgDgFIgeh1QgFAEgEAJIgJAUIgIAWIgHAYIgFAVIgEAPQgBAIgFAEQgFAEgGAAQgGAAgGgGg");
	this.shape_7.setTransform(-101.52,90.075);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F50D05").s().p("AApBcQgEgFgEgIIgFgQIgEgTQgQAWgPALQgQALgNAAQgKAAgGgEQgGgGgEgHQgFgHgBgIIgBgQQAAgQABgLIAHgXIAKgXQAHgPAKgNQAJgOALgKQANgKALAAQAJAAAGAGQAFAHAAAGQAAAJgEADIgHAFIgHAAIgEAAQgFABgHAGQgQARgIAVQgJAUABAZQAAAHACAGQADAFACAAIAGgCIAOgLQAIgIAHgMQAJgMAGgTIAFgQIACgOQACgQADgHQADgIAMAAQAGAAAEADQAEAEAAAJIgCAOIgDAPIgDATIgBATQAAAVADAQQAFAQAFALIADAGIACAGQgBAIgFADQgHACgFAAQgHAAgFgEg");
	this.shape_8.setTransform(-118.6,90.35);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#F50D05").s().p("AhMBwQgFgOAAgWIACgjIAEglIAIgsIAJgoIAKgeQAFgMADgCQAHgCAFABQAGABAEAEQAEAEABAFQACAGgCAFIgFAQIgEALIgEAJIgDAKIgDAOIgEAXIAHgEIAGgCIAagKIAUgHIAVgDQAEgBAEADQAEACACAFQACAEgBAGQgBAFgHAEIgHADIgKADQgQACgPAGIgfAKIASAIIAMAHIAVANIARALIAQANIASAOQAHAFAAAGQABAHgFAFQgEAGgGABQgGABgGgFIgOgLIgMgJIgHgGIgNgKIgQgKIgSgKIgRgJIgBAQIgBAPQAAALADANQADANgCAMIgFAHQgEADgLAAQgMAAgEgOg");
	this.shape_9.setTransform(-135.3975,87.4583);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#F50D05").s().p("AgvBkIgEgFIgDgGIAAgFQAAgGACgFQADgGAFgBQAEgBADABIAIABIAGAAIAJgDIAMgEIAPgIIAOgLQAHgFgBgGQAAgDgFgDIgMgFIgLgDIgEgBIgUgGQgMgDgJgGQgLgEgHgJQgHgJAAgNQgBgQALgNQALgMAPgJQAPgIAPgEQARgEALAAQAGAAAHADQAIADAAAIQAAAWgRAAIgGgCIgEgCQgKAAgKADIgRAIQgIAEgGAFQgEAGAAAFQAAAEADADIAKAGIAMAFIAMADIAXAIIAUAJQAJAEAEAHQAFAHABAJQAAAQgLANQgLAMgOAJQgQAJgQAGIgeAIIgFACIgEAAQgEAAgDgCg");
	this.shape_10.setTransform(-31.25,56.125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#F50D05").s().p("AgLB9QgEgBgDgEQgDgEgCgHQgDgIAAgOIABgQIACgbIABgaIABgQIAAgRIADgRQACgHADgFQAEgEAGAAQAIAAAHAFQAGAHAAAJIgBACIAAAHIgCATIgCAaIgDAbIgBAUIAAAKIADAIIACAHIACAIQAAAJgHAFQgHAEgGAAgAgEhZQgIgGAAgNQAAgJAFgEQAEgDAKAAQAHAAAHAEQAGAEAAAOQAAALgGAEQgHAEgFABQgIAAgFgHg");
	this.shape_11.setTransform(-43.75,51.35);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F50D05").s().p("AgMCHQgFgBgCgJIgDgdIAAgdQAAglAEglIgmAHQgJABgGgEQgFgEAAgHQAAgEAEgEQADgEAIgCIAJgCIAKgCIACgBIABAAIAMgDIAPgFIAKgqIAOgqQACgFAFgDQAFgDAEAAQAHAAAGAFQAFAFgBAJQgNAggIAgIATgEIAQgBIAJACIAGAFQADADAAAEQgBAFgDAEIgBACIgBABQgGAEgGAAIgWAEIgUAGIAAAAIAAAAIgFArIgCAsIABAbIACAbQABAHgGAEQgGADgFAAg");
	this.shape_12.setTransform(-55.425,50.575);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#F50D05").s().p("AAqBcQgFgFgEgIIgFgQIgEgTQgQAVgPAMQgQALgOAAQgJAAgGgEQgGgGgFgHQgEgHgBgIIgCgQQABgQACgLIAGgXIAKgXQAHgPAJgNQAKgOAMgKQALgKALAAQAKgBAGAIQAGAGAAAGQAAAJgFADIgIAFIgGAAIgEAAQgGABgFAGQgRARgIAVQgJAUAAAZQABAHACAGQACAFADAAIAHgCIANgLQAHgIAIgMQAIgMAIgTIADgQIACgOQACgQAEgHQAEgIAMAAQAFAAAEADQADAEAAAJIgBAOIgCAPIgFATIgBATQAAAVAFAQQADAQAHALIACAGIABAGQABAHgHAEQgFACgHAAQgGABgEgFg");
	this.shape_13.setTransform(-70.85,55.35);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#F50D05").s().p("AguBiQgDgDgDgGQgCgGABgLIABgQIAAgRQAAgZgEgaQgEgagLgUQgCgDACgFQACgFAEgEQAEgEAGgCQAGgBAHAGQAGAEADAJIAGAcIABACIAAAEQAOgWARgTQASgTAYgLQAIgDAHADQAGADAEAGIABAJIgCAJQgCAFgGACIgDABIgDAAIgDABQgRAIgNANQgNANgJARQgHAPgEATQgEASAAAUIAAAPIgBAKIgCAKIgGAGQgDADgGAAQgIAAgHgFg");
	this.shape_14.setTransform(-84.475,54.3308);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#F50D05").s().p("AAACjIgGgBIgEgEIgCgHQAAgHAEgEQADgFAFgCQALgMAIgSQAHgRAFgUQAEgTACgVIADgoIAAgIIAAgFIgBgFIAAgIIgJALIgFAGIgEAFIgDADIgOALIgPAKIgSAIQgKAEgIAAQgQAAgGgKQgHgJAAgUQAAgNADgQIAJggIAMgeQAHgOAJgMQAJgLAJgHQAJgHAJAAIAMAAIALACIALAFIAKAMQAEAEAAAFQAAAHgGAFQgFAFgHAAIgHgCIgFgEIgDgDIgEgCIgHAEIgHAFQgSAQgJAZQgJAZgBAfIAAgBQAKgBANgJQANgIALgLQALgMAIgMQAJgNAAgKIgBgCIAAgCIAAgCIAAgEQAAgEAGgEQAGgFAIAAQAJAAAEAIQADAIAAAMIAFAqIACAnIgDAjIgGAoIgLAmQgGATgIAOQgIAOgKAJQgKAJgLAAg");
	this.shape_15.setTransform(-103.075,61.625);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#F50D05").s().p("AhABUQgFgFAAgJIABgUIAEg/QADggAFgeQACgHAFgDQAEgEAGAAQAIAAAFAGQAGAFgCAJIgCAIIAAAEIgBACIgBAEQAHgKAJgJQAKgJALAAQALAAAHAHQAGAHAEAKIAFAVIAEASIAIAoQAFAUAIASQACAFgBAFIgDAHIgHAFIgIACIgIgCQgEgDgDgFIgeh1QgFAEgEAJIgJAUIgIAWIgHAYIgFAVIgEAPQgBAIgFAEQgFAEgGAAQgGAAgGgGg");
	this.shape_16.setTransform(-15.52,20.075);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#F50D05").s().p("AgjBYQgMgFgIgKQgJgLgEgPQgEgPABgVQABgRAIgTQAIgTANgPQAMgPAQgJQAPgJASAAQAKAAAHAEQAHAEAEAHQAEAGABAIIABARQgBASgJAOQgJAOgOAJQgNALgOAGQgQAGgNACQADAPAHAGQAHAFAJAAIAPgCIAQgFIANgJQAGgFAEgGQACgFAGABQAGAAAFADQAFAEACAFQACAFgCAFQgHAKgKAIQgJAIgMAFQgLAFgLADQgLADgKAAQgOAAgLgFgAACg1QgIAFgIAJQgHAJgGALQgGALgDAKIATgFQAKgDAIgHQAJgGAGgIQAGgJABgLQABgHgBgCQgBgBAAAAQAAgBgBAAQAAAAgBgBQgBAAAAAAQgJAAgIAGg");
	this.shape_17.setTransform(-32.133,19.975);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#F50D05").s().p("AAqCHQgGgFgCgHIgGgRIgEgTQgQAWgPALQgQAMgNAAQgKAAgGgFQgHgFgEgHQgDgIgCgIIgCgQQAAgQACgLIAHgXIAKgYQAHgNAJgOQAKgOALgKQAMgKALAAQAKAAAGAHQAGAGgBAGQABAJgFAEIgIAEIgGAAIgEAAQgGABgFAGQgRAQgIAVQgIAVAAAZQgBAIADAFQADAFACAAIAGgCIAOgLQAIgHAHgNQAJgMAGgUIAFgQIABgNQACgQAEgHQAEgIALAAQAGAAAEAEQADADABAJIgBAPIgEANIgEAUIAAAUQAAAUADAQQAFARAFAKIAEAGIABAGQAAAIgHADQgGADgFAAQgHAAgEgFgAAKhEQgHgDgEgFQgFgFgDgHQgCgGAAgIQAAgJADgHQAEgHAFgFQAHgEAHgCIAOgDQAQAAAJALQAJALAAAOQABAMgHAKQgFAJgLAEQgIADgHAAQgJAAgHgDgAAWhyIgEACQgGAFgBAGQAAAGAEAEQADAEAEABIAEAAQAFAAAEgEQAFgEAAgGQAAgFgDgFQgCgEgGgBIgDAAg");
	this.shape_18.setTransform(-60.25,16.025);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#F50D05").s().p("AgPCdQgGgEgBgIIgGg4QgDgcAAgdIAAgFIAAgEIgFACIgCABIgEACIgHADQgEABgFgBIgIgFIgEgIQgBgFACgEQACgFAGgDIgBAAQARgIAPgEIADgdIAEggIAIggQAFgQAGgMQAFgMAJgIQAIgIALAAQANAAAJAIQAIAIAFALQAFALACANQABAMgBAKQgDAOgNAAQgHAAgGgFQgGgEABgKIAAgIIgBgLIgCgKQgCgEgDAAQgCAAgDAFIgGANIgEAPIgDAKQgEAQgCAPIgCAgIALgCIAJgBIAJAAIAJgBIALABQAFACACAEIAAgBQAFAIgEAIQgEAIgLABIgCABIgBAAIgUACIgUADIACA6IAFA7IAEAFIACAHQAAAGgEAFQgEAFgJABIgBABQgGAAgGgEg");
	this.shape_19.setTransform(-74.7542,15.9528);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#F50D05").s().p("AAACjIgGgBIgEgEIgCgHQAAgHAEgEQADgFAFgCQALgMAIgSQAHgRAFgUQAEgTACgVIADgoIAAgIIAAgFIgBgFIAAgIIgJALIgFAGIgEAFIgDADIgOALIgPAKIgSAIQgKAEgIAAQgQAAgGgKQgHgJAAgUQAAgNADgQIAJggIAMgeQAHgOAJgMQAJgLAJgHQAJgHAJAAIAMAAIALACIALAFIAKAMQAEAEAAAFQAAAHgGAFQgFAFgHAAIgHgCIgFgEIgDgDIgEgCIgHAEIgHAFQgSAQgJAZQgJAZgBAfIAAgBQAKgBANgJQANgIALgLQALgMAIgMQAJgNAAgKIgBgCIAAgCIAAgCIAAgEQAAgEAGgEQAGgFAIAAQAJAAAEAIQADAIAAAMIAFAqIACAnIgDAjIgGAoIgLAmQgGATgIAOQgIAOgKAJQgKAJgLAAg");
	this.shape_20.setTransform(-103.125,26.625);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#F50D05").s().p("AgoBOQgKgHgIgMQgHgLgDgOQgEgPAAgNQAAgPAEgOQAFgNAHgLQAHgKAKgGQAKgGALAAIAEAAIAXgLQALgEAJAAQALAAAJAFQAIAEAFAIQAFAIADAJQADAJAAAKQAAARgHAUQgIAUgMASQgMARgQAMQgQAMgQAAQgPAAgLgHgAgUgbQgCAEgEACIgJADIgDAPIAAALQAAATAGAMQAHAMAKAAQAKAAAJgHQAJgIAIgMQAIgLAEgNQAFgOAAgMQAAgJgEgHQgDgIgJAAIgMACIgKAEIgJAGIgIAFIAAAAIgBAAg");
	this.shape_21.setTransform(-120.375,20.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-147.9,-4,160,115);


(lib.Tween6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhBBZQgVgfAAg4QAAg4AWggQAYgkApAAQAsAAAWAjQAUAfAAA4QAAA5gVAfQgWAjgsgBQgqAAgXghgAgfAAQAAAqAIARQAIAQAPAAQARAAAHgQQAHgRAAgqQAAhLgeAAQggAAAABLg");
	this.shape.setTransform(-18.475,52.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhBBZQgVgfAAg4QAAg4AWggQAYgkApAAQAsAAAWAjQAUAfAAA4QAAA5gVAfQgWAjgsgBQgqAAgXghgAgfAAQAAAqAIARQAIAQAPAAQARAAAHgQQAHgRAAgqQAAhLgeAAQggAAAABLg");
	this.shape_1.setTransform(-37.825,52.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgSBRQgIgIgBgLQAAgMAJgIQAIgGAKgBQALABAIAGQAJAIgBALQAAAMgJAHQgHAIgLgBQgJAAgJgGgAgSgpQgIgIgBgLQAAgMAJgHQAIgIAKABQALgBAIAIQAJAHgBAMQAAALgJAIQgHAGgLABQgJgBgJgGg");
	this.shape_2.setTransform(-51.4,55.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag9BpQgagUAAgiQAAgPAHgOQAMgUAVgKQgMgHgJgNQgJgOABgPQgBgfAXgRQAWgRAhAAQAgAAAVAQQAWASABAeQAAAPgKAOQgJANgNAIQASAHALAOQAOAQAAASQAAAigbAWQgZAUgkAAQglAAgYgSgAgiAwQAAAOAKAJQAKAKAOAAQAQAAAJgJQAJgJAAgPQABgMgNgLQgLgJgNgFQggASAAATgAgShJQgHAHAAAIQAAAKAIAJQAJAJAJAFQAYgPAAgQQAAgKgIgHQgHgHgKAAQgKAAgIAHg");
	this.shape_3.setTransform(-65.1,52.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgpBVQgKAAAAgJIAAiRQAAgKAKAAIAcAAQAJAAAAAHIABAKQAJgMAIgFQAKgFAPAAIAJABQAFABgBAHIgFAgQgBAGgFAAIgLgBQgSAAgMANIAABlQAAAJgJAAg");
	this.shape_4.setTransform(-88.5077,55.575);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhHBXIgJgIQgDgDgBgCQAAgDAEgFIAKgLQgOgWAAghQgBglAXgYQAYgZAnAAQAaAAATAKIAJgKQAFgHAIAHIAJAIQAEAEAAADQAAACgEAEIgIAJQARAXAAAiQAAAmgYAYQgXAZgnAAQgcAAgUgMIgJALQgDAEgDAAQgDAAgFgEgAgTArQAJAGAKAAQARAAAJgPQAJgNgBgVIgBgPgAgaghQgHANAAAUIABANIAwg4QgGgFgKAAQgQAAgKAPg");
	this.shape_5.setTransform(-105.4,55.7935);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgfB9QgJAAAAgKIAAh4IgRAAQgGAAgCgCQgCgCAAgHIAAgPQAAgJAIAAIATAAIAAgLQAAhJA+AAQAWAAASAIQAGADAAAFIgBAIIgDARQgCAJgIgDQgNgEgKAAQgVAAAAAaIAAAPIAiAAQAIAAAAAHIAAAUQAAAIgIAAIgiAAIAAB3QAAALgKAAg");
	this.shape_6.setTransform(-120.625,51.625);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag7BLQgFgCAAgFIABgEIAHgVQACgGADAAIAFABQAaALATAAQARAAAAgMQAAgIgQgHIgdgLQgPgFgJgLQgLgNAAgRQAAgaAVgOQATgLAYgBQAeABAYAKQAFACAAAEIgBAEIgHAYQgBAEgFAAIgEgBQgWgIgQAAQgGAAgFAEQgEADAAAEQAAAIAMAFIAiAOQAfAKAAAhQAAAbgWAOQgSANgbAAQgbAAgegNg");
	this.shape_7.setTransform(0.075,21);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAeB6QgLAAgFgIIglhEIAAAAIAABDQAAAJgJAAIghAAQgJAAAAgJIAAjcQAAgIAIgCIAkgEQAHAAAAAJIAACHIAAAAIAlg8QAEgGAHABIAlAAQAGgBAAAFQAAABAAAAQAAABAAAAQgBABAAAAQAAABgBABIgsA8IAzBTQACAFAAADQAAAEgHAAg");
	this.shape_8.setTransform(-15.2,17.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgvBBQgWgWAAgoQAAgoAXgZQAXgYAogBQAZAAAWAKQAFACgBAIIgGAYQgBAFgDAAIgFgCQgRgGgNAAQgUAAgJAMQgLANAAAVQAAAXALANQAJAMASgBQAQABASgIIADgBQAEABABAEIAHAbQAAADgFADQgXALgdAAQgmgBgWgWg");
	this.shape_9.setTransform(-32.475,21);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhNAYIAAhjQAAgJAKAAIAfAAQAKAAAAAJIAABaQAAAYATAAQASAAAQgNIAAhlQAAgJAKAAIAfAAQAKAAAAAJIAACQQAAALgLAAIgcAAQgIAAgBgHIAAgHQgYATgeAAQg1AAAAg9g");
	this.shape_10.setTransform(-50.1,21.275);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgPB3QgNgFgHgIIgBAKQgCAEgGAAIgbAAQgJAAAAgKIAAjaQAAgJAIgCIAkgEQAHAAAAAHIAABRQARgPAXAAQAaAAASARQAaAYAAAuQAAAmgSAYQgVAZgkAAQgJAAgMgFgAgdAEIAABCQAOAMANAAQAeAAAAgtQAAgrgdAAQgOAAgOAKg");
	this.shape_11.setTransform(-69.025,17.325);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgpBVQgKAAAAgJIAAiRQAAgKAKAAIAcAAQAJAAAAAHIABAKQAJgMAIgFQAKgFAPAAIAJABQAFABgBAHIgFAgQgBAGgFAAIgLgBQgSAAgMANIAABlQAAAJgJAAg");
	this.shape_12.setTransform(-84.5077,20.775);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhHA/QgRgXgBglQAAgpAYgZQAVgYAfAAQAbAAANAUIABgIQABgGAGAAIAfAAQAJAAAAAIIAAB0QAAAGAEgBIAEAAQAGAAAAAHIAAAUQABAIgJAAIgSAAQgaAAgGgQIgBAAQgHAIgOAHQgNAFgNABQgjAAgTgZgAgagiQgJANgBAVQAAAvAggBQAHAAAJgFQAIgEADgFIAAhBQgMgLgOAAQgOAAgJAKg");
	this.shape_13.setTransform(-101.35,21);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgcBeQgHgJgDgNQgCgJABgYIAAhAIgOAAQgGAAgCgCQgBgCgBgHIAAgPQABgJAHAAIAQAAIAAgjQAAgIAKgBIAggEQAIAAgBAIIAAAoIAmAAQAIAAAAAHIAAAUQAAAIgIAAIgmAAIAABBQABAPADAGQADAIALAAQAIAAAOgEIAEgBQAEAAABAEIAEAWIAAADQABAFgGACQgTAJgYAAQgeAAgNgPg");
	this.shape_14.setTransform(-118.1,18.825);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AhKBuQgHgBAAgGIABgFIAKgcQABgGAGAAIAFABQAcAKAaAAQALAAAJgFQALgHAAgLQAAgPgVgKIgsgVQgqgSAAgqQAAgfAagUQAZgRAfAAQAjAAAgAOQAIADAAAFIgCAEIgKAbQgDAGgEAAIgGgBQgZgMgWAAQgcAAAAAWQAAAMAXAJIAmARQAsAUAAApQAAAkgaAVQgXAVgkAAQgkAAgjgNg");
	this.shape_15.setTransform(-134.525,17.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgNB3QgLAAAAgKIAAiSQAAgJALAAIAdAAQAKAAAAAJIAACSQAAAKgKAAgAgRhIQgJgIAAgMQAAgLAIgIQAIgGAKAAQALAAAIAGQAIAIAAALQAAAMgIAIQgIAGgLAAQgJAAgIgGg");
	this.shape_16.setTransform(-23.175,-17.35);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgpBVQgKAAAAgJIAAiRQAAgKAKAAIAcAAQAJAAAAAHIABAKQAJgMAIgFQAKgFAPAAIAJABQAFABgBAHIgFAgQgBAGgFAAIgLgBQgSAAgMANIAABlQAAAJgJAAg");
	this.shape_17.setTransform(-33.2577,-14.025);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgfB9QgJAAAAgKIAAh4IgRAAQgGAAgCgCQgCgCAAgHIAAgPQAAgJAIAAIATAAIAAgLQAAhJA+AAQAWAAASAIQAGADAAAFIgBAIIgDARQgCAJgIgDQgNgEgKAAQgVAAAAAaIAAAPIAiAAQAIAAAAAHIAAAUQAAAIgIAAIgiAAIAAB3QAAALgKAAg");
	this.shape_18.setTransform(-45.875,-17.975);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("Ag1BvQgIgCADgKIAFgUQAEgIAIADQATAIATAAQAUAAAIgLQAGgIAAgSIAAgMQgSAPgWAAQgfAAgTgTQgWgVAAgnQAAglATgaQAWgbAjAAQALAAALAFQALAEAGAJIABgHQAAgHAJAAIAcAAQAKAAAAAKIAACNQAABYhSAAQgbAAgagLgAgQhHQgLAMAAAZQAAAXALALQAHAHAMgBQAQAAAMgLIAAhAQgLgLgPAAQgMAAgJAJg");
	this.shape_19.setTransform(-63.4,-10.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgQB6QgIAAgBgJIAAjcQABgIAHgCIAjgEQAHAAAAAJIAADgQABAKgKAAg");
	this.shape_20.setTransform(-77.15,-17.675);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AhHA+QgRgXAAgjQAAgqAXgaQAVgXAfAAQAaABAOATIABgHQABgIAGAAIAfAAQAJAAAAAJIAAB0QAAAGAEAAIAEAAQAGAAAAAGIAAAUQABAIgJAAIgSAAQgaAAgGgPIgBAAQgHAHgOAGQgNAHgNAAQgjAAgTgagAgZgiQgLAMAAAWQAAAuAgAAQAHABAJgGQAIgEADgFIAAhBQgMgLgOAAQgOAAgIAKg");
	this.shape_21.setTransform(-91.35,-13.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgKBTQgIAAgDgHIg9iWIgBgDQAAgFAIAAIAmAAQAJAAACAJIAWBFIAGAXIABAAIAGgXIAXhFQADgJAJAAIAgAAQAIAAAAAGIgBAEIg+CUQgCAHgJAAg");
	this.shape_22.setTransform(-109.9,-13.775);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAlBVQgKAAAAgKIAAhZQAAgYgUAAQgSAAgPANIAABkQAAAKgJAAIghAAQgJAAAAgJIAAiRQAAgKAJAAIAcAAQAJAAABAHIABAHQAYgTAdAAQA2AAAAA9IAABiQAAAKgKAAg");
	this.shape_23.setTransform(-25.1,-48.825);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("Ag4BAQgYgYAAgoQAAgmAZgZQAYgYAnABQAggBAUAWQAVAVAAAsIAAAEQAAAJgNAAIheAAQADAQANAKQALAIAQAAQAVAAAWgJIAEgBQAEAAABAFQAHAVAAAFQAAAEgHAEQgZALgkAAQgoABgYgYgAAfgSQAAgLgHgJQgHgKgNAAQgLAAgIAJQgIAJgCAMIA4AAIAAAAg");
	this.shape_24.setTransform(-43.825,-48.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgPB3QgNgFgHgIIgBAKQgCAEgGAAIgbAAQgJAAAAgKIAAjaQAAgJAIgCIAkgEQAHAAAAAHIAABRQARgPAXAAQAaAAASARQAaAYAAAuQAAAmgSAYQgVAZgkAAQgJAAgMgFgAgdAEIAABCQAOAMANAAQAeAAAAgtQAAgrgdAAQgOAAgOAKg");
	this.shape_25.setTransform(-70.375,-52.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AhHBXIgJgIQgDgDAAgCQAAgDADgFIAKgLQgOgWAAghQgBglAXgYQAYgZAnAAQAaAAATAKIAJgKQAFgHAIAHIAJAIQAEAEAAADQAAACgDAEIgJAJQARAXAAAiQAAAmgYAYQgXAZgnAAQgcAAgTgMIgJALQgEAEgDAAQgDAAgFgEgAgTArQAIAGALAAQARAAAJgPQAJgNgBgVIgBgPgAgaghQgHANgBAUIACANIAwg4QgGgFgKAAQgQAAgKAPg");
	this.shape_26.setTransform(-90.2,-48.6065);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAtB2QgNAAgGgKIg/hYIgBAAIAABYQAAAKgKAAIgiAAQgLAAAAgKIAAjYQAAgJALAAIAiAAQAKAAAAAJIAABeIABAAIA7hgQAFgHAKAAIAiAAQAGAAAAAFIgCAFIhGBoIBVBsQAEAEAAADQAAAGgHAAg");
	this.shape_27.setTransform(-109.875,-52.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-147.9,-73.6,159,147.2);


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.snow();
	this.instance.parent = this;
	this.instance.setTransform(-196.8,-610,0.6559,0.6559,0,-90,90);

	this.instance_1 = new lib.snow();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-196.8,610.05,0.6559,0.6559,-90);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-196.8,-610,393.6,1220.1);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.snow();
	this.instance.parent = this;
	this.instance.setTransform(-196.8,-610.05,0.6559,0.6559,0,-90,90);

	this.instance_1 = new lib.snow();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-196.8,610,0.6559,0.6559,-90);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-196.8,-610,393.6,1220);


(lib.Arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F3161C").s().p("ACgA4QgFgBgDgFQgCgEABgFIANgsQhZArhqAAQg4AAg3gMQgcgGgVgHQgFgCgCgEQgCgFACgEQACgFAEgCQAFgCAFACQAsAOA/AGQB8ALBjgvIgqgJQgFAAgCgFQgDgEABgFQABgFAEgDQAEgDAFABIBZASIgZBVQgCAKgKAAg");
	this.shape.setTransform(0.0179,0.0107);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19.9,-5.7,39.9,11.4);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_copy_copy_copy_copy
	this.instance = new lib.Tween3("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(57.75,-924.25,1,1,0,0,180);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(240).to({_off:false},0).to({x:49.1,y:-314.25},240).wait(1));

	// Layer_1_copy_copy_copy
	this.instance_1 = new lib.Tween3("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(50.25,-316,1,1,0,0,180);

	this.instance_2 = new lib.Tween4("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-49.15,899,1,1,0,0,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},480).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true,x:-49.15,y:899},480).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-245.9,-1534.3,500.5,3043.3999999999996);


// stage content:
(lib._160x600HTML5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_78 = function() {
		var _this = this;
		/*
		Stop a Movie Clip/Video
		Stops the specified movie clip or video.
		*/
		_this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(78).call(this.frame_78).wait(1));

	// Layer_2
	this.instance = new lib.starbucks_un_the_go();
	this.instance.parent = this;
	this.instance.setTransform(2,572,0.4874,0.4857);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(79));

	// Snow
	this.instance_1 = new lib.Symbol1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(146.8,305);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(79));

	// FlashAICB
	this.instance_2 = new lib.Arrow("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(120.55,292.4,1.8802,1.9453,0,-104.9999,75.0002);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(51).to({_off:false},0).to({scaleX:2.88,scaleY:2.88,skewX:-105,skewY:74.9999,x:120.45,y:333.15,alpha:1},9).wait(18).to({startPosition:0},0).wait(1));

	// KØB
	this.instance_3 = new lib.Tween6("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(148.45,-27.75);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(17).to({_off:false},0).to({y:72.25,alpha:1},8).wait(54));

	// rød
	this.instance_4 = new lib.Tween8("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(148.45,100.35);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(33).to({_off:false},0).to({y:160.35,alpha:1},8).wait(37).to({startPosition:0},0).wait(1));

	// BG
	this.instance_5 = new lib.bg160X600();
	this.instance_5.parent = this;
	this.instance_5.setTransform(0,1);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(79));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(80,-321,313.9,922);
// library properties:
lib.properties = {
	id: '518BD99F26E84AE1902D4F543675FC66',
	width: 160,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/snow.png", id:"snow"},
		{src:"images/160x600_atlas_P_.png", id:"160x600_atlas_P_"},
		{src:"images/160x600_atlas_NP_.jpg", id:"160x600_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['518BD99F26E84AE1902D4F543675FC66'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;