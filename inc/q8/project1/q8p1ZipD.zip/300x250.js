(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"300x250_atlas_P_", frames: [[0,0,80,53]]},
		{name:"300x250_atlas_NP_", frames: [[0,0,300,250]]}
];


// symbols:



(lib.bg300x250 = function() {
	this.initialize(ss["300x250_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.snow = function() {
	this.initialize(img.snow);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,930,600);


(lib.starbucks_un_the_go = function() {
	this.initialize(ss["300x250_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Tween8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F50D05").s().p("AgRB0QgEgGgCgKIgDgUIgBgRIACgcIADgcQgFAAgEgCQgDgDAAgFIAAgFIALgVIALgVIABgHIACgIIACgQIAFgTQADgKAFgGQAFgHAIABQAGAAAFADQAFAEAAAGIAAADQAAANgGARQgGASgJAQIgDAPIgDAPIgEAaIgDAaIgBAaIAAAVQACALADALIABADIAAABQAAAFgEADQgCACgFAAQgHABgFgIg");
	this.shape.setTransform(-12.775,5.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F50D05").s().p("AAACAIgEgCIgDgCIgCgGQAAgFADgEQADgDADgCQAJgKAGgNQAFgOAEgPQAEgPABgQIACggIAAgGIAAgEIAAgEIgBgGIgGAIIgEAGIgEADIgCACIgKAJIgMAIIgPAGQgHADgHAAQgMAAgFgIQgFgGAAgQQAAgKACgNIAHgYIAKgYQAFgLAHgJQAHgJAHgFQAHgGAHAAIAJABIAJABIAIAEIAJAJQACADAAAEQAAAFgEAEQgEAEgGAAIgFgBIgEgEIgCgCIgDgBIgGACIgFAFQgOAMgHAUQgHATgBAYIAAAAQAIgBAKgHQAKgGAIgJQAJgJAHgKQAGgKAAgIIAAgBIAAgCIgBgBIAAgDQAAgEAFgDQAFgEAGAAQAHAAADAHQADAGgBAJIAEAhIACAfIgCAbIgFAfIgIAeQgFAOgGALQgHALgHAHQgIAHgJAAg");
	this.shape_1.setTransform(-25.375,14.325);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F50D05").s().p("AgbBFQgJgFgHgIQgGgHgEgMQgDgMABgQQABgNAGgPQAHgPAJgLQAKgMAMgHQAMgIAOAAQAIAAAFADQAFAEADAFQAEAFABAHIABAMQgBAPgHALQgIAKgKAHQgKAJgLAEQgMAFgLACQADALAFAFQAGAEAGAAIAMgCIAMgEIALgHIAHgIQACgEAFABQAEAAAEACQAEADACAEQABAEgCAEQgFAIgHAGQgIAGgJAEQgIAEgJACQgJACgIAAQgKAAgJgDgAABgqQgFAFgGAHQgGAHgFAIQgEAJgCAHIAOgCQAIgEAGgFQAHgEAFgHQAFgHAAgIQABgGgBgCQgBAAAAgBQAAAAgBAAQAAAAgBAAQAAAAAAAAQgHgBgHAEg");
	this.shape_2.setTransform(-38.5554,9.15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F50D05").s().p("AgxBCQgFgFAAgGIABgQIAEgxQABgZAFgXQABgGAEgCQAEgDAEAAQAGAAAEAEQAFAEgCAIIgBAGIgBACIAAACIgBAEQAGgIAHgHQAHgIAJAAQAIAAAGAGQAFAGACAIIAFAQIADAOIAGAfQAEAPAGAPQACADgBAEIgDAGIgFAEIgGABIgHgCQgDgBgCgFIgXhbQgEAEgDAHIgHAPIgGARIgGASIgEARIgDAMQgBAGgEADQgEADgEAAQgFAAgEgEg");
	this.shape_3.setTransform(-51.7583,9.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F50D05").s().p("AgkBOIgEgEIgBgFIgBgEQAAgEACgEQACgFAEgBQADgBACABIAGABIAFAAIAHgCIAJgEIAMgGIALgIQAFgEAAgFQAAgCgEgDIgJgEIgJgCIgDAAIgQgFQgJgCgIgFQgIgDgFgHQgGgHAAgKQAAgNAIgKQAJgKALgGQAMgHAMgDQANgDAIAAQAGAAAFACQAGADAAAGQAAARgNAAIgFgBIgDgCQgIAAgIADIgNAFQgGAEgEAEQgEAEAAAEQAAADADADIAHAFIAKADIAIADIATAGIAQAHQAGADAEAFQAEAFAAAIQAAANgIAJQgIAKgMAHQgMAHgNAFIgYAGIgDABIgDABQgDAAgCgCg");
	this.shape_4.setTransform(-64.825,10.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#F50D05").s().p("AgRB0QgEgGgCgKIgDgUIgBgRIACgcIADgcQgFAAgEgCQgDgDAAgFIAAgFIALgVIALgVIABgHIACgIIACgQIAFgTQADgKAFgGQAFgHAIABQAGAAAFADQAFAEAAAGIAAADQAAANgGARQgGASgJAQIgDAPIgDAPIgEAaIgDAaIgBAaIAAAVQACALADALIABADIAAABQAAAFgEADQgCACgFAAQgHABgFgIg");
	this.shape_5.setTransform(-72.775,5.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F50D05").s().p("AgbBFQgJgFgHgIQgGgHgEgMQgDgMABgQQABgNAGgPQAHgPAJgLQAKgMAMgHQAMgIAOAAQAIAAAFADQAFAEADAFQAEAFABAHIABAMQgBAPgHALQgIAKgKAHQgKAJgLAEQgMAFgLACQADALAFAFQAGAEAGAAIAMgCIAMgEIALgHIAHgIQACgEAFABQAEAAAEACQAEADACAEQABAEgCAEQgFAIgHAGQgIAGgJAEQgIAEgJACQgJACgIAAQgKAAgJgDgAABgqQgFAFgGAHQgGAHgFAIQgEAJgCAHIAOgCQAIgEAGgFQAHgEAFgHQAFgHAAgIQABgGgBgCQgBAAAAgBQAAAAgBAAQAAAAgBAAQAAAAAAAAQgHgBgHAEg");
	this.shape_6.setTransform(-83.7554,9.15);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#F50D05").s().p("AgxBCQgFgFAAgGIABgQIAEgxQABgZAFgXQABgGAEgCQAEgDAEAAQAGAAAEAEQAFAEgCAIIgBAGIgBACIAAACIgBAEQAGgIAHgHQAHgIAJAAQAIAAAGAGQAFAGACAIIAFAQIADAOIAGAfQAEAPAGAPQACADgBAEIgDAGIgFAEIgGABIgHgCQgDgBgCgFIgXhbQgEAEgDAHIgHAPIgGARIgGASIgEARIgDAMQgBAGgEADQgEADgEAAQgFAAgEgEg");
	this.shape_7.setTransform(-96.9583,9.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F50D05").s().p("AAgBIQgDgEgDgGIgEgNIgDgPQgNARgLAJQgNAJgLAAQgHAAgEgEQgFgEgEgFQgCgGgCgHIgBgMQAAgMACgJIAEgRIAIgSQAFgMAIgLQAIgKAIgIQAKgJAIAAQAIABAFAFQAEAFAAAFQAAAHgEADIgGADIgEAAIgEgBQgEACgFAFQgMANgHAQQgGAQgBASQAAAHACAEQADAEACABIAEgDIALgIQAGgFAFgKQAIgLAEgOIAEgMIABgLQABgNADgFQADgGAKAAQAEAAADACQADADAAAHIAAAMIgDALIgDAPIgBAOQAAARADAMQADANAFAIIACAFIABAFQAAAFgFADQgFACgFABQgEgBgEgDg");
	this.shape_8.setTransform(-110.25,9.45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#F50D05").s().p("Ag7BYQgDgLAAgSIAAgaIAEgeIAFgiIAIgfIAIgXQADgJADgCQAFgCAEABQAFABADADQAEADABAEQAAAEgBAFIgEAMIgDAIIgDAHIgCAIIgDALIgDASIAGgDIAEgCIAUgIIAQgEIAQgDQADgBADACQAEACABAEQACADgBAEQgBAFgGADIgEACIgJACQgMACgMAFIgYAHIAOAGIAJAGIARAKIANAJIANAKIANALQAGADAAAFQAAAGgCAEQgEAEgEABQgGABgEgEIgMgIIgJgIIgEgEIgLgIIgNgIIgNgIIgOgHIgBANIAAALQAAAJACAKQACAKgBAJIgEAGQgDADgIAAQgKAAgDgLg");
	this.shape_9.setTransform(-123.35,7.1833);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#F50D05").s().p("AgkBOIgEgEIgBgFIgBgEQAAgEACgEQACgFAEgBQADgBACABIAGABIAFAAIAHgCIAJgEIAMgGIALgIQAFgEAAgFQAAgCgEgDIgJgEIgJgCIgDAAIgQgFQgJgCgIgFQgIgDgFgHQgGgHAAgKQAAgNAIgKQAJgKALgGQAMgHAMgDQANgDAIAAQAGAAAFACQAGADAAAGQAAARgNAAIgFgBIgDgCQgIAAgIADIgNAFQgGAEgEAEQgEAEAAAEQAAADADADIAHAFIAKADIAIADIATAGIAQAHQAGADAEAFQAEAFAAAIQAAANgIAJQgIAKgMAHQgMAHgNAFIgYAGIgDABIgDABQgDAAgCgCg");
	this.shape_10.setTransform(35.025,-23.925);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#F50D05").s().p("AgIBhQgDAAgDgDQgCgDgDgGQgBgGAAgMIAAgLIACgWIABgUIABgNIAAgNIACgMQABgGADgEQADgDAFAAQAGAAAFAEQAEAFAAAHIAAACIAAAFIgBAPIgCAUIgDAVIgBAQIABAIIACAGIACAGIABAGQAAAHgGADQgFAEgFAAgAgEhFQgFgFgBgKQABgIAEgCQADgDAHAAQAGAAAFAEQAFADAAAKQAAAJgFADQgFAEgEAAQgGAAgFgFg");
	this.shape_11.setTransform(25.3,-27.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F50D05").s().p("AgKBqQgEgBgBgHIgCgXIAAgWQAAgdADgdIgdAFIgBAAQgHAAgEgCQgEgDAAgFQAAgEADgDQACgDAGgBIAHgCIAIgCIACAAIABAAIAJgDIALgEIAJggIAKghQACgEAEgDQADgCAEAAQAFAAAFAEQAEAEgBAHQgLAZgFAZIAOgDIANgBIAHACIAFAEQACACAAADQgBADgDAEIAAABIgBABQgFADgEAAIgRAEIgQAEIAAAAIgEAhIgBAjIAAAVIACAVQABAGgFADQgFACgDAAg");
	this.shape_12.setTransform(16.175,-28.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#F50D05").s().p("AAgBIQgEgEgCgGIgFgNIgCgPQgNARgLAJQgNAJgLAAQgHAAgFgEQgEgEgEgFQgDgGgBgGIgBgNQAAgMACgJIAEgRIAIgSQAFgMAIgLQAIgKAIgJQAKgHAIgBQAIAAAFAGQAEAFAAAFQAAAHgEACIgGAEIgEAAIgEgBQgEACgFAEQgNAOgGAQQgHAQAAASQAAAHADAEQACAEABAAIAGgCIAKgIQAGgFAFgLQAIgKAEgOIAEgMIABgLQACgMACgGQADgGAKAAQAEAAADACQADADAAAHIAAAMIgDALIgDAQIgBANQAAARADANQADAMAFAIIACAFIABAFQAAAFgFADQgFADgFgBQgEAAgEgDg");
	this.shape_13.setTransform(4.15,-24.55);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#F50D05").s().p("AgkBNQgCgDgCgEQgCgFABgJIAAgMIAAgNQAAgUgDgUQgDgUgIgQIAAAAQgCgCACgEQABgEADgDQADgDAFgBQAFgBAGAEQAEADADAIIAEAVIABACIAAACQAKgRAOgOQAOgPATgJQAGgCAFACQAFADADAFIABAHIgCAHQgBADgFACIgCABIgDAAIgCAAQgNAHgLAKQgKAKgGANQgGAMgDAOQgDAPAAAPIAAAMIgBAIIgCAHIgEAGQgDABgEAAQgGAAgGgDg");
	this.shape_14.setTransform(-6.4875,-25.3625);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#F50D05").s().p("AAACAIgEgCIgDgCIgCgGQAAgFADgEQADgDADgCQAJgKAGgNQAFgOAEgPQAEgPABgQIACggIAAgGIAAgEIAAgEIgBgGIgGAIIgEAGIgEADIgCACIgKAJIgMAIIgPAGQgHADgHAAQgMAAgFgIQgFgGAAgQQAAgKACgNIAHgYIAKgYQAFgLAHgJQAHgJAHgFQAHgGAHAAIAJABIAJABIAIAEIAJAJQACADAAAEQAAAFgEAEQgEAEgGAAIgFgBIgEgEIgCgCIgDgBIgGACIgFAFQgOAMgHAUQgHATgBAYIAAAAQAIgBAKgHQAKgGAIgJQAJgJAHgKQAGgKAAgIIAAgBIAAgCIgBgBIAAgDQAAgEAFgDQAFgEAGAAQAHAAADAHQADAGgBAJIAEAhIACAfIgCAbIgFAfIgIAeQgFAOgGALQgHALgHAHQgIAHgJAAg");
	this.shape_15.setTransform(-20.975,-19.675);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#F50D05").s().p("AgxBCQgFgFAAgGIABgQIAEgxQABgZAFgXQABgGAEgCQAEgDAEAAQAGAAAEAEQAFAEgCAIIgBAGIgBACIAAACIgBAEQAGgIAHgHQAHgIAJAAQAIAAAGAGQAFAGACAIIAFAQIADAOIAGAfQAEAPAGAPQACADgBAEIgDAGIgFAEIgGABIgHgCQgDgBgCgFIgXhbQgEAEgDAHIgHAPIgGARIgGASIgEARIgDAMQgBAGgEADQgEADgEAAQgFAAgEgEg");
	this.shape_16.setTransform(-43.0083,-24.775);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#F50D05").s().p("AgbBEQgJgEgHgHQgGgJgEgLQgDgMABgQQABgNAGgPQAHgPAJgMQAKgLAMgIQAMgGAOgBQAIAAAFAEQAFADADAFQAEAFABAHIABAMQgBAOgHALQgIALgKAHQgKAJgLAEQgMAFgLACQADALAFAEQAGAFAGAAIAMgCIAMgEIALgHIAHgIQACgEAFABQAEAAAEACQAEADACAEQABAEgCAEQgFAHgHAHQgIAGgJAEQgIAEgJACQgJACgIAAQgKAAgJgEgAABgpQgFAEgGAHQgGAHgFAJQgEAIgCAIIAOgEQAIgCAGgGQAHgEAFgHQAFgHAAgJQABgFgBgCQgBAAAAgBQAAAAgBAAQAAAAgBAAQAAgBAAAAQgHAAgHAFg");
	this.shape_17.setTransform(-55.9554,-24.85);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#F50D05").s().p("AAgBqQgDgEgDgGIgEgNIgDgPQgNARgLAJQgNAJgLAAQgHAAgEgEQgFgEgEgGQgCgFgCgHIgBgMQAAgMACgKIAEgSIAIgSQAFgKAIgLQAIgLAIgIQAKgIAIAAQAIAAAFAGQAEAFAAAFQAAAHgEACIgGAEIgEAAIgEgBQgEACgFAEQgMANgHAQQgGAQgBATQAAAHACAEQADAEACAAIAEgCIALgIQAGgGAFgKQAIgKAEgPIAEgNIABgJQABgNADgFQADgGAKAAQAEAAADACQADADAAAHIAAAMIgDAJIgDAQIgBAPQAAARADAMQADANAFAIIACAFIABAEQAAAGgFADQgFACgFAAQgEAAgEgDgAAHg1IgIgGQgDgEgCgFQgDgFAAgGQAAgIADgFQADgGAEgDQAFgEAGgBIAKgCQANAAAHAIQAHAJAAALQAAAJgEAIQgFAHgIADQgGACgGAAQgHAAgGgCgAARhZIgDACQgGAEAAAFQABAEADADQACADADABIADAAQAEAAAEgDQADgDAAgFQAAgEgCgDQgCgEgFAAIgBAAg");
	this.shape_18.setTransform(-77.85,-27.925);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#F50D05").s().p("AgLB6QgFgDgBgGIgFgsQgCgWAAgWIAAgEIAAgDIgEABIgCABIgCACIgHACQgCABgFgBIgFgEIgDgGQgBgDABgEQACgDAEgDIAAAAQANgGAMgDIACgXIADgZIAGgZQAEgMAFgKQAEgJAGgGQAHgGAJAAQAKAAAGAGQAHAGAEAJQAEAIABAKQABAKgBAHQgCALgKAAQgGAAgFgDQgEgEABgIIAAgGIgBgIIgCgIQAAgBAAgBQgBAAAAgBQgBAAAAgBQgBAAAAAAQgCAAgDAFIgEAKIgDALIgCAJQgEAMgBAMIgCAZIAJgCIAHgBIAHAAIAHAAIAIAAQAEABACADQAEAGgDAHQgDAGgJABIgBAAIgBAAIgQACIgPACIABAtIAEAuIADAEIABAGQAAAEgDAEQgDAEgGABIgCAAQgEAAgEgDg");
	this.shape_19.setTransform(-89.175,-27.9719);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#F50D05").s().p("AAACAIgEgCIgDgCIgCgGQAAgFADgEQADgDADgCQAJgKAGgNQAFgOAEgPQAEgPABgQIACggIAAgGIAAgEIAAgEIgBgGIgGAIIgEAGIgEADIgCACIgKAJIgMAIIgPAGQgHADgHAAQgMAAgFgIQgFgGAAgQQAAgKACgNIAHgYIAKgYQAFgLAHgJQAHgJAHgFQAHgGAHAAIAJABIAJABIAIAEIAJAJQACADAAAEQAAAFgEAEQgEAEgGAAIgFgBIgEgEIgCgCIgDgBIgGACIgFAFQgOAMgHAUQgHATgBAYIAAAAQAIgBAKgHQAKgGAIgJQAJgJAHgKQAGgKAAgIIAAgBIAAgCIgBgBIAAgDQAAgEAFgDQAFgEAGAAQAHAAADAHQADAGgBAJIAEAhIACAfIgCAbIgFAfIgIAeQgFAOgGALQgHALgHAHQgIAHgJAAg");
	this.shape_20.setTransform(-111.275,-19.675);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#F50D05").s().p("AgfA9QgIgGgGgJQgFgJgDgLQgDgLAAgKQAAgMADgLQADgKAGgJQAGgIAHgEQAIgEAJgBIAEAAIARgJQAJgCAHAAQAJAAAGADQAGAEAEAGQAFAGABAHQADAHAAAIQAAANgGAQQgFAPgKAOQgJANgNAKQgMAKgNAAQgLgBgJgFgAAIglIgIADIgHAFIgGADIgBAAIgCAFQgBAEgDABIgHACIgCAMIgBAJQAAAOAFAKQAFAJAIAAQAIAAAGgGQAIgGAHgJQAFgJAEgKQAEgLgBgJQABgIgDgFQgDgGgHAAg");
	this.shape_21.setTransform(-124.7,-24.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-132.9,-44,265.8,70);


(lib.Tween6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag1BJQgSgZAAgvQAAgtATgbQATgdAiAAQAkAAASAcQARAaAAAuQAAAvgRAaQgTAcgkAAQgjAAgSgcgAgZAAQAAAiAHAPQAGANAMAAQAOAAAGgNQAGgOAAgjQAAg+gZAAQgaAAAAA+g");
	this.shape.setTransform(90.625,13.325);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag1BJQgSgZAAgvQAAgtATgbQATgdAiAAQAkAAASAcQARAaAAAuQAAAvgRAaQgTAcgkAAQgjAAgSgcgAgZAAQAAAiAHAPQAGANAMAAQAOAAAGgNQAGgOAAgjQAAg+gZAAQgaAAAAA+g");
	this.shape_1.setTransform(74.675,13.325);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgOBDQgIgHAAgJQAAgJAHgHQAHgFAIAAQAJgBAGAGQAIAGAAAKQAAAJgIAHQgGAFgJAAQgIAAgGgFgAgOghQgIgHAAgJQAAgKAHgGQAHgGAIAAQAJAAAGAGQAIAGAAAKQAAAJgIAGQgGAGgJgBQgIAAgGgEg");
	this.shape_2.setTransform(63.525,16.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgyBXQgVgQAAgdQAAgMAGgMQAJgQASgIQgLgGgHgLQgHgMAAgMQAAgZATgOQASgOAbAAQAbAAARANQASAOAAAaQAAAMgIAMQgHAKgLAGQAPAHAKAKQAKAOAAAPQAAAcgWASQgUAQgeAAQgeAAgUgOgAgcAoQAAALAIAIQAJAIALAAQANgBAIgGQAHgIAAgMQAAgLgKgIQgJgIgLgEQgaAPAAAQgAgOg8QgGAFAAAIQAAAHAHAJQAGAHAIAEQATgNAAgNQAAgIgGgFQgGgHgIABQgIAAgGAFg");
	this.shape_3.setTransform(52.225,13.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgiBGQgIAAAAgIIAAh3QAAgIAIAAIAXAAQAIAAAAAGIABAIQAHgKAHgEQAIgEAMAAIAHABQAEABAAAGIgFAaQgBAFgDAAIgJgBQgPAAgKALIAABSQAAAIgIAAg");
	this.shape_4.setTransform(32.9778,16.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag6BHIgHgGQgDgDgBgCQAAgCAEgEIAIgJQgNgSAAgbQAAgfATgUQAUgUAgAAQAVAAAQAIIAHgIQAFgFAFAFIAIAHQAEADAAACQAAACgDADIgHAIQANASABAcQAAAggTATQgUAVggAAQgXAAgQgKIgHAJQgEADgCAAQgCAAgEgDgAgPAjQAGAFAJAAQAOAAAIgMQAHgLgBgRIgBgNgAgUgbQgIAKAAARIABAKIApguQgGgDgIAAQgNAAgHAMg");
	this.shape_5.setTransform(19.05,16.206);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgZBnQgIAAAAgJIAAhiIgOAAQgFAAgBgCQgCgCAAgFIAAgMQAAgIAHAAIAPAAIAAgJQAAg8AzAAQATAAAOAHQAFACAAAEIgBAHIgCAOQgCAHgGgCQgLgEgJAAQgRAAAAAWIAAAMIAcAAQAHAAAAAGIAAAQQAAAHgHAAIgcAAIAABiQAAAJgIAAg");
	this.shape_6.setTransform(6.525,12.775);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgxA+QgDgBAAgEIAAgEIAGgSQABgEADAAIAFABQAUAIAQABQAOgBAAgJQAAgHgNgFIgYgJQgMgFgHgJQgKgKABgPQAAgVARgLQAPgKAUAAQAZAAATAKQAEABAAADIgBADIgGAUQAAADgEAAIgDAAQgSgHgNAAQgGAAgEADQgDACAAADQAAAHAKAEIAcAMQAZAIABAbQgBAWgRAMQgPAKgXAAQgWAAgZgKg");
	this.shape_7.setTransform(-12.3,16.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAZBkQgJAAgEgGIgeg4IgBAAIAAA2QAAAJgHgBIgbAAQgIAAAAgHIAAi1QAAgHAHgBIAdgDQAGAAAAAHIAABuIABAAIAegxQADgEAGAAIAeAAQAFAAAAADIgBAFIglAxIAqBEIACAHQAAADgGAAg");
	this.shape_8.setTransform(-24.875,13);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgnA2QgSgSAAghQAAgiATgTQAUgVAgAAQAVAAASAHQAEACgCAHIgEAUQAAAEgEAAIgDgBQgOgFgLgBQgQAAgIALQgJAKAAARQAAATAJALQAHAKAPAAQANAAAPgHIADgBQADABABADIAGAWQAAADgFADQgSAIgZAAQgfAAgSgSg");
	this.shape_9.setTransform(-39.1,16.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ag/AUIAAhSQAAgHAIAAIAZAAQAIAAAAAHIAABLQAAATAQAAQAPAAANgLIAAhTQAAgHAJAAIAZAAQAIAAAAAHIAAB3QAAAJgJAAIgWAAQgIAAAAgFIAAgGQgUAPgYAAQgsAAAAgyg");
	this.shape_10.setTransform(-53.625,16.425);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgMBiQgKgEgGgGIgCAIQgBADgFAAIgWAAQgIAAAAgJIAAizQAAgHAHgBIAdgEQAGAAAAAGIAABCQAPgMASAAQAVAAAPAOQAWAUAAAmQAAAfgPATQgRAVgeAAQgHAAgKgEgAgYADIAAA3QAMAKALAAQAYAAAAglQAAgkgXAAQgMAAgMAIg");
	this.shape_11.setTransform(-69.225,13.175);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgiBGQgIAAAAgIIAAh3QAAgIAIAAIAXAAQAIAAAAAGIABAIQAHgKAHgEQAIgEAMAAIAHABQAEABAAAGIgFAaQgBAFgDAAIgJgBQgPAAgKALIAABSQAAAIgIAAg");
	this.shape_12.setTransform(-81.9722,16.025);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ag6AzQgPgSAAgeQAAgiATgVQASgTAZAAQAWAAALAQIABgGQAAgGAHAAIAZAAQAGAAAAAHIAABfQAAAFAFAAIACAAQAGAAAAAGIAAAQQAAAGgHAAIgPAAQgVABgGgNIgBAAQgFAGgMAFQgLAFgJAAQgdAAgQgVgAgVgbQgIAKAAARQAAAnAZAAQAHgBAHgEQAGgDAEgFIAAg1QgLgJgMAAQgLAAgHAJg");
	this.shape_13.setTransform(-95.85,16.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgXBNQgGgHgCgLQgBgHAAgUIAAg0IgLAAQgFAAgCgCQgBgCAAgGIAAgLQAAgIAGAAIANAAIAAgdQAAgGAJgBIAagEQAGAAAAAHIAAAhIAeAAQAHAAAAAGIAAAQQAAAHgHAAIgeAAIAAA1QAAANACAEQADAHAJAAQAHAAALgEIAEgBQADAAABAFIADASIAAACQAAAEgEACQgQAHgUAAQgYAAgLgNg");
	this.shape_14.setTransform(-109.625,14.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ag9BbQgFgCAAgEIABgFIAIgWQABgGAEAAIAFACQAWAIAWAAQAIAAAIgFQAKgFAAgKQAAgMgSgIIgkgRQgjgPAAgiQAAgaAWgQQAUgOAaAAQAcAAAbALQAGADAAADIgBAFIgJAVQgBAFgFAAIgEgBQgVgJgRAAQgYAAAAASQAAAJATAIIAfAPQAlAPAAAiQAAAegWARQgTARgdAAQgeAAgdgKg");
	this.shape_15.setTransform(-123.15,13.325);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgLBhQgJAAAAgHIAAh5QAAgHAJAAIAYAAQAIAAAAAHIAAB5QAAAHgIAAgAgPg7QgGgHgBgJQABgKAGgGQAHgGAIABQAJgBAHAGQAGAGAAAJQABAKgIAHQgGAFgJAAQgHAAgIgFg");
	this.shape_16.setTransform(41.8,-20.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgiBGQgIAAAAgIIAAh3QAAgIAIAAIAXAAQAIAAAAAGIABAIQAHgKAHgEQAIgEAMAAIAHABQAEABAAAGIgFAaQgBAFgDAAIgJgBQgPAAgKALIAABSQAAAIgIAAg");
	this.shape_17.setTransform(33.4778,-17.875);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgZBnQgIAAAAgJIAAhiIgOAAQgFAAgBgCQgCgCAAgFIAAgMQAAgIAHAAIAPAAIAAgJQAAg8AzAAQATAAAOAHQAFACAAAEIgBAHIgCAOQgCAHgGgCQgLgEgJAAQgRAAAAAWIAAAMIAcAAQAHAAAAAGIAAAQQAAAHgHAAIgcAAIAABiQAAAJgIAAg");
	this.shape_18.setTransform(23.075,-21.125);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgrBcQgIgCADgJIAFgPQACgIAIADQAQAGAOAAQARABAHgKQAEgGAAgPIAAgKQgPAMgRAAQgaAAgQgPQgRgSgBgfQABgfAQgVQARgWAdgBQAJABAJAEQAJADAFAHIABgGQAAgFAHAAIAXAAQAJgBgBAJIAAB0QABBJhFAAQgVAAgVgJgAgNg7QgKAKAAAVQAAATAJAJQAHAFAKAAQANABAJgKIAAg1QgJgJgNAAQgJAAgHAHg");
	this.shape_19.setTransform(8.65,-14.75);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgNBkQgHAAAAgHIAAi1QAAgHAHgBIAcgDQAGAAAAAHIAAC4QAAAIgIAAg");
	this.shape_20.setTransform(-2.7,-20.875);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("Ag6A0QgPgTAAgeQAAgiATgVQASgTAZAAQAWAAALAQIABgGQAAgGAHAAIAZAAQAGAAAAAHIAABgQAAAEAFAAIACAAQAGAAAAAGIAAAQQAAAHgHgBIgPAAQgVAAgGgNIgBAAQgFAHgMAFQgLAFgJAAQgdAAgQgUgAgVgbQgIAKAAARQAAAmAZAAQAHAAAHgEQAGgDAEgEIAAg1QgLgKgMAAQgLAAgHAJg");
	this.shape_21.setTransform(-14.4,-17.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgHBEQgIAAgCgFIgzh7IAAgDQAAgEAGAAIAgAAQAHAAACAHIASA5IAEATIABAAIAFgTIATg5QADgHAHAAIAaAAQAHAAAAAFIgBADIgzB5QgCAGgHAAg");
	this.shape_22.setTransform(-29.675,-17.675);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAeBGQgIAAAAgIIAAhKQAAgTgQAAQgPAAgMALIAABSQAAAIgIAAIgbAAQgHAAAAgHIAAh4QAAgIAIAAIAXAAQAHAAABAGIAAAGQAUgQAYAAQAsAAAAAyIAABRQAAAIgIAAg");
	this.shape_23.setTransform(-51.725,-17.875);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AguA1QgTgTAAgiQAAggAUgUQAUgTAfAAQAbAAARASQAQASAAAjIAAADQAAAJgKgBIhNAAQACANALAHQAJAIANAAQARAAASgIIAEAAQADAAABAEQAGARAAAEQAAAEgGADQgVAJgeAAQggAAgUgTgAAZgOQAAgKgFgHQgGgIgKAAQgJABgHAGQgHAIgCAKIAuAAIAAAAg");
	this.shape_24.setTransform(-67.125,-17.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgMBiQgKgEgGgGIgCAIQgBADgFAAIgWAAQgIAAAAgJIAAizQAAgHAHgBIAdgEQAGAAAAAGIAABCQAPgMASAAQAVAAAPAOQAWAUAAAmQAAAfgPATQgRAVgeAAQgHAAgKgEgAgYADIAAA3QAMAKALAAQAYAAAAglQAAgkgXAAQgMAAgMAIg");
	this.shape_25.setTransform(-88.975,-20.725);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("Ag6BHIgHgGQgDgDAAgCQgBgCAEgEIAHgJQgLgSAAgbQgBgfAUgUQATgUAgAAQAWAAAPAIIAIgIQADgFAHAFIAHAHQAEADAAACQAAACgDADIgHAIQANASAAAcQAAAggSATQgUAVggAAQgXAAgQgKIgIAJQgCADgCAAQgDAAgEgDgAgPAjQAHAFAIAAQAOAAAIgMQAHgLAAgRIgBgNgAgVgbQgGAKgBARIABAKIApguQgGgDgHAAQgOAAgIAMg");
	this.shape_26.setTransform(-105.3,-17.694);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAlBhQgKAAgGgIIg0hIIAAAAIAABIQAAAIgJAAIgbAAQgJAAAAgIIAAiyQAAgHAJAAIAbAAQAJAAAAAHIAABOIAAAAIAyhPQADgGAJAAIAbAAQAGAAAAAEIgCAEIg6BWIBHBZQACADAAACQAAAFgFAAg");
	this.shape_27.setTransform(-121.5,-20.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-133.1,-38.6,274.29999999999995,69.8);


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.snow();
	this.instance.parent = this;
	this.instance.setTransform(-196.8,-610,0.6559,0.6559,0,-90,90);

	this.instance_1 = new lib.snow();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-196.8,610.05,0.6559,0.6559,-90);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-196.8,-610,393.6,1220.1);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.snow();
	this.instance.parent = this;
	this.instance.setTransform(-196.8,-610.05,0.6559,0.6559,0,-90,90);

	this.instance_1 = new lib.snow();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-196.8,610,0.6559,0.6559,-90);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-196.8,-610,393.6,1220);


(lib.Arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F3161C").s().p("ACgA4QgFgBgDgFQgCgEABgFIANgsQhZArhqAAQg4AAg3gMQgcgGgVgHQgFgCgCgEQgCgFACgEQACgFAEgCQAFgCAFACQAsAOA/AGQB8ALBjgvIgqgJQgFAAgCgFQgDgEABgFQABgFAEgDQAEgDAFABIBZASIgZBVQgCAKgKAAg");
	this.shape.setTransform(-52.3857,-8.9724,0.4413,0.4413,29.9985);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60.1,-13.5,16.200000000000003,10.4);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_copy_copy_copy_copy
	this.instance = new lib.Tween3("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(57.75,-924.25,1,1,0,0,180);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(240).to({_off:false},0).to({x:49.1,y:-314.25},240).wait(1));

	// Layer_1_copy_copy_copy
	this.instance_1 = new lib.Tween3("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(50.25,-316,1,1,0,0,180);

	this.instance_2 = new lib.Tween4("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-49.15,899,1,1,0,0,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},480).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true,x:-49.15,y:899},480).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-245.9,-1534.3,500.5,3043.3999999999996);


// stage content:
(lib._300x250HTML5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_78 = function() {
		var _this = this;
		/*
		Stop a Movie Clip/Video
		Stops the specified movie clip or video.
		*/
		_this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(78).call(this.frame_78).wait(1));

	// Layer_2
	this.instance = new lib.starbucks_un_the_go();
	this.instance.parent = this;
	this.instance.setTransform(2,221,0.4874,0.4876);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(79));

	// Snow
	this.instance_1 = new lib.Symbol1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(146.8,305);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(79));

	// FlashAICB
	this.instance_2 = new lib.Arrow("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(186.55,216.4,1.8802,1.9453,0,-104.9999,75.0002);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(51).to({_off:false},0).to({scaleX:2.88,scaleY:2.88,skewX:-105,skewY:74.9999,x:220.45,y:283.15,alpha:1},9).wait(18).to({startPosition:0},0).wait(1));

	// KØB
	this.instance_3 = new lib.Tween6("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(137.15,-9.4);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(17).to({_off:false},0).to({y:40.6,alpha:1},8).wait(54));

	// Layer_5
	this.instance_4 = new lib.Tween8("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(136.9,75.8);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(33).to({_off:false},0).to({y:115.8,alpha:1},7).wait(38).to({startPosition:0},0).wait(1));

	// BG
	this.instance_5 = new lib.bg300x250();
	this.instance_5.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(79));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(150,-496,243.89999999999998,1095);
// library properties:
lib.properties = {
	id: '518BD99F26E84AE1902D4F543675FC66',
	width: 300,
	height: 250,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/snow.png", id:"snow"},
		{src:"images/300x250_atlas_P_.png", id:"300x250_atlas_P_"},
		{src:"images/300x250_atlas_NP_.jpg", id:"300x250_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['518BD99F26E84AE1902D4F543675FC66'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;