(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"728x90_atlas_P_", frames: [[0,0,80,53]]},
		{name:"728x90_atlas_NP_", frames: [[0,0,728,90]]}
];


// symbols:



(lib.bg728x90 = function() {
	this.initialize(ss["728x90_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.snowpngcopy = function() {
	this.initialize(img.snowpngcopy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,613,396);


(lib.starbucks_un_the_go = function() {
	this.initialize(ss["728x90_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Tween10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.snowpngcopy();
	this.instance.parent = this;
	this.instance.setTransform(0,-198);

	this.instance_1 = new lib.snowpngcopy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-613,-198);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-613,-198,1226,396);


(lib.Tween9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.snowpngcopy();
	this.instance.parent = this;
	this.instance.setTransform(0,-198);

	this.instance_1 = new lib.snowpngcopy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-613,-198);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-613,-198,1226,396);


(lib.Tween8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F50D05").s().p("AgSB/QgFgHgDgKIgDgWIAAgTIABgfIAFgeQgGAAgEgDQgFgDAAgGIABgFIAMgWIAMgYIACgIIABgHIADgTIAFgUQADgKAFgIQAGgHAJAAQAGAAAGAEQAFADABAJIAAACQAAAOgHATQgHATgKASIgDAQIgCAQIgGAdIgDAcIgBAdIABAXQABAMAEAMIABADIAAABQAAAGgEADQgDADgFAAQgIAAgFgIg");
	this.shape.setTransform(186.925,-72.575);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F50D05").s().p("AAACMIgEgCIgEgDIgCgGQAAgGAEgEQADgEADgBQAJgLAHgPQAGgOAEgRQAFgRABgRIACgjIAAgHIAAgEIAAgEIgBgHIgHAJIgEAGIgEAEIgDACIgLAKIgNAIIgQAHQgIADgHAAQgNAAgGgIQgFgHgBgRQABgMACgNIAHgbIALgaQAGgNAIgJQAHgKAIgGQAIgGAHAAIAKABIAKABIAJAEIAJAKQADAEAAAEQAAAGgFAEQgEAFgHAAIgFgCIgFgEIgCgDIgDgBIgGADIgGAFQgQANgIAWQgHAVgBAaIABAAQAHgBAMgIQALgHAJgJQAJgKAIgLQAGgLABgIIAAgCIAAgBIgBgCIAAgDQAAgEAFgEQAGgEAGAAQAIAAADAHQADAHgBAKIAFAkIACAhIgDAeIgFAiIgJAhQgGAPgGANQgHAMgIAHQgIAIgKAAg");
	this.shape_1.setTransform(173.15,-62.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F50D05").s().p("AgeBLQgKgFgHgIQgHgIgEgNQgDgNABgSQABgPAHgQQAHgQAKgNQALgMANgJQANgHAPgBQAJAAAGAEQAGADADAHQADAFACAHIABAOQgBAPgIANQgIALgLAIQgMAJgMAFQgNAGgMABQADAMAGAFQAGAGAIAAIANgCIANgFIAMgIQAFgDACgGQADgEAFABQAFAAAEADQAEACACAFQACAFgDADQgFAKgIAGQgJAHgJAEQgKAFgJACQgKACgIAAQgMAAgKgEgAACguQgHAFgGAIQgHAIgFAJQgEAJgDAIIAQgDQAJgDAGgFQAIgGAFgHQAFgIABgJQABgGgBgCQgBgBAAAAQgBAAAAgBQAAAAgBAAQAAAAgBAAQgHAAgHAEg");
	this.shape_2.setTransform(158.7333,-68.25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F50D05").s().p("Ag2BIQgFgFAAgHIABgSIAEg1QACgcAEgZQACgGAEgDQAEgCAFAAQAGgBAFAFQAFAEgCAJIgBAGIgBADIAAACIgBADQAGgIAIgHQAIgIAJAAQAKAAAFAFQAGAHADAIIAEASIAEAQIAHAiQAEARAHAPQABAEAAAEIgDAHIgGAEIgGABIgIgCQgDgBgCgGIgahjQgEAEgDAIIgIAQIgHAUIgGATIgFASIgDANQgBAGgEAEQgFADgEABQgGgBgEgEg");
	this.shape_3.setTransform(144.3063,-68.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F50D05").s().p("AgoBWIgDgFIgCgFIgBgFQAAgEACgFQACgFAEAAQAEgCADACIAGABIAFgBIAIgCIAKgEIANgHIAMgJQAFgFAAgEQAAgEgEgCIgKgEIgKgCIgDgBIgRgFQgKgDgJgFQgIgEgHgHQgGgHAAgLQAAgPAJgLQAJgKANgIQANgGANgEQAOgDAJAAQAGAAAGADQAGACAAAHQAAASgOAAIgFgBIgEgBQgIAAgJACIgOAGQgHAEgEAFQgEAEAAAEQAAAEADACIAIAGIAKAEIAKADIAUAGIARAHQAHAEAEAGQAFAGAAAIQAAAOgJALQgJAKgNAIQgNAIgOAEIgaAIIgEABIgDAAQgEAAgCgBg");
	this.shape_4.setTransform(130.025,-67.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#F50D05").s().p("AgSB/QgFgHgDgKIgDgWIAAgTIABgfIAFgeQgGAAgEgDQgFgDAAgGIABgFIAMgWIAMgYIACgIIABgHIADgTIAFgUQADgKAFgIQAGgHAJAAQAGAAAGAEQAFADABAJIAAACQAAAOgHATQgHATgKASIgDAQIgCAQIgGAdIgDAcIgBAdIABAXQABAMAEAMIABADIAAABQAAAGgEADQgDADgFAAQgIAAgFgIg");
	this.shape_5.setTransform(121.275,-72.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F50D05").s().p("AgeBLQgKgFgHgIQgHgIgEgNQgDgNABgSQABgPAHgQQAHgQAKgNQALgMANgJQANgHAPgBQAJAAAGAEQAGADADAHQADAFACAHIABAOQgBAPgIANQgIALgLAIQgMAJgMAFQgNAGgMABQADAMAGAFQAGAGAIAAIANgCIANgFIAMgIQAFgDACgGQADgEAFABQAFAAAEADQAEACACAFQACAFgDADQgFAKgIAGQgJAHgJAEQgKAFgJACQgKACgIAAQgMAAgKgEgAACguQgHAFgGAIQgHAIgFAJQgEAJgDAIIAQgDQAJgDAGgFQAIgGAFgHQAFgIABgJQABgGgBgCQgBgBAAAAQgBAAAAgBQAAAAgBAAQAAAAgBAAQgHAAgHAEg");
	this.shape_6.setTransform(109.2833,-68.25);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#F50D05").s().p("Ag2BIQgFgFAAgHIABgSIAEg1QACgcAEgZQACgGAEgDQAEgCAFAAQAGgBAFAFQAFAEgCAJIgBAGIgBADIAAACIgBADQAGgIAIgHQAIgIAJAAQAKAAAFAFQAGAHADAIIAEASIAEAQIAHAiQAEARAHAPQABAEAAAEIgDAHIgGAEIgGABIgIgCQgDgBgCgGIgahjQgEAEgDAIIgIAQIgHAUIgGATIgFASIgDANQgBAGgEAEQgFADgEABQgGgBgEgEg");
	this.shape_7.setTransform(94.8563,-68.15);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F50D05").s().p("AAkBPQgFgFgCgGIgFgPIgEgQQgNATgMAJQgOAKgMAAQgIABgFgFQgGgEgDgGQgDgHgCgHIgBgNQAAgOABgKIAGgTIAJgTQAGgNAHgMQAJgLAKgJQAKgIAKAAQAHgBAFAHQAFAFABAGQAAAGgFAEIgHADIgEAAIgEAAQgEACgGAEQgOAPgHASQgHARAAAVQAAAGACAFQADAFACAAIAFgDIAMgJQAGgGAGgKQAHgMAHgPIADgOIABgLQACgOADgHQADgFAKAAQAFgBADADQAEADAAAHIgBANIgDAMIgDASIgBAPQAAASADANQADAPAGAIIACAFIABAFQAAAHgFADQgFACgFAAQgGAAgDgDg");
	this.shape_8.setTransform(80.3,-67.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#F50D05").s().p("AhBBgQgEgMAAgUIACgdIADggIAHglIAIgjIAIgZQAEgKADgCQAFgCAFABQAFABAEAEQADADABAFQABAEgBAFIgFAOIgDAJIgDAHIgCAJIgDAMIgEATIAHgDIAEgCIAWgIIASgGIARgDQAEAAADACQAEACACAEQABAEgBAEQgBAFgGADIgGADIgIACQgOACgMAFIgbAJIAPAGIALAGIARALIAPAKIANALIAQAMQAGAEAAAGQABAFgEAFQgEAFgFAAQgFABgGgDIgMgKIgKgIIgFgFIgMgIIgNgJIgQgJIgOgIIgBAOIgBANQAAAKADALQACALgBAKIgFAGQgDADgJAAQgKAAgEgMg");
	this.shape_9.setTransform(66.0028,-70.3917);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#F50D05").s().p("AgoBWIgDgFIgCgFIgBgFQAAgEACgFQACgFAEAAQAEgCADACIAGABIAFgBIAIgCIAKgEIANgHIAMgJQAFgFAAgEQAAgEgEgCIgKgEIgKgCIgDgBIgRgFQgKgDgJgFQgIgEgHgHQgGgHAAgLQAAgPAJgLQAJgKANgIQANgGANgEQAOgDAJAAQAGAAAGADQAGACAAAHQAAASgOAAIgFgBIgEgBQgIAAgJACIgOAGQgHAEgEAFQgEAEAAAEQAAAEADACIAIAGIAKAEIAKADIAUAGIARAHQAHAEAEAGQAFAGAAAIQAAAOgJALQgJAKgNAIQgNAIgOAEIgaAIIgEABIgDAAQgEAAgCgBg");
	this.shape_10.setTransform(41.725,-67.25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#F50D05").s().p("AgJBrQgDgBgDgDQgDgEgCgGQgCgHAAgMIABgNIABgYIABgVIABgOIAAgPIADgNQABgHADgEQADgDAGgBQAGABAGAEQAGAFgBAIIAAACIgBAGIgBAQIgCAWIgDAYIgBARIABAIIACAHIACAGIABAHQABAIgHADQgGAEgEAAgAgEhMQgGgEAAgMQAAgIAEgDQAEgDAIAAQAGAAAFAEQAGADAAAMQAAAKgGADQgFAEgEAAQgHAAgFgGg");
	this.shape_11.setTransform(31.05,-71.35);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F50D05").s().p("AgKBzQgFgBgBgHIgCgYIgBgaQAAgfAEggIggAGQgJAAgEgDQgFgDABgGQAAgDACgEQAEgDAFgBIAJgCIAJgDIAAAAIABAAIALgDIANgEIAJgkIALgjQACgFAFgCQADgDAEAAQAGAAAFAEQAFAFgCAHQgLAbgHAcIAQgEIAPAAIAHABIAFAFQACADAAADQAAAEgDADIgBABIgBABQgFAEgFAAIgTAEIgQAFIAAAAIgFAkIgBAlIAAAYIACAXQABAGgFADQgGADgDAAg");
	this.shape_12.setTransform(21.1,-72);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#F50D05").s().p("AAkBPQgFgFgCgGIgFgPIgEgQQgNATgNAJQgNAKgMAAQgIABgFgFQgGgEgDgGQgDgHgCgHIgBgNQAAgOABgKIAGgTIAJgTQAFgNAIgMQAJgLAKgJQAKgIAKAAQAHgBAFAHQAGAFAAAGQAAAGgFAEIgGADIgFAAIgEAAQgEACgGAEQgOAPgHASQgHARAAAVQAAAGACAFQACAFADAAIAFgDIAMgJQAGgGAGgKQAHgMAHgPIADgOIABgLQACgOADgHQADgFAKAAQAFgBADADQAEADAAAHIgBANIgDAMIgDASIgBAPQAAASADANQADAPAGAIIACAFIABAFQAAAHgFADQgFACgFAAQgGAAgDgDg");
	this.shape_13.setTransform(7.95,-67.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#F50D05").s().p("AgnBTQgDgCgCgFQgCgFABgKIAAgOIABgOQAAgVgEgWQgDgXgKgRQgBgCABgEQACgFADgDQAEgEAFgBQAFgBAHAFQAFAEACAIIAFAXIABACIAAADQAMgTAOgQQAPgQAVgJQAHgDAGACQAFADADAGIABAHIgCAIQgBAEgFACIgDABIgDAAIgCAAQgPAHgLALQgLALgHAOQgGANgEAQQgDAQAAARIAAANIgBAJIgCAIIgEAGQgDACgGAAQgGAAgGgFg");
	this.shape_14.setTransform(-3.6875,-68.7818);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#F50D05").s().p("AAACMIgEgCIgEgDIgCgGQAAgGADgEQAEgEADgBQAJgLAHgPQAGgOAEgRQAFgRABgRIACgjIAAgHIAAgEIAAgEIgBgHIgHAJIgEAGIgEAEIgDACIgLAKIgNAIIgQAHQgIADgHAAQgNAAgGgIQgFgHgBgRQABgMACgNIAHgbIALgaQAGgNAIgJQAHgKAHgGQAJgGAHAAIAKABIAKABIAJAEIAJAKQADAEAAAEQAAAGgFAEQgFAFgGAAIgFgCIgFgEIgCgDIgDgBIgGADIgGAFQgPANgJAWQgHAVgBAaIAAAAQAIgBAMgIQALgHAJgJQAJgKAIgLQAGgLABgIIAAgCIAAgBIgBgCIAAgDQAAgEAFgEQAFgEAHAAQAIAAADAHQADAHAAAKIAEAkIACAhIgDAeIgFAiIgJAhQgGAPgGANQgHAMgIAHQgJAIgJAAg");
	this.shape_15.setTransform(-19.55,-62.575);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#F50D05").s().p("Ag2BIQgFgFAAgHIABgSIAEg1QACgcAEgZQACgGAEgDQAEgCAFAAQAGgBAFAFQAFAEgCAJIgBAGIgBADIAAACIgBADQAGgIAIgHQAIgIAJAAQAKAAAFAFQAGAHADAIIAEASIAEAQIAHAiQAEARAHAPQABAEAAAEIgDAHIgGAEIgGABIgIgCQgDgBgCgGIgahjQgEAEgDAIIgIAQIgHAUIgGATIgFASIgDANQgBAGgEAEQgFADgEABQgGgBgEgEg");
	this.shape_16.setTransform(-43.6937,-68.15);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#F50D05").s().p("AgeBLQgKgFgHgIQgHgIgEgNQgDgNABgSQABgPAHgQQAHgQAKgNQALgMANgJQANgHAPgBQAJAAAGAEQAGADADAHQADAFACAHIABAOQgBAPgIANQgIALgLAIQgMAJgMAFQgNAGgMABQADAMAGAFQAGAGAIAAIANgCIANgFIAMgIQAFgDACgGQADgEAFABQAFAAAEADQAEACACAFQACAFgDADQgFAKgIAGQgJAHgJAEQgKAFgJACQgKACgIAAQgMAAgKgEgAACguQgHAFgGAIQgHAIgFAJQgEAJgDAIIAQgDQAJgDAGgFQAIgGAFgHQAFgIABgJQABgGgBgCQgBgBAAAAQgBAAAAgBQAAAAgBAAQAAAAgBAAQgHAAgHAEg");
	this.shape_17.setTransform(-57.8667,-68.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#F50D05").s().p("AAjB0QgEgFgDgGIgEgPIgEgQQgNATgNAJQgOAKgLAAQgIABgGgFQgFgEgDgGQgEgHgBgHIgBgNQAAgOACgKIAFgUIAIgTQAHgMAIgMQAIgLAKgJQAKgIAJAAQAJgBAEAHQAGAFgBAGQAAAGgDAEIgHADIgGAAIgDAAQgFACgEAEQgPAOgHASQgHASAAAVQAAAGACAFQACAFACAAIAGgDIALgJQAHgGAHgKQAHgMAFgQIAEgOIACgKQABgOADgHQADgFALAAQAEgBAEADQADADAAAHIgBANIgCALIgEASIgBAQQAAASADANQADAPAGAIIADAFIAAAFQAAAHgFADQgFACgGAAQgEAAgFgDgAAIg7QgFgCgDgEQgFgFgCgFQgDgFABgHQAAgIADgGQADgGAEgDQAGgFAGgBIAMgCQAOAAAHAJQAIAJAAAMQAAALgEAHQgGAJgJADQgHACgGAAQgIAAgGgDgAAThiIgDACQgHAFAAAFQAAAFADADQADAEAEABIADAAQAEAAAEgEQAEgDABgFQgBgEgCgFQgCgEgFAAIgCAAg");
	this.shape_18.setTransform(-81.85,-71.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#F50D05").s().p("AgMCGQgGgDgBgHIgFgwQgCgYAAgZIAAgEIAAgDIgFABIgCABIgDACIgGADQgDABgFgBIgGgFIgDgHQgBgDABgEQACgEAFgDIgBAAQAOgHAOgDIACgYIAEgcIAGgcQAEgNAFgLQAFgKAHgGQAIgHAJAAQALAAAHAHQAIAGAEAKQAEAJABALQABALgBAIQgCAMgLAAQgGAAgFgEQgGgEABgIIABgHIgBgJIgCgJQgBgEgDAAQgCAAgDAFIgEALIgEANIgCAJQgEANgCANIgCAbIAKgBIAIgBIAHgBIAIAAIAJABQAFABACADQADAGgDAIQgDAGgKABIgBABIgBAAIgRACIgRACIABAyIAFAyIADAEIACAHQAAAEgEAEQgDAFgIABIgCAAQgEAAgEgDg");
	this.shape_19.setTransform(-94.22,-71.6639);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#F50D05").s().p("AAACMIgEgCIgEgDIgCgGQAAgGAEgEQADgEADgBQAJgLAHgPQAGgOAEgRQAFgRABgRIACgjIAAgHIAAgEIAAgEIgBgHIgHAJIgEAGIgEAEIgDACIgLAKIgNAIIgQAHQgIADgHAAQgNAAgGgIQgFgHgBgRQABgMACgNIAHgbIALgaQAGgNAIgJQAHgKAIgGQAIgGAHAAIAKABIAKABIAJAEIAJAKQADAEAAAEQAAAGgFAEQgEAFgHAAIgFgCIgFgEIgCgDIgDgBIgGADIgGAFQgQANgIAWQgHAVgBAaIABAAQAHgBAMgIQALgHAJgJQAJgKAIgLQAGgLABgIIAAgCIAAgBIgBgCIAAgDQAAgEAFgEQAGgEAGAAQAIAAADAHQADAHgBAKIAFAkIACAhIgDAeIgFAiIgJAhQgGAPgGANQgHAMgIAHQgIAIgKAAg");
	this.shape_20.setTransform(-118.45,-62.575);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#F50D05").s().p("AgiBCQgJgGgGgJQgGgKgDgMQgDgMAAgMQAAgNADgLQAEgMAGgJQAGgJAJgFQAIgFAKAAIADAAIAUgJQAJgEAIAAQAJAAAHAEQAHAEAFAHQAFAGACAIQACAIAAAIQAAAPgGARQgGARgKAPQgLAPgOALQgNAKgOAAQgNAAgJgHgAgPgcIgCAFQgCAEgDACIgIACIgCAMIgBAKQAAAQAGAKQAFALAJAAQAJAAAHgHQAIgGAHgKQAGgKAEgLQAEgMAAgKQAAgIgDgGQgDgGgIgBIgJACIgJAEIgIAFIgGAEIgBAAg");
	this.shape_21.setTransform(-133.125,-67.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-141.9,-89,929.6,39);


(lib.Tween6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag4BLQgRgcAAguQAAgtASgdQAUgiAkAAQAlABATAgQARAcAAAuQAAAugRAdQgTAggmABQglAAgTghgAghAAQAABKAhAAQAiAAAAhKQAAhJghAAQgiAAAABJg");
	this.shape.setTransform(276.925,-68.45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag4BLQgRgcAAguQAAgtASgdQAUgiAkAAQAlABATAgQARAcAAAuQAAAugRAdQgTAggmABQglAAgTghgAghAAQAABKAhAAQAiAAAAhKQAAhJghAAQgiAAAABJg");
	this.shape_1.setTransform(260.125,-68.45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgNBHQgHgGAAgIQAAgKAGgGQAGgEAIgBQAJABAGAEQAGAGAAAJQAAAJgHAGQgGAFgIABQgHAAgGgGgAgNgoQgHgGAAgJQAAgKAGgFQAGgFAIAAQAJAAAGAFQAGAGAAAJQAAAJgHAGQgGAFgIAAQgHAAgGgFg");
	this.shape_2.setTransform(248.325,-65.35);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgzBcQgWgQABgeQAAgNAHgNQALgSAVgJQgNgGgJgMQgIgMAAgPQgBgZAUgPQASgPAbAAQAbAAASAOQARAPABAZQAAANgKAOQgIALgOAHQATAIALAMQALAOAAARQABAdgXASQgVASgeAAQgfgBgUgPgAgiAsQAAAPAKAKQAKAIAOABQAPAAAKgJQAJgJABgPQAAgYglgOQggAPAAAWgAgShGQgIAHAAAKQAAAUAbANQAYgOABgSQAAgLgHgHQgIgHgLAAQgKAAgIAHg");
	this.shape_3.setTransform(236.2,-68.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AghBLQgHAAAAgIIAAiBQAAgIAHAAIAUAAQAHAAAAAGIAAAKQAPgUAUAAIAJACQABAAAAAAQABAAAAABQABAAAAABQAAAAAAABIgEAYQAAAFgFgBIgIgBQgRAAgLAPIAABeQAAAIgHAAg");
	this.shape_4.setTransform(216.15,-65.525);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgwBVIgHgEQgEgCADgEIAIgOQgXgUAAgpQAAghATgVQATgWAiAAQATAAANAHIAHgLQAEgHAGADIAEADQAEACgDAFIgIANQAZAUAAApQAAAhgTAVQgUAWghAAQgTAAgOgGIgIANQgCADgCAAIgDgBgAgRAsQAHAEAKAAQASAAAJgPQAIgMAAgVQAAgSgGgMgAgaghQgIANAAAUQAAASAGAMIAthJQgHgEgKAAQgRAAgJAOg");
	this.shape_5.setTransform(201.925,-65.3137);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgZBtQgHAAAAgIIAAhvIgQAAQgEAAgBgCIgBgGIAAgLQAAgGAFAAIARAAIAAgIQAAgNACgMQAIgoAqAAQASAAAOAGQAEACgBAJIgCANQgBAEgDAAIgDgBQgLgDgKAAQgWAAAAAdIAAAOIAiAAQAGAAAAAFIAAAOQAAAGgGAAIgiAAIAABvQAAAIgGAAg");
	this.shape_6.setTransform(188.8341,-68.975);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgyBCQgDgCAAgDIABgCIAEgQQACgEADAAIADABQAXAJAOAAQAWAAAAgQQAAgKgSgIIgXgJQgegKAAgcQgBgVASgMQAOgKAWAAQAWgBAVAKQAEACAAACIgBADIgFAQQgBADgDABIgDgBQgSgIgPAAQgIABgFAEQgEAEAAAGQgBAJAQAFIAaALQAcALAAAbQAAAXgRAMQgQAMgYAAQgXAAgYgLg");
	this.shape_7.setTransform(169.4,-65.35);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAdBrQgIAAgEgGIglg/IgEADIAAA7QAAAHgGAAIgXAAQgHAAAAgHIAAjEQAAgGAGgBIAYgDQAGAAAAAHIAAB3IABAAIAmg1QADgEAGAAIAaAAQABAAABAAQAAAAABAAQAAABABAAQAAABAAABIgBADIgrA1IAxBMQACADAAADQAAADgGAAg");
	this.shape_8.setTransform(156.675,-68.775);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgoA5QgTgVAAgiQAAgjAUgVQAUgWAiABQAVAAATAIQAEACgBAGIgEAPQgBAFgDAAIgDgBQgQgHgNAAQgSAAgLANQgKAMAAAWQAAAWAKANQAKAOASAAQAPgBAQgGQAGgCABAEIAEAOIABAEQAAAEgFACQgTAJgYAAQghgBgTgTg");
	this.shape_9.setTransform(142.175,-65.35);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhAAVIAAhYQAAgGAIgBIAVAAQAIABAAAGIAABRQAAAcAWAAQASAAAQgOIAAhfQAAgGAHgBIAVAAQAIABAAAGIAACCQAAAIgIAAIgTAAQgHAAAAgGIgBgIQgVARgZABQgwgBAAg1g");
	this.shape_10.setTransform(126.975,-65.15);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgRBoQgLgFgGgHIgCAKQgBADgFAAIgSAAQgIAAAAgHIAAjDQAAgHAHAAIAYgEQAGAAgBAGIAABJQASgOAVAAQAXAAAQAOQAWAVAAApQAAAhgQAVQgRAWggAAQgKAAgKgFgAggAAIAABAQAOAPAQAAQAhAAAAguQAAgtggAAQgQAAgPAMg");
	this.shape_11.setTransform(110.8,-68.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AghBLQgHAAAAgIIAAiBQAAgIAHAAIATAAQAIAAAAAGIAAAKQAOgUAVAAIAJACQABAAAAAAQABAAAAABQABAAAAABQAAAAAAABIgEAYQgBAFgEgBIgIgBQgRAAgLAPIAABeQAAAIgHAAg");
	this.shape_12.setTransform(97.7,-65.525);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ag7A2QgQgTABggQAAgkATgWQASgVAbABQAZAAANARIAAgIQABgGAFAAIAVAAQAHAAAAAHIAABnQAAAHACACIAEABIACAAQAGAAAAAFIAAAPQAAAFgHAAIgPAAQgUAAgEgRIAAAAQgGAIgNAGQgMAGgMABQgeAAgQgXgAgbgiQgKANAAAVQAAAVAIAMQAIAOAQAAQAJAAAKgHQAIgFADgJIAAg4QgKgPgSgBQgPAAgJAMg");
	this.shape_13.setTransform(83.5,-65.35);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgVBTQgGgHgCgLIgBgbIAAhBIgPAAQgEAAgBgCQgBgBAAgFIAAgLQAAgGAFAAIAQAAIAAghQAAgGAHgBIAXgDQAFAAAAAHIAAAkIAiAAQAFAAAAAFIAAAOQAAAGgGAAIghAAIAABDQAAAPAEAGQAEAGAKAAQAIAAALgEIADAAQABAAABAAQAAAAABABQAAAAABABQAAAAAAABIADAPQABAGgFACQgRAHgRAAQgYAAgLgNg");
	this.shape_14.setTransform(69.3083,-67.275);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ag9BiQgHgDACgGIAGgUQACgFAEAAIAEABQAZAJAUAAQANAAAJgHQALgGAAgOQAAgQgVgLIgmgUQgkgQAAgiQAAgaAWgQQAUgPAaAAQAeAAAYALQAGADAAADIgBAEIgHASQgCAEgDABIgFgBQgWgKgRAAQgMAAgIAFQgKAHAAALQAAAOAWALIAgAQQAoASAAAkQAAAdgWASQgUARgeAAQgeAAgbgKg");
	this.shape_15.setTransform(55.625,-68.45);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgJBlQgIAAAAgHIAAiCQAAgHAIAAIAUAAQAHAAAAAHIAACCQAAAHgHAAgAgNhDQgGgGAAgIQAAgJAGgFQAGgFAHAAQAIAAAGAFQAGAFAAAJQAAAIgGAFQgGAGgIAAQgHAAgGgFg");
	this.shape_16.setTransform(36.275,-68.175);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AghBLQgHAAAAgIIAAiBQAAgIAIAAIASAAQAIAAAAAGIABAKQANgUAWAAIAIACQABAAAAAAQABAAAAABQABAAAAABQAAAAAAABIgDAYQgBAFgFgBIgIgBQgRAAgLAPIAABeQAAAIgHAAg");
	this.shape_17.setTransform(28,-65.525);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgZBtQgHAAAAgIIAAhvIgQAAQgEAAgBgCIgBgGIAAgLQAAgGAFAAIARAAIAAgIQAAgNACgMQAIgoAqAAQASAAAOAGQAEACgBAJIgCANQgBAEgDAAIgDgBQgLgDgKAAQgWAAAAAdIAAAOIAiAAQAGAAAAAFIAAAOQAAAGgGAAIgiAAIAABvQAAAIgGAAg");
	this.shape_18.setTransform(17.1841,-68.975);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AguBiQgEgDAAgDIAAgEIAFgNQACgFACgBIAFABQASAJAPgBQAUABAJgLQAGgKAAgTIAAgNQgGAHgLAFQgLAEgJAAQgcAAgRgSQgSgSAAgjQAAgfARgXQATgYAeAAQAKAAALAFQAKAFAFAHIABgIQAAgFAHAAIAUAAQAHAAAAAHIAACAQAABMhGgBQgYAAgVgJgAgRhFQgNAMgBAbQABAYALALQAIAHANABQAIgBAKgEQAIgEAEgFIAAg+QgKgOgSAAQgNgBgIAJg");
	this.shape_19.setTransform(2.35,-62.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgKBrQgHAAAAgHIAAjEQAAgGAGgBIAXgDQAGAAAAAGIAADIQAAAHgHAAg");
	this.shape_20.setTransform(-9.3,-68.775);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("Ag8A2QgOgTAAggQgBgkAVgWQARgVAcABQAYAAANARIAAgIQABgGAGAAIAUAAQAHAAAAAHIAABnQAAAHACACIADABIADAAQAGAAgBAFIAAAPQABAFgHAAIgPAAQgUAAgEgRIgBAAQgFAIgNAGQgMAGgMABQgeAAgRgXgAgbgiQgKANAAAVQAAAVAIAMQAIAOAQAAQAJAAAJgHQAJgFAEgJIAAg4QgLgPgSgBQgOAAgKAMg");
	this.shape_21.setTransform(-21.2,-65.35);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgHBJQgHAAgCgGIg0iEIAAgDQAAgEAFAAIAaAAQAHAAACAGIAXBFIAGAaIABAAIAHgZIAXhFQACgHAIAAIAVAAQAGAAAAAEIAAADIg1CEQgCAGgHAAg");
	this.shape_22.setTransform(-36.925,-65.325);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAkBLQgHAAAAgIIAAhRQAAgcgXAAQgRAAgRAOIAABfQAAAIgHAAIgWAAQgHAAAAgHIAAiCQAAgIAHAAIAUAAQAGAAABAGIAAAIQAWgSAaAAQAvAAAAA2IAABXQAAAIgHAAg");
	this.shape_23.setTransform(-59.825,-65.525);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgvA4QgUgVAAgjQAAghAUgVQAVgWAgABQAbAAARASQASASAAAkIAAADQAAAFgCACQgCABgGAAIhXAAQACASAMAKQALAMARAAQASgBATgGQAGgDABAFIAEAQIABADQAAADgFACQgVAKgdAAQgigBgUgUgAgSgmQgIAKgCAOIA8AAIAAgEQAAgMgHgJQgIgJgNAAQgNAAgJAKg");
	this.shape_24.setTransform(-75.875,-65.35);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgRBoQgLgFgGgHIgCAKQgBADgFAAIgSAAQgIAAAAgHIAAjDQAAgHAHAAIAZgEQAEAAAAAGIAABJQARgOAXAAQAWAAAQAOQAWAVAAApQAAAhgQAVQgSAWggAAQgJAAgKgFgAggAAIAABAQAOAPAQAAQAhAAAAguQAAgtgfAAQgRAAgPAMg");
	this.shape_25.setTransform(-98.8,-68.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgwBVIgHgEQgEgCADgEIAIgOQgXgUAAgpQAAghATgVQATgWAiAAQATAAANAHIAHgLQAEgHAGADIAEADQAEACgDAFIgIANQAZAUAAApQAAAhgTAVQgUAWghAAQgTAAgOgGIgIANQgCADgCAAIgDgBgAgRAsQAHAEAKAAQASAAAJgPQAIgMAAgVQAAgSgGgMgAgaghQgIANAAAUQAAASAGAMIAthJQgHgEgKAAQgRAAgJAOg");
	this.shape_26.setTransform(-115.775,-65.3137);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAqBoQgJAAgGgIIhAhTIAAAAIAABTQAAAIgHAAIgYAAQgHAAAAgIIAAjAQAAgHAHAAIAYAAQAHAAAAAHIAABVIAAAAIA9hWQAFgGAGAAIAZAAQAEAAAAAEIgBAEIhEBcIBPBiQACADABACQgBAEgEAAg");
	this.shape_27.setTransform(-132.05,-68.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-143.9,-87.6,929.6,38.199999999999996);


(lib.Arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F3161C").s().p("ACgA4QgFgBgDgFQgCgEABgFIANgsQhZArhqAAQg4AAg3gMQgcgGgVgHQgFgCgCgEQgCgFACgEQACgFAEgCQAFgCAFACQAsAOA/AGQB8ALBjgvIgqgJQgFAAgCgFQgDgEABgFQABgFAEgDQAEgDAFABIBZASIgZBVQgCAKgKAAg");
	this.shape.setTransform(0.0179,0.0107);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19.9,-5.7,39.9,11.4);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_copy
	this.instance = new lib.Tween9("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(306,-180.1);
	this.instance._off = true;

	this.instance_1 = new lib.Tween10("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(306,0.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},119).to({state:[{t:this.instance_1}]},119).wait(2));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(119).to({_off:false},0).to({_off:true,y:0.2},119).wait(2));

	// Layer_1
	this.instance_2 = new lib.Tween9("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(306,0);

	this.instance_3 = new lib.Tween10("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(306,396.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).to({state:[{t:this.instance_3}]},239).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true,y:396.2},239).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-307,-378.1,1226,972.3000000000001);


// stage content:
(lib._728x90_HTML5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_78 = function() {
		var _this = this;
		/*
		Stop a Movie Clip/Video
		Stops the specified movie clip or video.
		*/
		_this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(78).call(this.frame_78).wait(1));

	// Snow
	this.instance = new lib.Symbol2();
	this.instance.parent = this;
	this.instance.setTransform(262.5,-18);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(79));

	// Layer_2
	this.instance_1 = new lib.starbucks_un_the_go();
	this.instance_1.parent = this;
	this.instance_1.setTransform(659,3,0.7374,0.7376);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(79));

	// FlashAICB
	this.instance_2 = new lib.Arrow("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(358.7,61.1,1,1,0,0,0,-17.9,-4.8);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(51).to({_off:false},0).to({regX:-17.8,scaleX:1.5294,scaleY:1.7895,x:378.15,y:55.4,alpha:1},14).wait(14));

	// KØB
	this.instance_3 = new lib.Tween6("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(161.45,62.25);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(17).to({_off:false},0).to({y:94.75,alpha:1},7).wait(55));

	// Layer_5
	this.instance_4 = new lib.Tween8("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(161.45,104.35);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(33).to({_off:false},0).to({y:130.35,alpha:1},7).wait(38).to({startPosition:0},0).wait(1));

	// BG
	this.instance_5 = new lib.bg728x90();
	this.instance_5.parent = this;
	this.instance_5.setTransform(1,1);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(79));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(319.5,-171,862,351);
// library properties:
lib.properties = {
	id: '518BD99F26E84AE1902D4F543675FC66',
	width: 728,
	height: 90,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/snowpngcopy.png", id:"snowpngcopy"},
		{src:"images/728x90_atlas_P_.png", id:"728x90_atlas_P_"},
		{src:"images/728x90_atlas_NP_.jpg", id:"728x90_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['518BD99F26E84AE1902D4F543675FC66'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;